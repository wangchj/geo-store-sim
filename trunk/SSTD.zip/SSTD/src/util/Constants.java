/**
 * 
 */
package util;

/**
 * File, path settings and constants
 * Change USER variable for different users (LING/SIMON)
 * 
 * @author Siu Wu (Simon)
 *
 */
public class Constants {
	
	// File paths
	public static String FILE_PATH = "J:\\Ling Hu\\Grad Study\\CSG230\\project_data\\";
	
	// Files
	public static final String TUNING_SET = "tuning_set\\tuning_set.txt";
	public static final String TEST_SET = "test_set\\test_set.txt";
	public static final String TRAINING_SET = "training_set.txt";
	public static final String MOVIE_ID_TREE_LEAF_ENTRIES = "movieIDTreeLeafEntries.txt";
	public static final String CUST_ID_TREE_LEAF_ENTRIES = "custIDTreeLeafEntries.txt";
	
	public static final String MOVIE_DETAIL = "movies_details_clean.xml" ;
	
	/**
	 * 
	 */
	public Constants() {
		// TODO Auto-generated constructor stub
	}

}
