/**
 * 
 */
package util;

/**
 * @author Ling
 *
 */
import java.security.MessageDigest;


public class MD5 {

    public static String md5Converter(String strParam) {
        try {
            byte[] defaultBytes = strParam.getBytes();
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.reset();
            md.update(defaultBytes);
            byte messageDigest[] = md.digest();

            StringBuffer hexString = new StringBuffer();
            for (int i = 0; i < messageDigest.length; i++) {
                hexString.append(Integer.toHexString(0xFF & messageDigest[i]));
            }
            return hexString.toString();
        } catch (Exception e) {
            return null;
        }
    }
}

