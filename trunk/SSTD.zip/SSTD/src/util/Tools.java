/**
 * 
 */
package util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.*;

/**
 * Tools
 * 
 * @author Siu Wu (Simon)
 * 
 * update - add println(String) and print(String) methods
 * @author Ling Hu
 * @date 03/29/2007
 */
public class Tools {
	public static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
	
	/**
	 * 
	 */
	public Tools() {
		// TODO Auto-generated constructor stub
	}

	// Get current time
	public static String getCurrentTime() {
		return ("[" + dateFormat.format(new Date(System.currentTimeMillis())) + "] ");
	}
	
	// print out information w/ change line
	public static void println(String str) {
		System.out.println(getCurrentTime() + str) ;
	}
	
	// print out information w/o change line
	public static void print(String str) {
		System.out.print(str) ;
	}
	
	// following is for debug
	public static void print(int[] arr) {
		if (arr == null) {
			Tools.println("input array is null") ;
			return ;
		}
		for (int i : arr)
			Tools.print(i + ",") ;
		Tools.println("") ;
	}
	
	public static void print(double[] arr) {
		if (arr == null) {
			Tools.println("input array is null") ;
			return ;
		}
		for (double i : arr)
			Tools.print(i + ",") ;
		Tools.println("") ;
	}
	
	public static void print(int[][] arr) {
		if (arr == null) {
			Tools.println("input 2-dim array is null") ;
			return ;
		}
		for (int[] i : arr) {
			print(i) ;
		}
		Tools.println("") ;
	}	
/*	
	// Convert integer to byte array
	public static byte[] integerToByteArray(int intgr) {
		byte[] byteArr = new byte[4];
		
		
		
		return byteArr;
	}
		
	// Convert byte array to integer
	public static int byteArrayToInteger(byte[] byteArr) {
		int intgr = 0;
		
		return intgr;
	}
	
	// Remove rating date from training set, and convert to chars to bytes
	public static void processTrainingSet() {
		try {
			BufferedReader bufRdr = new BufferedReader(new FileReader(Constants.FILE_PATH + Constants.TRAINING_SET));
			FileOutputStream fos = new FileOutputStream(Constants.FILE_PATH + Constants.TRAINING_SET_PROCESSED);
			String line = null;
			String[] fields = null;
			
int i = 0;
			
			while ((line = bufRdr.readLine()) != null) {
++i;
System.out.println(i + "th line:" + line);
if (i == 10) {
	break;
}
				// line: "movieID custID ratingDate rating"
				fields = line.split("\\s+");
				fos.write(fields[0]);
			}
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public static void main(String args[]) {
		
	}*/
}
