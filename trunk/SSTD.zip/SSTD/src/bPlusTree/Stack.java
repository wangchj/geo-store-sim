/**
 * 
 */
package bPlusTree;

/**
 * @author Ling
 *
 */
public interface Stack {
	  public boolean isEmpty();
	  public Object getLast(); // Throw NoSuchElementExceptions if stack is empty
	  public void clear();
	  public void addLast(Object item);
	  public Object removeLast(); // Throw NoSuchElementExceptions if stack is empty
	}
