package bPlusTree;

public class SingleLinkedListNode {
	  protected Object item;
	  protected SingleLinkedListNode succ;

	  public SingleLinkedListNode(Object item, SingleLinkedListNode succ) {
	    this.item = item;
	    this.succ = succ;
	  }
	}