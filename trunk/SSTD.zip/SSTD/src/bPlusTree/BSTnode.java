package bPlusTree;

/**
 * Binary search tree node
 *<pre>
 *    data area   --- implemented here as a minimal single integer
 *    height      --- height within the tree of THIS node
 *    size        --- number of nodes in this (sub)tree
 *    util        --- miscellaneous int value, should we every need it
 *    left link   --- left subtree
 *    right link  --- right subtree
 *
 * Access to the fields will be through package-level visibility
 *</pre>
 */
class BSTnode
{  int     data;   // Realistic case, this could be quite large
   int     height; // Height of THIS NODE
   int     size;   // Number of nodes in this (sub)tree
   int     util;   // Generic utility area for an int value
   BSTnode left,   // "<" subtree
           right;  // ">" subtree

   BSTnode ( int data ) // Constructor for leaf node
   {  this.data   = data;
      this.height = this.size = 1;
      this.left   = null;
      this.right  = null;
   }

public BSTnode(int data2, BSTnode left2, BSTnode right2) {
	this.data = data2; 
	this.left = left2;
	this.right = right2;
	this.height = 1;
}
   
   
}
