/**
 * 
 */
package bPlusTree;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

import util.Constants;
import util.Tools;

/**
 * Two B+ Trees (like B+ Tree, but not exactly) for Rating
 *  1: key is custID
 * 	2: key is movieID
 *  Tree Structure:
 * 	  In each level, nodes are combined into a nodeset (a 1-D int array to save memory)
 *    All levels of index nodesets are combined into a collection of nodesets (a 2-D array)
 * 	  Index nodesets: 2-D array,
 * 					  [i][] is a nodeset of level i,
 * 					  [i][j...k] is a node with entries from j to k,
 *                    [i][j] is an entry (j) of a node, which stores a key (custID or movieID) and
 *                           points to the starting index of lower level nodeset (j points to j * NUM_ENTRIES_PER_NODE)
 * 	  Leaf nodeset: 2-D array, [][0] is key (custID or movieID), [][1...n] are pointers (indexes of custIDs or 
 * 											movieIDs array)
 * 
 * Memory:
 *  All class variables in this class take 792MB memory
 * 
 * Storage:
 *  store as Vector<MovieCustRating(short, int, byte)>: 999MB Memory, 7.5min time
 *  store as MovieCustRating[] (short, int, byte): 999MB Memory, 7.5min time
 *  store as short[], int[], byte[]: 339MB Memory, 6.5min time
 *  
 * Statistics:
 *  total number of rating records (training_set.txt): 46704158
 *  movieID:
 * 	  number of unique movieIDs: 9058
 * 	  min movieID: 1
 * 	  max movieID: 17770
 *    number of occurence of a movieID:
 *      avg: 5156, max: 227715, min: 3
 *  custID:
 * 	  number of unique custIDs: 477293
 * 	  min custID: 6
 * 	  max custID: 2649429
 *    number of occurence of a custID:
 *      avg: 97, max: 9031, min: 1
 *      
 * @author Siu Wu (Simon)
 *
 */
public class RatingTrees {
	// Data
	public static short[] movieIDs = new short[46704158];
	public static int[] custIDs = new int[46704158];
	public static byte[] ratings = new byte[46704158];

	// Statistics of data
	private static final short NUM_MOVIE_ID = 9058;
	public static final int NUM_CUST_ID = 477293;

	// Tree settings
	private static final byte NUM_ENTRIES_PER_NODE = 100;
	
	// Index nodesets
	private static int[][] movieIDTreeIndexNodesets = null;
	private static int[][] custIDTreeIndexNodesets = null;
	
	// Leaf nodeset
	private static int[][] movieIDTreeLeafNodeset = null;
	private static int[][] custIDTreeLeafNodeset = null;
	
	// Average ratings
	private static double[] avgMovieRatings = new double[NUM_MOVIE_ID];
	private static double[] avgCustRatings = new double[NUM_CUST_ID];
	
	// Leaf entries file
	private boolean hasMovieIDTreeLeafEntriesFile = false;
	private boolean hasCustIDTreeLeafEntriesFile = false;
	private static final short NUM_ENTRIES_PER_LINE = 500;
	
	// Create the trees
	public RatingTrees() {
		// check if the leaf entries files exists
		if ((new File(Constants.FILE_PATH + Constants.MOVIE_ID_TREE_LEAF_ENTRIES)).exists())
			hasMovieIDTreeLeafEntriesFile = true;
		if ((new File(Constants.FILE_PATH + Constants.CUST_ID_TREE_LEAF_ENTRIES)).exists())
			hasCustIDTreeLeafEntriesFile = true;
		
		try {
			buildTrees();
//			printTree(custIDTreeIndexNodesets, custIDTreeLeafNodeset);
//			printTree(movieIDTreeIndexNodesets, movieIDTreeLeafNodeset);
//			System.exit(0);
			loadData();
		}
		catch (Exception ex) {
			System.err.println("Error in RatingTrees(): got exception when creating rating trees.");
			ex.printStackTrace();
		}
	}

	/**
	 * Build the basic structure of the trees w/o any data
	 * 
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private void buildTrees()
		throws FileNotFoundException, IOException {
		int i = 0, j = 0, k = 0, numOfLevels = 0;
		BufferedReader bufRder = null;
		String line = null, fields[] = null;

		System.out.println(Tools.getCurrentTime() + "buildTrees() starts");
		
		// MOVIE ID TREE
		// Compute number of levels (exclude leaf nodes) h = logbM
		numOfLevels = (int) Math.floor(Math.log10((double) NUM_MOVIE_ID) /
			Math.log10((double) NUM_ENTRIES_PER_NODE));
		movieIDTreeIndexNodesets = new int[numOfLevels][];
		
		// Compute number of nodes per level
		j = NUM_ENTRIES_PER_NODE;
		for (i = 0; i < numOfLevels; ++i) {
			movieIDTreeIndexNodesets[i] = new int[j];
			
			// initialize each entry to -1
			for (k = 0; k < j; ++k)
				movieIDTreeIndexNodesets[i][k] = -1;
			
			j *= NUM_ENTRIES_PER_NODE;
		}
		
		// Build leaf nodes with movieIDCount.csv file (sorted by movieID)
		movieIDTreeLeafNodeset = new int[NUM_MOVIE_ID][];
		i = 0;
		bufRder = new BufferedReader(new FileReader(Constants.FILE_PATH + "movieIDCount.csv"));
		while ((line = bufRder.readLine()) != null) {
			// format: ID,Count
			fields = line.split(",");

			j = Integer.parseInt(fields[1]) + 1;
			movieIDTreeLeafNodeset[i] = new int[j];
			// entry 0 is ID
			movieIDTreeLeafNodeset[i][0] = Integer.parseInt(fields[0]);
			// initialize other entries to -1
			for (k = 1; k < j; ++k)
				movieIDTreeLeafNodeset[i][k] = -1;
			++i;
		}
		bufRder.close();
		
		// fill in keys in index nodes
		// lowest level above leaf nodes
		j = movieIDTreeIndexNodesets[numOfLevels - 1].length;
		for (k = 0; k < j && (k + 1)*NUM_ENTRIES_PER_NODE - 1 < NUM_MOVIE_ID; ++k) {
			movieIDTreeIndexNodesets[numOfLevels - 1][k] = 
				movieIDTreeLeafNodeset[(k + 1)*NUM_ENTRIES_PER_NODE - 1][0];
		}
		// fill in the last index node for the last key in the last leaf node
		if ((k + 1)*NUM_ENTRIES_PER_NODE > NUM_MOVIE_ID) {
			movieIDTreeIndexNodesets[numOfLevels - 1][k] = 
				movieIDTreeLeafNodeset[NUM_MOVIE_ID - 1][0];
		}
		// upper levels		
		for (i = numOfLevels - 2; i >= 0 ; --i) {
			j = movieIDTreeIndexNodesets[i].length;
			for (k = 0; k < j; ++k) {
				movieIDTreeIndexNodesets[i][k] = movieIDTreeIndexNodesets[i + 1][(k + 1)*NUM_ENTRIES_PER_NODE - 1];
			}
			--k;
			while (k >= 0 && movieIDTreeIndexNodesets[i][k] == -1)
				--k;
			if (k >= 0)
				movieIDTreeIndexNodesets[i][k + 1] = movieIDTreeLeafNodeset[NUM_MOVIE_ID - 1][0];
		}

		// CUST ID TREE
		// Compute number of levels (exclude leaf nodes)
		numOfLevels = (int) Math.floor(Math.log10((double) NUM_CUST_ID) /
			Math.log10((double) NUM_ENTRIES_PER_NODE));
		custIDTreeIndexNodesets = new int[numOfLevels][];
		
		// Compute number of nodes per level
		j = NUM_ENTRIES_PER_NODE;
		for (i = 0; i < numOfLevels; ++i) {
			custIDTreeIndexNodesets[i] = new int[j];
			
			// initialize each entry to -1
			for (k = 0; k < j; ++k)
				custIDTreeIndexNodesets[i][k] = -1;
			
			j *= NUM_ENTRIES_PER_NODE;
		}
		
		// Build leaf nodes with movieIDCount.csv file (sorted by movieID)
		custIDTreeLeafNodeset = new int[NUM_CUST_ID][];
		i = 0;
		bufRder = new BufferedReader(new FileReader(Constants.FILE_PATH + "custIDCount.csv"));
		while ((line = bufRder.readLine()) != null) {
			// format: ID,Count
			fields = line.split(",");

			j = Integer.parseInt(fields[1]) + 1;
			custIDTreeLeafNodeset[i] = new int[j];
			// entry 0 is ID
			custIDTreeLeafNodeset[i][0] = Integer.parseInt(fields[0]);
			// initialize other entries to -1
			for (k = 1; k < j; ++k)
				custIDTreeLeafNodeset[i][k] = -1;
			++i;
		}
		bufRder.close();
		
		// fill in keys in index nodes
		// lowest level above leaf nodes
		j = custIDTreeIndexNodesets[numOfLevels - 1].length;
		for (k = 0; k < j && (k + 1)*NUM_ENTRIES_PER_NODE - 1 < NUM_CUST_ID; ++k) {
			custIDTreeIndexNodesets[numOfLevels - 1][k] = 
				custIDTreeLeafNodeset[(k + 1)*NUM_ENTRIES_PER_NODE - 1][0];
		}
		// fill in the last index node for the last key in the last leaf node
		if ((k + 1)*NUM_ENTRIES_PER_NODE > NUM_CUST_ID) {
			custIDTreeIndexNodesets[numOfLevels - 1][k] = 
				custIDTreeLeafNodeset[NUM_CUST_ID - 1][0];
		}
		// upper levels		
		for (i = numOfLevels - 2; i >= 0 ; --i) {
			j = custIDTreeIndexNodesets[i].length;
			for (k = 0; k < j; ++k) {
				custIDTreeIndexNodesets[i][k] = custIDTreeIndexNodesets[i + 1][(k + 1)*NUM_ENTRIES_PER_NODE - 1];
			}
			--k;
			while (k >= 0 && custIDTreeIndexNodesets[i][k] == -1)
				--k;
			if (k >= 0)
				custIDTreeIndexNodesets[i][k + 1] = custIDTreeLeafNodeset[NUM_CUST_ID - 1][0];
		}
		
		System.out.println(Tools.getCurrentTime() + "buildTrees() done");
	}
	
	/**
	 * Search all the customers who rated a specific movie
	 * 
	 * @param movieID
	 * @return an int array of indexes of the data arrays, null if not found,
	 * i.e. it returns an int[] indexes, you need to access the data by 
	 * movieIDs[indexese[i]], custIDs[indexese[i]], ratings[indexese[i]],
     * this should be efficient and save memory
	 */
	public static int[] searchMovieID(int movieID) {
		return searchID(movieIDTreeIndexNodesets, movieIDTreeLeafNodeset, movieID);
	}

	/**
	 * Search all the movies which are rated by a specific customer
	 * 
	 * @param custID
	 * @return an int array of indexes of the data arrays, null if not found,
	 * i.e. it returns an int[] indexes, you need to access the data by 
	 * movieIDs[indexese[i]], custIDs[indexese[i]], ratings[indexese[i]],
     * this should be efficient and save memory
	 */
	public static int[] searchCustID(int custID) {
		return searchID(custIDTreeIndexNodesets, custIDTreeLeafNodeset, custID);
	}
	
	private static int[] searchID(int[][] indexNodesets, int[][] leafNodeset, int searchID) {
		int[] leafEntries = null;
		int i = 0, j = 0, len1 = 0, nextLevelStart = 0;
		
		// find the leaf node
		len1 = indexNodesets.length;
		for (i = 0; i < len1; ++i) {
			j = nextLevelStart;
			nextLevelStart = binaryGrEqSearch(indexNodesets[i], j, searchID);
			if (nextLevelStart >= j + NUM_ENTRIES_PER_NODE) {
				System.err.println("Error in searchID(): cannot find nextLevelStart of index node");
//System.out.println("searchID:" + searchID + ", lvl:" + i + ", start:" + j + ", nextStart:" + nextLevelStart);
//System.exit(0);
				return null;
			}
			nextLevelStart *= NUM_ENTRIES_PER_NODE;
		}

		// find the entry of leaf node		
		i = binaryEqSearch(leafNodeset, nextLevelStart, searchID);
		if (i > -1) {
			len1 = leafNodeset[i].length - 1;
			leafEntries = new int[len1];
			System.arraycopy(leafNodeset[i], 1, leafEntries, 0, len1);
			return leafEntries;
		}
		else {
//			System.out.println("searchID(): cannot find the leaf node");
			return null;
		}
	}

	/**
	 * Search the average rating of a specific movie
	 * 
	 * @param movieID
	 * @return the average rating, 0 if not found
	 */
	public static double searchAvgMovieRating(int movieID) {
		return searchAvgRating(movieIDTreeIndexNodesets, movieIDTreeLeafNodeset, avgMovieRatings, movieID);
	}

	/**
	 * Search the average rating given by a specific customer
	 * 
	 * @param custID
	 * @return the average rating, 0 if not found
	 */
	public static double searchAvgCustRating(int custID) {
		return searchAvgRating(custIDTreeIndexNodesets, custIDTreeLeafNodeset, avgCustRatings, custID);
	}

	private static double searchAvgRating(int[][] indexNodesets, int[][] leafNodeset, 
			double[] avgRatings, int searchID) {
		int i = 0, j = 0, len1 = 0, nextLevelStart = 0;
		
		// find the leaf node
		len1 = indexNodesets.length;
		for (i = 0; i < len1; ++i) {
			j = nextLevelStart;
			nextLevelStart = binaryGrEqSearch(indexNodesets[i], j, searchID);
			if (nextLevelStart >= j + NUM_ENTRIES_PER_NODE) {
				System.err.println("Error in searchAvgRating(): cannot find nextLevelStart of index node");
				return 0.0;
			}
			nextLevelStart *= NUM_ENTRIES_PER_NODE;
		}
		
		// find the entry of leaf node		
		i = binaryEqSearch(leafNodeset, nextLevelStart, searchID);
		if (i > -1) {
			return avgRatings[i];
		}
		else {
//			System.out.println("searchAvgRating(): cannot find the leaf node");
			return 0.0;
		}
	}

	/**
	 * Search the rating of a specific movie given by a specific customer 
	 * 
	 * @param movieID
	 * @param custID
	 * @return rating, 0 if not found
	 */
	public static byte searchRating(int movieID, int custID) {
		int i = 0, j = 0, len1 = 0, nextLevelStart = 0;

		// find the leaf node
		len1 = custIDTreeIndexNodesets.length;
		for (i = 0; i < len1; ++i) {
			j = nextLevelStart;
			nextLevelStart = binaryGrEqSearch(custIDTreeIndexNodesets[i], j, custID);
			if (nextLevelStart >= j + NUM_ENTRIES_PER_NODE) {
				System.err.println("Error in searchRating(): cannot find nextLevelStart of index node");
				return 0;
			}
			nextLevelStart *= NUM_ENTRIES_PER_NODE;
		}
		
		// find the entry of leaf node		
		i = binaryEqSearch(custIDTreeLeafNodeset, nextLevelStart, custID);
		if (i > -1) {
			len1 = custIDTreeLeafNodeset[i].length;
			for (j = 1; j < len1; ++j) {
				if (movieIDs[custIDTreeLeafNodeset[i][j]] == (short) movieID) {
					return ratings[custIDTreeLeafNodeset[i][j]]; 
				}
			}
			return 0;
		}
		else {
//			System.out.println("searchRating(): cannot find the leaf node");
			return 0;
		}
	}
	
	/**
	 * Insert an index of data array into an entry of a leaf node
	 * 
	 * @param indexNodesets
	 * @param leafNodeset
	 * @param objID the custID or movieID
	 * @param objIndex the index pointing to the data array to be inserted
	 */
	private void insertLeaf(int[][] indexNodesets, int[][] leafNodeset, int objID, int objIndex) {
		int i = 0, j = 0, len1 = 0, nextLevelStart = 0;
		
		// find the leaf node
		len1 = indexNodesets.length;
		for (i = 0; i < len1; ++i) {
			j = nextLevelStart;
			nextLevelStart = binaryGrEqSearch(indexNodesets[i], j, objID);
			if (nextLevelStart >= j + NUM_ENTRIES_PER_NODE) {
				System.err.println("Error in insertLeaf(): cannot find nextLevelStart of index node");
				return;
			}
			nextLevelStart *= NUM_ENTRIES_PER_NODE;
		}
		
		// find the entry of leaf node		
		i = binaryEqSearch(leafNodeset, nextLevelStart, objID);
		if (i > -1) {
			len1 = leafNodeset[i].length;
			for (j = 1; j < len1; ++j) {
				if (leafNodeset[i][j] == -1) {
					leafNodeset[i][j] = objIndex;
					return;
				}
			}				
			if (j == len1) {
				System.err.println("Error in insertLeaf(): cannot find an empty slot in leaf node for insertion");
				return;
			}
		}
		else {
			System.err.println("Error in insertLeaf(): cannot find the leaf node for insertion");
		}
	}
	
	/**
	 * Binary Search for the entry >= key in a indexNodeset
	 * 
	 * @param indexNodesets
	 * @param startIndex inclusive
	 * @param key
	 * @return the index of the entry if equal, the index of the smallest entry bigger than the key if not found 
	 */
	private static int binaryGrEqSearch(int[] indexNodeset, int startIndex, int key) {
		int low = 0, high = 0, p = 0;
		
		low = startIndex;
		high = low + NUM_ENTRIES_PER_NODE - 1;
		
		// check if high is empty
		if (indexNodeset[high] == -1) {
//			for (p = high - 1; p >= low && indexNodeset[p] == -1; --p);
//			high = p;
			
			// use binary search
			int l = low, h = high;
			p = l + ((h - l) / 2);
			while (l <= h) {
				if (indexNodeset[p] == -1)
					h = p - 1;
				else
					l = p + 1;
				p = l + ((h - l) / 2);
			}
			high = p - 1;
		}
		
		p = low + ((high - low) / 2);
		while (low <= high) {
			if (indexNodeset[p] > key)
				high = p - 1;
			else if (indexNodeset[p] < key)
				low = p + 1;
			else
				return p;
			
			p = low + ((high - low) / 2);
		}
		if (p < startIndex)
			return startIndex;
		else
			return p;
	}
	
	/**
	 * Binary Search for the entry = key in a leafNodesets
	 * 
	 * @param leafNodesets
	 * @param startIndex inclusive
	 * @param key
	 * @return the index of the entry if equal, -1 if not found 
	 */
	private static int binaryEqSearch(int[][] leafNodeset, int startIndex, int key) {
		int low = 0, high = 0, p = 0;
		
		low = startIndex;
		high = low + NUM_ENTRIES_PER_NODE - 1;
		
		// check if high is empty
		if (high >= leafNodeset.length)
			high = leafNodeset.length - 1;
		
		p = low + ((high - low) / 2);
		while (low <= high) {
			if (leafNodeset[p][0] > key)
				high = p - 1;
			else if (leafNodeset[p][0] < key)
				low = p + 1;
			else
				return p;
			
			p = low + ((high - low) / 2);
		}
		return -1;
	}
	
	/**
	 * Load rating data from disk to memory
	 * This method needs 6-7 min
	 * 
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private void loadData() throws FileNotFoundException, IOException {
		BufferedReader bufRder = null;
		String line = null;
		String[] fields = null;
		byte rating = 0;
		short movieID = 0;
		int custID = 0, i = 0;
		System.out.println(Tools.getCurrentTime() + "loadData() starts");
		
		bufRder = new BufferedReader(new FileReader(Constants.FILE_PATH + Constants.TRAINING_SET));
		while ((line = bufRder.readLine()) != null) {
			// line: "movieID custID ratingDate rating"
			fields = line.split("\\s+");
			
		try {
					movieID = Short.parseShort(fields[0]);
					custID = Integer.parseInt(fields[1]);
					rating = Byte.parseByte(fields[3]);
		}
		catch (ArrayIndexOutOfBoundsException ex) {
			System.out.println("File is " + Constants.FILE_PATH + Constants.TRAINING_SET);
			System.out.println("Line is " + line);
			System.out.println("Line number is " + (i+1));
			ex.printStackTrace();
			System.exit(0);
		}

			movieIDs[i] = movieID;
			custIDs[i] = custID;
			ratings[i] = rating;
			
			// Insert into trees
			if (!hasMovieIDTreeLeafEntriesFile)
				insertLeaf(movieIDTreeIndexNodesets, movieIDTreeLeafNodeset, movieID, i);
			if (!hasCustIDTreeLeafEntriesFile)
				insertLeaf(custIDTreeIndexNodesets, custIDTreeLeafNodeset, custID, i);
			
			++i;
			if (i % 5000000 == 0)
				System.out.println(Tools.getCurrentTime() + "Loaded " + i + " data (" + Math.round(i / 467041.58) + "%)");
		}
		bufRder.close();
		
		System.out.println(Tools.getCurrentTime() + "loadData() done");

		// save leaf entries into file or retrieve from files
		if (!hasMovieIDTreeLeafEntriesFile)
			saveTreeLeafEntriesToFile(movieIDTreeLeafNodeset, Constants.FILE_PATH + Constants.MOVIE_ID_TREE_LEAF_ENTRIES);
		else
			retrieveTreeLeafEntriesFromFile(movieIDTreeLeafNodeset, Constants.FILE_PATH + Constants.MOVIE_ID_TREE_LEAF_ENTRIES);
		if (!hasCustIDTreeLeafEntriesFile)
			saveTreeLeafEntriesToFile(custIDTreeLeafNodeset, Constants.FILE_PATH + Constants.CUST_ID_TREE_LEAF_ENTRIES);
		else
			retrieveTreeLeafEntriesFromFile(custIDTreeLeafNodeset, Constants.FILE_PATH + Constants.CUST_ID_TREE_LEAF_ENTRIES);
		
		// compute average ratings
		 computeAvgRatings(movieIDTreeLeafNodeset, avgMovieRatings);
		 computeAvgRatings(custIDTreeLeafNodeset, avgCustRatings);
	}
	
	/**
	 * Save tree leaf entries to file to avoid insertion at the next time
	 * 
	 * @param leafNodeset
	 * @param filename
	 * @throws IOException
	 * @throws FileNotFoundException
	 */
	private void saveTreeLeafEntriesToFile(int[][] leafNodeset, String filename)
		throws IOException, FileNotFoundException {
		PrintWriter pwr = null;
		int i = 0, j = 0, len1 = 0, len2 = 0;

		System.out.println(Tools.getCurrentTime() + "saveTreeLeafEntriesToFile() starts");
		
		pwr = new PrintWriter(filename);
		len1 = leafNodeset.length;
		for (i = 0; i < len1; ++i) {
			len2 = leafNodeset[i].length;
			pwr.print(i + "," + leafNodeset[i][1]);
			for (j = 2; j < len2; ++j) {
				// format: 
				//		0,data{x NUM_ENTRIES_PER_LINE}
				//		,data{x NUM_ENTRIES_PER_LINE}
				//		1,data{x NUM_ENTRIES_PER_LINE}
				//		,data{x NUM_ENTRIES_PER_LINE}
				//		...
				pwr.print("," + leafNodeset[i][j]);
				
				// next line
				if (j + 1 < len2 && j % NUM_ENTRIES_PER_LINE == 0)
					pwr.println();
			}
			pwr.println();
		}
		pwr.close();
		
		System.out.println(Tools.getCurrentTime() + "saveTreeLeafEntriesToFile() done");
	}
	
	/**
	 * Retrieve tree leaf entries from file to avoid insertion
	 * Run this method needs 2 min (per tree)
	 * 
	 * @param leafNodeset
	 * @param filename
	 */
	private void retrieveTreeLeafEntriesFromFile(int[][] leafNodeset, String filename)
		throws IOException, FileNotFoundException {
		BufferedReader bufRder = null;
		String line = null;
		String[] fields = null;
		int outerIndex = 0, innerIndex = 0, i = 0, len = 0;
		
		System.out.println(Tools.getCurrentTime() + "retrieveTreeLeafEntriesFromFile() starts");
		
		bufRder = new BufferedReader(new FileReader(filename));
		while ((line = bufRder.readLine()) != null) {
			// format: 
			//		0,data{x NUM_ENTRIES_PER_LINE}
			//		,data{x NUM_ENTRIES_PER_LINE}
			//		1,data{x NUM_ENTRIES_PER_LINE}
			//		,data{x NUM_ENTRIES_PER_LINE}
			//		...
			fields = line.split(",");
			if (fields[0].length() > 0) {
				outerIndex = Integer.parseInt(fields[0]);
				innerIndex = 1;
			}
			len = fields.length;
			for (i = 1; i < len; ++i) {
				leafNodeset[outerIndex][innerIndex] = Integer.parseInt(fields[i]);
				++innerIndex;
			}
		}
		bufRder.close();
		
		System.out.println(Tools.getCurrentTime() + "retrieveTreeLeafEntriesFromFile() done");
	}
		
	// Compute average ratings
	private void computeAvgRatings(int[][] leafNodeset, double[] avgRatings) {
		int i = 0, j = 0, total = 0, len1 = 0, len2 = 0;

		System.out.println(Tools.getCurrentTime() + "computeAvgRatings() starts");
		
		len1 = leafNodeset.length;
		for (i = 0; i < len1; ++i) {
			total = 0;
			len2 = leafNodeset[i].length;
			for (j = 1; j < len2; ++j) {
				total += ratings[leafNodeset[i][j]];
			}
			--len2;
			avgRatings[i] = (len2 > 0 ? total / (double) len2 : 0.0);
		}
		
		System.out.println(Tools.getCurrentTime() + "computeAvgRatings() done");
	}
	
	private void printTree(int[][] indexNodesets, int[][] leafNodeset) {
		int i = 0, j = 0, len1 = 0, len2 = 0;
		
		System.out.println("---- Index Nodesets ----");
		len1 = indexNodesets.length;
		for (i = 0; i < len1; ++i) {
			System.out.print(i + "----");
			len2 = indexNodesets[i].length;
			for (j = 0; j < len2 && indexNodesets[i][j] > -1; ++j) {
				System.out.print(j + ":" + indexNodesets[i][j] + "|");
				
				if (j % 100 == 0)
					System.out.println();
			}
			System.out.println("END");
		}
/*		
		System.out.println("---- Leaf Nodeset ----");
		len1 = leafNodeset.length;
		for (i = 0; i < len1; ++i) {
			System.out.print(i + ":" + leafNodeset[i][0] + "|");
			
			if (i % 100 == 0)
				System.out.println();
		}
		System.out.println("END"); */
	}
}
