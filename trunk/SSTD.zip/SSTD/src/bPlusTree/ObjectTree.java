/**
 * 
 */
package bPlusTree;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * @author Ling
 *
 */
public class ObjectTree {

	private static long[] hilbertValues = new long[10160];
	
	private static final short NUM_SPATIAL_POIS = 10160;
	
	// Tree settings
	private static final byte NUM_ENTRIES_PER_NODE = 100;
	
	// Index nodesets
	private static int[][] hilbertObjectTreeIndexNodesets = null;
	
	// Leaf nodeset
	private static int[][] hilbertObjectTreeLeafNodeset = null;
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}
	
	private void buildTrees()
	throws FileNotFoundException, IOException {
		
	}

}
