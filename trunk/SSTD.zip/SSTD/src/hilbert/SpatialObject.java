/**
 * 
 */
package hilbert;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * @author Ling
 *
 */
public class SpatialObject implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4895199208330372541L;
	private long id;
	private double x;
	private double y;
	private long qx;
	private long qy;
	private Object nonSpatial;
	
	
	private long hilbertValue = -1;
	private char dual; //a-primary with no duplication; b-primary with duplication; c-secondary
	/**
	 * 
	 * @param id
	 * @param x
	 * @param y
	 * @param qx
	 * @param qy
	 * @param nonSpatial
	 * @param dual --- a-primary with no duplication; b-primary with duplication; c-secondary
	 */
	public SpatialObject(long id, double x, double y, long qx, long qy,
			Object nonSpatial, char dual) {
		super();
		this.id = id;
		this.x = x;
		this.y = y;
		this.qx = qx;
		this.qy = qy;
		this.nonSpatial = nonSpatial;
		this.dual = dual;
	}
	
	
	public long getHilbertValue() {
		return hilbertValue;
	}


	public void setHilbertValue(long hilbertValue) {
		this.hilbertValue = hilbertValue;
	}

	
	public char getDual() {
		return dual;
	}


	public long getId() {
		return id;
	}
	public double getX() {
		return x;
	}
	public double getY() {
		return y;
	}
	public long getQx() {
		return qx;
	}
	public long getQy() {
		return qy;
	}
	public Object getNonSpatial() {
		return nonSpatial;
	}
	
	public String isDual() {
		if (this.dual == 'a') return "Primary without duplication.";
		if (this.dual == 'b') return "Primary with duplication.";
		if (this.dual == 'c') return "Secondary.";
		return "Invalid dual tag.";
	}


	public String toString() {
		return "Hilbert value = " + hilbertValue + " Object index= "+id+" with qx= " + qx + " with qy= " + qy + " " + isDual();
	}
	
	public static byte[] getBytes(Object obj) throws java.io.IOException{
	      ByteArrayOutputStream bos = new ByteArrayOutputStream();
	      ObjectOutputStream oos = new ObjectOutputStream(bos);
	      oos.writeObject(obj);
	      oos.flush();
	      oos.close();
	      bos.close();
	      byte [] data = bos.toByteArray();
	      return data;
	  }
	
	public static SpatialObject getObject(byte[] bytes) throws java.io.IOException, ClassNotFoundException{
		ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
		ObjectInputStream ois = new ObjectInputStream(bis);
		Object obj = ois.readObject();
		return (SpatialObject)obj;
	}
	
	public byte[] getBytes() throws java.io.IOException {
		return getBytes(this);
	}
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		SpatialObject so = new SpatialObject(19232, 8923.32, 23432.34, 8923,23432, null, 'a');
		byte[] bytes = getBytes(so);
		String str = new String(bytes);
		System.out.println(str);
		SpatialObject s = getObject(bytes);
		System.out.println(s.toString());
	}
}
