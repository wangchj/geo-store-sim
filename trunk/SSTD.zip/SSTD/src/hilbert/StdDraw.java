package hilbert;
/*************************************************************************
 *  Compilation:  javac StdDraw.java
 *  Execution:    java StdDraw
 *
 *  Standard graphics library.
 *
 *  For documentation, see http://www.cs.princeton.edu/introcs/15inout
 *
 *  Todo
 *  ----
 *    -  Add support for CubicCurve2D or QudarticCurve2D or Arc2D
 *    -  Add support for gradient fill, etc.
 *
 *  Remarks
 *  -------
 *    -  don't use AffineTransform for rescaling since it inverts
 *       images and strings
 *    -  careful using setFont in inner loop within an animation -
 *       it can cause flicker
 *
 *************************************************************************/

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.geom.*;
import java.awt.event.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;


public class StdDraw //extends JFrame
	implements ActionListener, MouseListener, MouseMotionListener {

    /**
	 * 
	 */
	private static final long serialVersionUID = -6288110705181910840L;
	// pre-defined colors
    public static final Color BLACK      = Color.BLACK;
    public static final Color BLUE       = Color.BLUE;
    public static final Color CYAN       = Color.CYAN;
    public static final Color DARK_GRAY  = Color.DARK_GRAY;
    public static final Color GRAY       = Color.GRAY;
    public static final Color GREEN      = Color.GREEN;
    public static final Color LIGHT_GRAY = Color.LIGHT_GRAY;
    public static final Color MAGENTA    = Color.MAGENTA;
    public static final Color ORANGE     = Color.ORANGE;
    public static final Color PINK       = Color.PINK;
    public static final Color RED        = Color.RED;
    public static final Color WHITE      = Color.WHITE;
    public static final Color YELLOW     = Color.YELLOW;

    // default colors
    public static final Color DEFAULT_PEN_COLOR   = BLACK;
    public static final Color DEFAULT_CLEAR_COLOR = WHITE;

    // current pen color
    private static Color penColor;

    // default canvas size is SIZE-by-SIZE
    private static final int SIZE = 512;
    private static int width  = SIZE;
    private static int height = SIZE;

    // default pen radius
    private static final double DEFAULT_PEN_RADIUS = 0.002;

    // current pen radius
    private static double penRadius;

    // show we draw immediately or wait until next show?
    private static boolean defer = false;

    // boundary of drawing canvas, 5% border
    private static final double BORDER = 0.05;
    private static final double DEFAULT_XMIN = 0.0;
    private static final double DEFAULT_XMAX = 1.0;
    private static final double DEFAULT_YMIN = 0.0;
    private static final double DEFAULT_YMAX = 1.0;
    private double xmin, ymin, xmax, ymax;

    // default font
    private static final Font DEFAULT_FONT = new Font("Serif", Font.PLAIN, 16);

    // current font
    private static Font font;

    // double buffered graphics
    private BufferedImage offscreenImage, onscreenImage;
    private Graphics2D offscreen, onscreen;

    // singleton for callbacks: avoids generation of extra .class files
    //private static StdDraw std = new StdDraw();

    // the frame for drawing to the screen
    private JFrame frame;
    public JFrame getFrame() {
    	return frame;
    }
    // mouse state
    private boolean mousePressed = false;
    private boolean mouseDragged = false;
    private boolean mouseReleased = false;
    private double mouseX = 0;
    private double mouseY = 0;

    
    /**
	 * @throws HeadlessException
	 */
	
	public StdDraw(int w, int h, String title) throws HeadlessException {
		width = w;
        height = h;
    	init(title, null); 
	}
	
	public StdDraw(int w, int h, String title, JFrame parent) throws HeadlessException {
		width = w;
        height = h;
    	init(title, parent); 
	}
	
	
    private void init(String title, JFrame parent) {
    	frame = new JFrame();
        frame.setTitle(title);
        offscreenImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        onscreenImage  = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        offscreen = offscreenImage.createGraphics();
        onscreen  = onscreenImage.createGraphics();
        setXscale();
        setYscale();
        offscreen.setColor(DEFAULT_CLEAR_COLOR);
        offscreen.fillRect(0, 0, width, height);
        setPenColor();
        //setPenColor(WHITE);
        setPenRadius();
        setFont();
        clear();

        // add antialiasing
        RenderingHints hints = new RenderingHints(RenderingHints.KEY_ANTIALIASING,
                                                  RenderingHints.VALUE_ANTIALIAS_ON);
        hints.put(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        offscreen.addRenderingHints(hints);

        // frame stuff
        ImageIcon icon = new ImageIcon(onscreenImage);
        JLabel draw = new JLabel(icon);

        draw.addMouseListener(this);
        draw.addMouseMotionListener(this);

        frame.setContentPane(draw);
        frame.setResizable(false);
        if (title.equals("Main")) {
        	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);            // closes all windows
        }
        else {
        	frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);      // closes only current window
        }
        frame.setJMenuBar(createMenuBar());
        frame.pack();
        frame.setVisible(true);
    }

    // create the menu bar
    public JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("File");
        menuBar.add(menu);
        JMenuItem menuItem1 = new JMenuItem(" Save...   ");
        menuItem1.addActionListener(this);
        menuItem1.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
                                Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        menu.add(menuItem1);
        return menuBar;
    }



    // change the user coordinate system
    public void setXscale() { setXscale(DEFAULT_XMIN, DEFAULT_XMAX); }
    public void setYscale() { setYscale(DEFAULT_YMIN, DEFAULT_YMAX); }
    public void setXscale(double min, double max) {
        double size = max - min;
        xmin = min - BORDER * size;
        xmax = max + BORDER * size;
    }
    public void setYscale(double min, double max) {
        double size = max - min;
        ymin = min - BORDER * size;
        ymax = max + BORDER * size;
    }

    // helper functions that scale from user coordinates to screen coordinates and back
    private double scaleX (double x) { return width  * (x - xmin) / (xmax - xmin); }
    private double scaleY (double y) { return height * (ymax - y) / (ymax - ymin); }
    private double factorX(double w) { return w * width  / Math.abs(xmax - xmin);  }
    private double factorY(double h) { return h * height / Math.abs(ymax - ymin);  }
    private double userX  (double x) { return xmin + x * (xmax - xmin) / width;    }
    private double userY  (double y) { return ymax - y * (ymax - ymin) / height;   }


    /**
     * clear the screen with given color
     */
    public void clear() { clear(DEFAULT_CLEAR_COLOR); }
    public void clear(Color color) {
        offscreen.setColor(color);
        offscreen.fillRect(0, 0, width, height);
        offscreen.setColor(penColor);
        show();
    }

    /**
     * set the pen size
     */
    public void setPenRadius() { setPenRadius(DEFAULT_PEN_RADIUS); }
    public void setPenRadius(double r) {
        penRadius = r * SIZE;
        BasicStroke stroke = new BasicStroke((float) penRadius);
        offscreen.setStroke(stroke);
    }

    /**
     * set the pen color
     */
    public void setPenColor() { setPenColor(DEFAULT_PEN_COLOR); }
    public void setPenColor(Color color) {
        penColor = color;
        offscreen.setColor(penColor);
    }

    /**
     * write the given string in the current font
     */
    public void setFont() { setFont(DEFAULT_FONT); }
    public void setFont(Font f) { font = f; }

    /**
     * draw a line from (x0, y0) to (x1, y1)
     * @param x0
     * @param y0
     * @param x1
     * @param y1
     */
    public void line(double x0, double y0, double x1, double y1) {
        offscreen.draw(new Line2D.Double(scaleX(x0), scaleY(y0), scaleX(x1), scaleY(y1)));
        show();
    }
    
    public void rectangle(double x0, double y0, double w, double h) {
    	System.out.println("from ("+x0+"," +y0+" width= "+w+" height= " + h);
    	System.out.println("from ("+scaleX(x0)+"," +scaleY(y0)+" width= "+factorX(w)+" height= " + factorY(h));
    	offscreen.draw(new Rectangle2D.Double(scaleX(x0), scaleY(y0), factorX(w), factorY(h)));
        show();
    }

    /**
     * draw one pixel at (x, y)
     * @param x
     * @param y
     */
    private void pixel(double x, double y) {
        offscreen.fillRect((int) Math.round(scaleX(x)), (int) Math.round(scaleY(y)), 1, 1);
    }

    /**
     * draw point at (x, y)
     * @param x
     * @param y
     */
    public void point(double x, double y) {
        double xs = scaleX(x);
        double ys = scaleY(y);
        double r = penRadius;
        // double ws = factorX(2*r);
        // double hs = factorY(2*r);
        // if (ws <= 1 && hs <= 1) pixel(x, y);
        if (r <= 1) pixel(x, y);
        else offscreen.fill(new Ellipse2D.Double(xs - r/2, ys - r/2, r, r));
        show();
    }

    /**
     * draw circle of radius r, centered on (x, y); degenerate to pixel if small
     * @param x
     * @param y
     * @param r
     */
    public void circle(double x, double y, double r) {
        double xs = scaleX(x);
        double ys = scaleY(y);
        double ws = factorX(2*r);
        double hs = factorY(2*r);
        if (ws <= 1 && hs <= 1) pixel(x, y);
        else offscreen.draw(new Ellipse2D.Double(xs - ws/2, ys - hs/2, ws, hs));
        show();
    }


    /**
     * draw filled circle of radius r, centered on (x, y); degenerate to pixel if small
     * @param x
     * @param y
     * @param r
     */
    public void filledCircle(double x, double y, double r) {
        double xs = scaleX(x);
        double ys = scaleY(y);
        double ws = factorX(2*r);
        double hs = factorY(2*r);
        if (ws <= 1 && hs <= 1) pixel(x, y);
        else offscreen.fill(new Ellipse2D.Double(xs - ws/2, ys - hs/2, ws, hs));
        show();
    }

    /**
     * draw squared of side length 2r, centered on (x, y); degenerate to pixel if small
     * @param x
     * @param y
     * @param r
     */
    public void square(double x, double y, double r) {
        // screen coordinates
        double xs = scaleX(x);
        double ys = scaleY(y);
        double ws = factorX(2*r);
        double hs = factorY(2*r);
        if (ws <= 1 && hs <= 1) pixel(x, y);
        else offscreen.draw(new Rectangle2D.Double(xs - ws/2, ys - hs/2, ws, hs));
        show();
    }

    /**
     * draw squared of side length 2r, centered on (x, y); degenerate to pixel if small
     * @param x
     * @param y
     * @param r
     */
    public void filledSquare(double x, double y, double r) {
        // screen coordinates
        double xs = scaleX(x);
        double ys = scaleY(y);
        double ws = factorX(2*r);
        double hs = factorY(2*r);
        if (ws <= 1 && hs <= 1) pixel(x, y);
        else offscreen.fill(new Rectangle2D.Double(xs - ws/2, ys - hs/2, ws, hs));
        show();
    }

    
    public void rectangle(Point2D.Double topleft, Point2D.Double bottomright) {
    	double[] x = {scaleX(topleft.x), scaleX(bottomright.x)};
    	double[] y = {scaleY(topleft.y),scaleY(bottomright.y)};
    	offscreen.fill(new Rectangle2D.Double(x[0],y[0], x[1]-x[0], y[1]-y[0]));
        show();
    }
    /**
     * draw a polygon with the given (x[i], y[i]) coordinates
     * @param x
     * @param y
     */
    public void polygon(double[] x, double[] y) {
        int N = x.length;
        GeneralPath path = new GeneralPath();
        path.moveTo((float) scaleX(x[0]), (float) scaleY(y[0]));
        for (int i = 0; i < N; i++)
            path.lineTo((float) scaleX(x[i]), (float) scaleY(y[i]));
        path.closePath();
        offscreen.draw(path);
        show();
    }

    // draw a filled polygon with the given (x[i], y[i]) coordinates
    public void filledPolygon(double[] x, double[] y) {
        int N = x.length;
        GeneralPath path = new GeneralPath();
        path.moveTo((float) scaleX(x[0]), (float) scaleY(y[0]));
        for (int i = 0; i < N; i++)
            path.lineTo((float) scaleX(x[i]), (float) scaleY(y[i]));
        path.closePath();
        offscreen.fill(path);
        show();
    }


    // get an image from the given filename
    private Image getImage(String filename) {

        // to read from file
        ImageIcon icon = new ImageIcon(filename);

        // try to read from URL
        if ((icon == null) || (icon.getImageLoadStatus() != MediaTracker.COMPLETE)) {
            try {
                URL url = new URL(filename);
                icon = new ImageIcon(url);
            } catch (Exception e) { /* not a url */ }
        }

        // in case file is inside a .jar
        if ((icon == null) || (icon.getImageLoadStatus() != MediaTracker.COMPLETE)) {
            URL url = StdDraw.class.getResource(filename);
            if (url == null) throw new RuntimeException("image " + filename + " not found");
            icon = new ImageIcon(url);
        }

        return icon.getImage();
    }

    // draw picture (gif, jpg, or png) centered on (x, y)
    public void picture(double x, double y, String s) {
        Image image = getImage(s);
        double xs = scaleX(x);
        double ys = scaleY(y);
        int ws = image.getWidth(null);
        int hs = image.getHeight(null);
        if (ws < 0 || hs < 0) throw new RuntimeException("image " + s + " is corrupt");

        offscreen.drawImage(image, (int) Math.round(xs - ws/2.0), (int) Math.round(ys - hs/2.0), null);
        show();
    }

    // draw picture (gif, jpg, or png) centered on (x, y), rescaled to w-by-h
    public void picture(double x, double y, String s, double w, double h) {
        Image image = getImage(s);
        double xs = scaleX(x);
        double ys = scaleY(y);
        double ws = factorX(w);
        double hs = factorY(h);
        if (ws <= 1 && hs <= 1) pixel(x, y);
        else {
            offscreen.drawImage(image, (int) Math.round(xs - ws/2.0),
                                       (int) Math.round(ys - hs/2.0),
                                       (int) Math.round(ws),
                                       (int) Math.round(hs), null);
        }
        show();
    }



    // write the given text string in the current font, center on (x, y)
    public void text(double x, double y, String s) {
        offscreen.setFont(font);
        FontMetrics metrics = offscreen.getFontMetrics();
        double xs = scaleX(x);
        double ys = scaleY(y);
        int ws = metrics.stringWidth(s);
        int hs = metrics.getDescent();
        offscreen.drawString(s, (float) (xs - ws/2.0), (float) (ys + hs));
        show();
    }

    // display on screen and pause for t miliseconds
    public void show(int t) {
        defer = true;
        onscreen.drawImage(offscreenImage, 0, 0, null);
        frame.repaint();
        try { Thread.currentThread();
		Thread.sleep(t); }
        catch (InterruptedException e) { System.out.println("Error sleeping"); }
    }


    // view on-screen, creating new frame if necessary
    public void show() {
        if (!defer) onscreen.drawImage(offscreenImage, 0, 0, null);
        if (!defer) frame.repaint();
    }


    // save to file - suffix must be png, jpg, or gif
    public void save(String filename) {
        File file = new File(filename);
        String suffix = filename.substring(filename.lastIndexOf('.') + 1);

        // png files
        if (suffix.toLowerCase().equals("png")) {
            try { ImageIO.write(offscreenImage, suffix, file); }
            catch (IOException e) { e.printStackTrace(); }
        }

        // need to change from ARGB to RGB for jpeg
        // reference: http://archives.java.sun.com/cgi-bin/wa?A2=ind0404&L=java2d-interest&D=0&P=2727
        else if (suffix.toLowerCase().equals("jpg")) {
            WritableRaster raster = offscreenImage.getRaster();
            WritableRaster newRaster;
            newRaster = raster.createWritableChild(0, 0, width, height, 0, 0, new int[] {0, 1, 2});
            DirectColorModel cm = (DirectColorModel) offscreenImage.getColorModel();
            DirectColorModel newCM = new DirectColorModel(cm.getPixelSize(),
                                                          cm.getRedMask(),
                                                          cm.getGreenMask(),
                                                          cm.getBlueMask());
            BufferedImage rgbBuffer = new BufferedImage(newCM, newRaster, false,  null);
            try { ImageIO.write(rgbBuffer, suffix, file); }
            catch (IOException e) { e.printStackTrace(); }
        }

        else {
            System.out.println("Invalid image file type: " + suffix);
        }
    }


    // open a save dialog when the user selects "Save As" from the menu
    public void actionPerformed(ActionEvent e) {
        FileDialog chooser = new FileDialog(frame, "Use a .png or .jpg extension", FileDialog.SAVE);
        chooser.setVisible(true);
        String filename = chooser.getFile();
        if (filename != null) {
            save(chooser.getDirectory() + File.separator + chooser.getFile());
        }
    }

    Point2D.Double startPoint = new Point2D.Double(-1, -1); 
	Point2D.Double endPoint = new Point2D.Double(-1, -1);  
    public boolean mousePressed() { return mousePressed; }
    public boolean mouseDragged() { return mouseDragged; }
    public boolean mouseReleased() { return mouseReleased; }
    public double mouseX()        { return mouseX;       }
    public double mouseY()        { return mouseY;       }
    

    public void mouseClicked (MouseEvent e) { }
    public void mouseEntered (MouseEvent e) { }
    public void mouseExited  (MouseEvent e) { }
    public void mousePressed (MouseEvent e) {
    	System.out.println("mouse pressed");
    	
        mouseX = userX(e.getX());
        mouseY = userY(e.getY());
        mousePressed = true;
        mouseReleased = false;
        
        e.consume();  
        startPoint.x = mouseX;
        startPoint.y = mouseY;
        //this.point(startPoint.x, startPoint.y);
    }
    public void mouseReleased(MouseEvent e) { 
    	System.out.println("mouse released");
    	mouseX = userX(e.getX());
        mouseY = userY(e.getY());
    	mousePressed = false;
    	mouseDragged = false;
    	mouseReleased = true;
    	
    	e.consume();  
    	endPoint.x = mouseX ;
    	endPoint.y = mouseY;   
    	this.clear();
    	frame.repaint();
    	paint(this.offscreen);;
    	
    }
    public void mouseDragged(MouseEvent e)  {
    	System.out.println("mouse dragging");
    	
        mouseX = userX(e.getX());
        mouseY = userY(e.getY());
        mouseDragged = true;
        mouseReleased = false;
        
        e.consume();  
        endPoint.x = mouseX ;
    	endPoint.y = mouseY;    
    	
    	this.clear();
    	frame.repaint();
       	paint(this.offscreen);
    	//show();
    }

    public void mouseMoved(MouseEvent e) {
        mouseX = userX(e.getX());
        mouseY = userY(e.getY());
    }    
    public void paint(Graphics2D g) {  
        //Rectangle p;  
        /* Draw old rectangles. 
        for (int i=0; i < points.size(); i++) { 
           p = (Rectangle)points.elementAt(i); 
           g.drawRect(p.x, p.y, p.width-p.x, p.height-p.y); 
        } */
        /* Draw current rectangle.*/
    	//g.setColor(Color.YELLOW);
    	
    	System.out.println("execute paint");
    	
    	setPenRadius(0.003);
    	setPenColor(StdDraw.YELLOW);
    	//this.line(x0, y0, x1, y1)(endPoint.x, endPoint.y);
       if ((endPoint.x < startPoint.x) & (endPoint.y < startPoint.y)) 
        	rectangle(endPoint.x, endPoint.y, startPoint.x- endPoint.x, startPoint.y - endPoint.y);//offscreen.drawRect(endPoint.x, endPoint.y, startPoint.x- endPoint.x, startPoint.y - endPoint.y);
        else if (endPoint.x < startPoint.x)
        	rectangle(endPoint.x, startPoint.y, startPoint.x-endPoint.x, endPoint.y-startPoint.y);//offscreen.drawRect(endPoint.x, startPoint.y, startPoint.x-endPoint.x, endPoint.y-startPoint.y);
        else if (endPoint.y < startPoint.y)
        	rectangle(startPoint.x, endPoint.y, endPoint.x-startPoint.x, startPoint.y-endPoint.y);// .drawRect(startPoint.x, endPoint.y, endPoint.x-startPoint.x, startPoint.y-endPoint.y);
        else 
        	rectangle(startPoint.x, startPoint.y, endPoint.x-startPoint.x, endPoint.y-startPoint.y);//offscreen.drawRect(startPoint.x, startPoint.y, endPoint.x-startPoint.x, endPoint.y-startPoint.y);
        
        //show();
    }
    
}
