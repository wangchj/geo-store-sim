/**
 * 
 */
package hilbert;

/**
 * @author Ling
 *
 */
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;


public class MD5 {

    public static byte[] md5Converter(String strParam) {
        try {
            byte[] defaultBytes = strParam.getBytes();
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.reset();
            md.update(defaultBytes);
            byte messageDigest[] = md.digest();
            return messageDigest;
//            StringBuffer hexString = new StringBuffer();
//            for (int i = 0; i < messageDigest.length; i++) {
//                hexString.append(Integer.toHexString(0xFF & messageDigest[i]));
//            }
//            return hexString.toString();
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * 
     * @param obj
     * @return
     * @throws IOException
     * @throws NoSuchAlgorithmException
     * @throws NoSuchProviderException 
     */
    public static byte[] md5Converter(Object obj) throws IOException, NoSuchAlgorithmException, NoSuchProviderException {
    	
    	byte[] bytes = SpatialObject.getBytes(obj);
    	MessageDigest md = MessageDigest.getInstance("MD5");
        md.reset();
        md.update(bytes);
        byte messageDigest[] = md.digest();
        return messageDigest;
//        StringBuffer hexString = new StringBuffer();
//        for (int i = 0; i < messageDigest.length; i++) {
//            hexString.append(Integer.toHexString(0xFF & messageDigest[i]));
//        }
//        return hexString.toString();
    }
    /**
     * 
     * @param input
     * @return
     * @throws IOException
     * @throws NoSuchAlgorithmException
     */
    public static String md5Converter(byte[] input) throws IOException, NoSuchAlgorithmException { 
    	MessageDigest md = MessageDigest.getInstance("MD5");
        md.reset();
        md.update(input);
        byte messageDigest[] = md.digest();
        StringBuffer hexString = new StringBuffer();
        for (int i = 0; i < messageDigest.length; i++) {
            hexString.append(Integer.toHexString(0xFF & messageDigest[i]));
        }
        return hexString.toString();
    }
    public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
    	
    	SpatialObject so1 = new SpatialObject(3232, 342.3, 4343.2, 342, 4343, null, 'c');
    	SpatialObject so2 = new SpatialObject(3232, 342.1, 4343.2, 342, 4343, null, 'c');
    	String so3 = new String("here ");
    	
    	try {
    		System.out.println(md5Converter(so1).length);
			System.out.println(md5Converter(so2).length);
			System.out.println(md5Converter(so3).length);
			if (md5Converter(so2).equals(md5Converter(so1))) {
	    		System.out.println("same.....");
	    	} else {
	    		System.out.println("different.....");
	    	}
    	} catch (NoSuchProviderException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    }

}

