/**
 * 
 */
package hilbert;

import com.std.princeton.*;
/**
 * @author Ling
 *
 */
public class VisTool {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		

	}

}
