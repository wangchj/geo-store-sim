package hilbert;

import java.util.Comparator;

public class MaximalBlockComparator implements Comparator<MaximalBlock> {
	public int compare(MaximalBlock b1, MaximalBlock b2) {

		if ((b1.he < b2.hb)|| (b1.hb<b2.hb))
			return -1;
		return +1;
	}
}
