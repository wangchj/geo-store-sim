/**
 * 
 */
package hilbert;

import java.io.Serializable;
import java.util.HashMap;

/**
 * @author Ling
 *
 */
public class PointCnt implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3453955163303962799L;
	private int cnt ; 
	private HashMap<Long, Integer> hm = new HashMap<Long, Integer>();
	/**
	 * @param cnt
	 * @param hm
	 */
	public PointCnt(int cnt, HashMap<Long, Integer> hm) {
		super();
		this.cnt = cnt;
		this.hm = hm;
	}
	public int getCnt() {
		return cnt;
	}
	public HashMap<Long, Integer> getHm() {
		return hm;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public void setHm(HashMap<Long, Integer> hm) {
		this.hm = hm;
	}
	
	
}
