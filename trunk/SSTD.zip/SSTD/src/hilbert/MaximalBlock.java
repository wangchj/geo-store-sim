package hilbert;

public class MaximalBlock {
	long x;
	long y;
	long d;
	long hb;
	long he;
	

	/**
	 * 
	 * @param x
	 * @param y
	 * @param d
	 */
	MaximalBlock(long x, long y, int d) {
		this.x = x;
		this.y = y;
		this.d = d;

		this.hb = this.he = -1;
	}

	/**
	 * 
	 * @param x
	 * @param y
	 * @param d
	 * @param hb
	 * @param he
	 */
	MaximalBlock(long x, long y, long d, long hb, long he) {
		this.x = x;
		this.y = y;
		this.d = d;

		this.hb = hb;
		this.he = he;
	}
	
	public String toString () {
		return "Starting from cell (" + this.x + "," + this.y + ") with " + this.getNumberOfValues() + " values from "+ hb + " to " + he ;
		/*
		String ret = "";
		for (long i = hb ; i <= he ; i++) {
			ret += i + "\n";
		}
		return ret;
		*/
	}

	public long getX() {
		return x;
	}

	public long getY() {
		return y;
	}

	public long getD() {
		return d;
	}

	public long getHb() {
		return hb;
	}

	public long getHe() {
		return he;
	}
	
	public long getNumberOfValues () {
		return ((he - hb) + 1 );
	}

	public void setX(long x) {
		this.x = x;
	}

	public void setY(long y) {
		this.y = y;
	}

	public void setD(int d) {
		this.d = d;
	}

	public void setHe(long he) {
		this.he = he;
	}

	public void setHb(long hb) {
		this.he = hb;
	}
}