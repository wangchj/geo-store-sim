/**
 * 
 */
package hilbert;

import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;
import java.io.*;

/**
 * @author Ling
 *
 */
public class Utility {

	public static void bisearch(long[] sortedHibertValues) {
		
	}

	public static long getNumberOfGrids(int order) {
		return (long)Math.pow(2, order * 2) ; 
	}
	
	public static double log2(double a) {
		return (Math.log(a)/Math.log(2));
	}
	public static void drawGrid(StdDraw draw, int in) {
		int gridSize = in;

		for (int i = 0; i <= gridSize; i++) {
			draw.setPenColor(StdDraw.LIGHT_GRAY);
			draw.setPenRadius(0.0005);
			//if (i == 8 || i == 12 || i == 4)
			//StdDraw.setPenRadius(0.005);
			//if (i == 12 || i == 4)
				//StdDraw.line(i, 0, i, max / 2);
			//else
			draw.line(i, 0, i, 4);
			if (i < gridSize)
				draw.text(i + 0.5, -0.2, Integer.toString(i));
		}
		
		for (int i = 0; i <= gridSize; i++) {
			draw.setPenRadius(0.0005);
			//if (i == 8 || i == 4)
			//	StdDraw.setPenRadius(0.005);
			draw.line(0, i, 4, i);
			if (i < gridSize)
				draw.text(-0.2, i + 0.5, Integer.toString(i));
		}
	}
	
	public static void storeBinToFile(String file, Map<Long, Vector<SpatialObject>> sortedMap) {
		try {
			FileOutputStream fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(sortedMap);
			oos.close();
			fos.close();
		} catch (IOException e) {
			System.out.println("Exception when serializing object.");
			e.printStackTrace();
		}
	}
	
	public static void storeBinToFile2(String file, HashMap<Long, PointCnt> hashMap) {
		try {
			FileOutputStream fos = new FileOutputStream(file);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(hashMap);
			oos.close();
			fos.close();
		} catch (IOException e) {
			System.out.println("Exception when serializing object.");
			e.printStackTrace();
		}
	}
	
	public static Range[] generateRangeQuery(int main, int dual) {
		//Point2D.Double geo = new Point2D.Double()
		//Hilbert.geo2Grid(, order)
		long x = (long) ((long)Math.pow(2, dual)* Constant.generator.nextDouble()) ;//1512 ; //1005724;//7861;//
		long y = (long)((long)Math.pow(2, dual)* Constant.generator.nextDouble()) ; //2914 ; //586130; // 3227;//
		//System.out.println("Hilbert value = 63038055 &" + Hilbert.computeIndex(Constant.N1, x, y));
		long step = (long) (0.01 * (Math.pow(2, dual))); //1% of the data
		long stepx = step*5;//100 ; //1005891-1005724;//(int) (10 *  (Constant.generator.nextDouble()+1)) ;
		long stepy = step*5;//80 ; //14907-586130;//(int) (10 *  (Constant.generator.nextDouble())+1) ;
		
		//transformed query range in main map
		double scale = Math.pow(2, main - dual);
		long x0 = (long) (x * scale);
		long y0 = (long) (y * scale);
		long stepx0 = (long) (stepx * scale);
		long stepy0 = (long) (stepy * scale);
		
		Range m = new Range(x0, y0, stepx0, stepy0);
		Range d = new Range(x, y, stepx, stepy);
		
		//temp
		Constant.range =  new Range(x, y, stepx, stepy);
		
		Range[] ret = new Range[2];
		ret[0] = m;
		ret[1] = d;
		return ret;
		
	}
	public static void printVector(Vector<SpatialObject> vos2) {
		for (Iterator<SpatialObject> it1 = vos2.iterator() ; it1.hasNext() ; ) {
			System.out.println(it1.next());
		}
	}
	
	public static void printVector(Vector<SpatialObject> vos2, BufferedWriter bw) throws IOException{
		for (Iterator<SpatialObject> it1 = vos2.iterator() ; it1.hasNext() ; ) {
			bw.write(it1.next()+"\n");
		}
	}
	@SuppressWarnings("unchecked")
	public static Map<Long, Vector<SpatialObject>> restoreFileFromBin (String file) {
		Map<Long, Vector<SpatialObject>> ret = new HashMap<Long, Vector<SpatialObject>>();
		try {
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			ret = (Map<Long, Vector<SpatialObject>>) (ois.readObject());
			ois.close();
			fis.close();
		} catch (IOException e) {
			System.out.println("IOException when de-serializing object.");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("ClassNotFoundException when serializing object.");
			e.printStackTrace();
		}
		return ret;
	}
	
	@SuppressWarnings("unchecked")
	public static HashMap<Long, PointCnt> restoreFileFromBin2 (String file) {
		HashMap<Long, PointCnt> ret = new HashMap<Long, PointCnt>();
		try {
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			ret = (HashMap<Long, PointCnt>) (ois.readObject());
			ois.close();
			fis.close();
		} catch (IOException e) {
			System.out.println("IOException when de-serializing object.");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("ClassNotFoundException when serializing object.");
			e.printStackTrace();
		}
		return ret;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		for (int i = 0; i < 10; i ++) {
			long x = (long) ((long)Math.pow(2, 13)* Constant.generator.nextDouble());
			long y = (long) ((long)Math.pow(2, 13)* Constant.generator.nextDouble());
			System.out.println(x + " " + y + " 63 63");	
		}
		
		System.exit(0);
		
		String str1 = "any string", str2="any  string";
		System.out.println(util.MD5.md5Converter(str1));
		if (util.MD5.md5Converter(str2).equals(util.MD5.md5Converter(str1))) {
			System.out.println("same signatures.");
		}
		
		double t = Math.pow(2, 66);
		long temp = (long)Math.pow(2, 64);
		System.out.println( t + "2^25  = " + temp );
		System.out.println( "Max Long = " + Long.MAX_VALUE);
		System.out.println(Utility.log2(Long.MAX_VALUE));
		System.exit(0);
		Constant.PATH = "D:\\Datasets\\NorthAmerica\\";
		Constant.ORIGINALDATA = Constant.PATH + "na.txt";
		Constant.FILTEREDDATA = Constant.PATH + "filtered.txt";
		try {
	        BufferedReader in = new BufferedReader(new FileReader(Constant.ORIGINALDATA));
	        BufferedWriter out = new BufferedWriter(new FileWriter(Constant.FILTEREDDATA));
	        String str;
	        String[] coordinate = new String[2];
	        double minx=5419, maxx=-1, miny=3555, maxy=-1;
	        while ((str = in.readLine()) != null) {
	        	coordinate = str.split("\\s");
	            double lat = Double.parseDouble(coordinate[1]);
	            double lng = Double.parseDouble(coordinate[3]);
	            if (lat < minx) minx = lat;
	            if (lat > maxx) maxx = lat;
	            if (lng < miny) miny = lng;
	            if (lng > maxy) maxy = lng;
	            //if ((lng>=0) && (lng<=10000) && (lat>=0) && (lat<=10000))
	            {
					out.write(Double.toString(lat)+","+Double.toString(lng)+"\n");
				}				        
			}
	        System.out.println("finished processing.");
	        System.out.println("minx = " + minx + " maxx = " + maxx);
	        System.out.println("miny = " + miny + " maxy = " + maxy);
	        in.close();
	        out.close();
	    } catch (IOException e) {
			System.out.println("Error reading file");
            System.exit(1);
	    }
	    
		
		
		double x1 = 3;
		double y1 = 4;
		System.out.println("0=" + Long.toBinaryString(0));
		System.out.println("6896=" + Long.toBinaryString(6896));
		/*
		Point2D.Double tmp = Hilbert.grid2Geo(new Point2D.Double(x1,y1), Constant.N1);
		System.out.println("cell  " + tmp.x + "," + tmp.y);
		
		tmp = Hilbert.geo2Grid(Hilbert.grid2Geo(new Point2D.Double(x1,y1), Constant.N1), Constant.N2) ;
		System.out.println("cell  " + tmp.x + "," + tmp.y);
		
		System.out.println("result of Log2(128)=" + log2(10));
		StdDraw s = new StdDraw(800, 800, "test");
		
        //s.square(.2, .8, .1);
        //s.filledSquare(.8, .8, .2);
        s.circle(.8, .2, .2);
		//s.rectangle(Point2D.Double(), Point2D.Double(400,450));
        // draw a blue diamond
        s.setPenColor(StdDraw.BLUE);
        double[] x = { .1, .2, .3, .2 };
        double[] y = { .2, .3, .2, .1 };
        //s.filledPolygon(x, y);
        
        //s.rectangle(.8, .8, .1, .1);
        //HilbertRange.useMouse(s);

        // text
        s.text(0.8, 0.2, "centered");
        */
        
		/*System.out.println("random number test");
		long[] a = new long[2];
		TimerStart(a);
		System.out.println();
		int tmp ;
		int cnt0 = 0, cnt1 = 0, cnt2 = 0, cnt3 = 0, cnt4 = 0, cnt5 = 0;
		for (int i = 0;i < Constant.totalPOI;i++) {
			tmp = ((int)(10 * Constant.generator.nextDouble()));
			System.out.println(tmp);
			if (tmp == 0) cnt0 ++;
			if (tmp == 1) cnt1 ++;
			if (tmp == 2) cnt2 ++;
			if (tmp == 3) cnt3 ++;
			if (tmp == 4) cnt4 ++;
			if (tmp == 5) cnt5 ++;
		}
		System.out.println("Percentage: " + (double) (cnt0*1.00000/Constant.totalPOI));
		System.out.println("Percentage: " + (double) (cnt1*1.00000/Constant.totalPOI));
		System.out.println("Percentage: " + (double) (cnt2*1.00000/Constant.totalPOI));
		System.out.println("Percentage: " + (double) (cnt3*1.00000/Constant.totalPOI));
		System.out.println("Percentage: " + (double) (cnt4*1.00000/Constant.totalPOI));
		System.out.println("Percentage: " + (double) (cnt4*1.00000/Constant.totalPOI));
		
		System.out.println("time cost = "+TimerEnd(a));
		String m = new String();
		m = getStringFromUser("Please input something here to continue the program....");
		System.out.println("Here is what the user inputted.");
		System.out.println(m);*/
	}
	/*
	 * get String or simply enter
	 */
	public static String getStringFromUser(String msg)
	{
	String str="";
	try
	{
		System.out.print(msg);
		str = new BufferedReader(new InputStreamReader(System.in)).readLine();
	}
	catch (IOException e)
	{
	// TODO do exception handling
	}
	return str ;
	} 
	/**
	 * example of using timer
	 * long[] a = new long[2];
	 * TimerStart(a);
	 * *************
	 * TimerEnd(a);
	 * @param time
	 */
	public static void TimerStart(long[] time) {
		time[0] = System.currentTimeMillis();
		time[1] = System.currentTimeMillis();
		time[2] = 0; //accumulated time;
	}
	/**
	 * 
	 * @param time
	 * @param count - if true, count in the time interval between TimerEnd and last TimerPause
	 * @return
	 */
	public static long TimerEnd(long[] time, boolean count) {
		//time[1] = System.currentTimeMillis();
		//long diff = time[1]-time[0];
		//time[2] = time[2] + diff; //accumulated time;
		//System.out.println("Time cost in Milliseconds = " + diff);
		if (count) {
			time[1] = System.currentTimeMillis();
			time[2] += (time[1] - time[0]);
		}
		//System.out.println("Time cost in Milliseconds = " + time[2]);
		System.out.print(time[2] + "\t");
		return time[2];
	}
	public static void TimerPause(long[] time) {
		time[1] = System.currentTimeMillis();
		long diff = time[1]-time[0];
		time[2] += diff; //accumulated time;
	}
	public static void TimerResume(long[] time) {
		time[0] = System.currentTimeMillis();
	}
	
	public static String millisecondsToString(long milliTime){
	    int milliseconds = (int)(milliTime % 1000);
	    int seconds = (int)((milliTime/1000) % 60);
	    int minutes = (int)((milliTime/60000) % 60);
	    int hours = (int)((milliTime/3600000) % 24);
	    String millisecondsStr = (milliseconds<10 ? "00" : (milliseconds<100 ? "0" : ""))+ milliseconds;
		String secondsStr = (seconds<10 ? "0" : "")+ seconds;
		String minutesStr = (minutes<10 ? "0" : "")+ minutes;
		String hoursStr = (hours<10 ? "0" : "")+ hours;
		return new String(hoursStr + ":" + minutesStr + ":" + secondsStr + "." + millisecondsStr);
	}

	
}
