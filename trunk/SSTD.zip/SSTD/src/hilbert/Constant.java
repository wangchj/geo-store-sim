package hilbert;

import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
/**
 * Constant values for the program
 */
import java.util.Vector;

/**
 * @author Ling
 *
 */
public final class Constant {
	public static Random generator = new Random();
	
	//be aware that N1 is always greater than N2 because more data points
	//but range given should be measured on the second curve, which has large granularity 
	
	/*Synthetic Uniform  
	 private static double minLat=33.760000;
    private static double maxLat=34.150000;
    private static double minLng=-118.400163;
    private static double maxLng=-117.932000;
    public static String PATH = "D:\\Datasets\\Uniform\\";
    public static int N1 = 15; 
	public static int N2 = 13; 
	
	*/
	/*Synthetic Skewed  
	 private static double minLat=33.760000;
   private static double maxLat=34.150000;
   private static double minLng=-118.400163;
   private static double maxLng=-117.932000;
   public static String PATH = "D:\\Datasets\\Skewed\\";
   public static int N1 = 15; 
	public static int N2 = 13; 
	*/
	
    /* Los Angeles*/
	
    private static double minLat=33.760000;
    private static double maxLat=34.150000;
    private static double minLng=-118.400163;
    private static double maxLng=-117.932000;
    public static String PATH = "D:\\Datasets\\LosAngeles\\";
    public static int N1 = 6; 
	public static int N2 = 6; 
	/* California*/
//    private static double minLat=0;
//    private static double maxLat=10000;
//    private static double minLng=0;
//    private static double maxLng=10000; 
//    public static String PATH = "D:\\Datasets\\California\\";
//    public static int N1 = 12; 
//	public static int N2 = 10; 
	
	/* NorthAmerica -- current config will overflow */
//    private static double minLat = 151.434464;
//    private static double maxLat = 10022.386719;
//    private static double minLng = 2366.826904;
//    private static double maxLng = 7105.509766;
//    public static String PATH = "D:\\Datasets\\NorthAmerica\\";
//	public static int N1 = 15; 
//	public static int N2 = 13;  

	public static Point2D.Double min = new Point2D.Double(minLat, minLng);
	public static Point2D.Double max = new Point2D.Double(maxLat, maxLng);
	 
	public static int ScreenSize = 800;
	/**
	 * Curve order!
	 */
	
	
	
	public static String ORIGINALDATA = PATH + "realdata_lat_lng.txt";
	public static String FILTEREDDATA = PATH + "filtered.txt";
	public static String FILTEREDDUALDATA = PATH + "filtereddual.txt";
	public static String SCALEDDATA = PATH + "scaled.txt";
	public static String SCALEDDUALDATA = PATH + "scaleddual.txt"; //the file was originally used to store the dual hilbert curve, we use it for dual data now.
	public static String HILBERTINDEXED = PATH + "hilbertindexed.txt";
	public static String DUALHILBERTINDEXED = PATH + "dualhilbertindexed.txt";
	
	public static double DUALRATE =40 ;
	public static String PRIMARY = PATH + "primaryDB" + DUALRATE + ".bin";
	public static String SECONDARY = PATH + "secondaryDB" + DUALRATE + ".bin";
	public static String STORAGE = PATH + "SORTEDDB-R" + DUALRATE + "-O" + N1 + "-O" + N2 + ".bin";
	
	/**
	 * ratio of dual data
	 * Default = 10%
	 */
	
	/**
	 * total number of POIs
	 * Default = 10160
	 * updated when read in the data set
	 */
	public static long totalPOI = 10160;
	public static long dualPOI = 0;
	
	public static HashMap<Long, Vector<SpatialObject>> primary = new HashMap<Long, Vector<SpatialObject>>(15000);
	public static ArrayList<SpatialObject> primaryArray = new ArrayList<SpatialObject>();
	public static HashMap<Long, Vector<SpatialObject>> secondary = new HashMap<Long, Vector<SpatialObject>>(1800);
	public static ArrayList<SpatialObject> secondaryArray = new ArrayList<SpatialObject>();
	public static boolean combine = true; //put primary and secondary in one data structure
	
	//temp
	public static Range range = new Range(1,1,1,1);
}
