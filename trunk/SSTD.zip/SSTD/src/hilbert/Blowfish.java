package hilbert;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.swing.JOptionPane;

/**
 * This program demonstrates how to encrypt/decrypt input
 * using the Blowfish Cipher with the Java Cryptograhpy.
 *
 */
public class Blowfish {
	
	private SecretKey secretkey;
	private  Cipher cipher ;
	
	

  /**
	 * @param secretkey
 * @throws NoSuchAlgorithmException 
 * @throws NoSuchPaddingException 
 * @throws InvalidKeyException 
	 */
	public Blowfish() throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException {
		super();
		KeyGenerator keygenerator = KeyGenerator.getInstance("Blowfish");
		this.secretkey = keygenerator.generateKey();
		// create a cipher based upon Blowfish
	    this.cipher = Cipher.getInstance("Blowfish");
	    cipher.init(Cipher.ENCRYPT_MODE, this.secretkey);
	}

	

	/**
	 * @param secretkey
	 */
	public Blowfish(SecretKey secretkey) {
		super();
		this.secretkey = secretkey;
	}

	public byte[] encrypt(byte[] input) throws IllegalBlockSizeException, BadPaddingException {

		return cipher.doFinal(input);
		
	}

	public static byte[] decrypt(SecretKey key, byte[] cipherText) throws NoSuchAlgorithmException, 
		NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance("Blowfish");
		cipher.init(Cipher.DECRYPT_MODE, key);
		return cipher.doFinal(cipherText);
	}
	
	public SecretKey getSecretKey() {
		return this.secretkey;
	}
	
public static void main(String[] args) throws Exception {

    // create a key generator based upon the Blowfish cipher
    KeyGenerator keygenerator = KeyGenerator.getInstance("Blowfish");

    // create a key
    SecretKey secretkey = keygenerator.generateKey();

    // create a cipher based upon Blowfish
    Cipher cipher = Cipher.getInstance("Blowfish");

    // initialise cipher to with secret key
    cipher.init(Cipher.ENCRYPT_MODE, secretkey);

    // get the text to encrypt
    //String inputText = JOptionPane.showInputDialog("Input your message: ");
    SpatialObject so = new SpatialObject(19232, 8923.32, 23432.34, 8923,23432, null, 'a');
	byte[] bytes = SpatialObject.getBytes(so);
	String str = new String(bytes);
	System.out.println("Binary="+str);
	
    // encrypt message
    byte[] encrypted = cipher.doFinal(bytes);
    str = new String(encrypted);
    System.out.println("Encrypted="+str);
    //decryption
    
    // re-initialise the cipher to be in decrypt mode
    cipher.init(Cipher.DECRYPT_MODE, secretkey);

    // decrypt message
    byte[] decrypted = cipher.doFinal(encrypted);
    SpatialObject s = SpatialObject.getObject(decrypted);
	System.out.println("Decrypted SpatialObject="+s.toString());
    // and display the results
    //JOptionPane.showMessageDialog(JOptionPane.getRootFrame(),
    //                              "encrypted text: " + new String(encrypted) + "\n" +
    //                              "decrypted text: " + new String(decrypted));

    // end example
    System.exit(0);
  }
}