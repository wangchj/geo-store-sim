/**
 * 
 */
package hilbert;

/**
 * @author Ling
 *
 */
public class HilbertPOI {
	private long hilbertIndex;
	private double[] att = new double[5];
	
	public HilbertPOI() {
	}
	/**
	 * @param hilbertIndex
	 * @param att
	 */
	public HilbertPOI(long hilbertIndex, double[] att) {
		this.hilbertIndex = hilbertIndex;
		this.att = att;
	}
	public long getHilbertIndex() {
		return hilbertIndex;
	}
	public double[] getAtt() {
		return att;
	}
	
	public String toString() {
		return (hilbertIndex + "," + att[0] + "," + att[1] + "," + att[2] + "," + att[3] + "," + att[4] + "\n");
	}
	

}
