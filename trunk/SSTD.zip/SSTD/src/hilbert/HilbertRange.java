/*
 * Author: Houtan Shirani-Mehr
 */
package hilbert;

import java.awt.Color;
import java.awt.Font;
import java.awt.geom.Point2D;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Vector;

public class HilbertRange {

	
	//curve order 
	public int curverOrder ;
	// x coordinate of the lower left corner
	private long x;

	// y coordinate of the lower left corner
	private long y;

	// Height of the Window query
	private long n1;

	// Width of the window query
	private long n2;

	// A vector containing the maximal blocks before the merge
	private Vector<MaximalBlock> maximalBlocks = new Vector<MaximalBlock>();

	// A vector containing the final maximal quad tree blocks
	private Vector<MaximalBlock> finalRuns = new Vector<MaximalBlock>();

	// Used in the coloring phase
	private int currColor = 0;

	/**
	 * size of the underlying grid is max*max
	 */
	private int max = (int) Math.pow(2, curverOrder);//16384;

	// Size of the range query (n1 and n2)
	// This values should be reasonably small relative to the size of the grid
	// for the experiments
	static long experimentN1 = 0;
	static long experimentN2 = 0;

	private static int intervalBeginning = -1;
	private static int intervalEnd = -1;

	private static double numExps = 5000;

	static int numNegative = 0;
	static int numPositives = 0;

	// hb and he are the beginning and the ending Hilbert values of a
	// run in a quad-tree block
	private long hb = -1;

	// hb and he are the beginning and the ending Hilbert values of a
	// run in a quad-tree block
	private long he = -1;

	private BufferedWriter out;
	private BufferedWriter outAll;

	/**
	 * @param curverOrder
	 */
	public HilbertRange(int curverOrder) {
		super();
		this.curverOrder = curverOrder;
	}

	public static void main(String args[]) throws Exception {

		HilbertRange hr = new HilbertRange(4);
		StdDraw s = new StdDraw(800, 800, "Main");
		s.setXscale(0, Math.pow(2, 4));
		s.setYscale(0, Math.pow(2, 4));

		// Used for drawing the grid
		Hilbert.drawGrid(s, (int)(Math.pow(2, hr.curverOrder)));
		while (!s.mousePressed()) {}
		
		//runMultipleExperiments();

		// setXYforDualShift(false, true, x, y, n1);
		// runRossoupolus(x, y, n1, n2);
		//hr.getRangeQueryHilbertValues(1,4,4,6);
		//hr.printMaximalBlocks(hr.maximalBlocks);
		//while (!s.mousePressed()) {}
		

		//System.out.println("Number of runs:" + hr.finalRuns.size());

		//hr.drawRuns(s, (long)(Math.pow(2, hr.curverOrder)));
		//while (!s.mousePressed()) {}
		System.exit(0);
	}
	
	public static Vector<SpatialObject> kNNQuery(HashMap<Long, Vector<SpatialObject>> storage, int k, long queryPtHValue) {
		Vector<SpatialObject> ret = new Vector<SpatialObject>();
		if (k % 2 == 0) {
			//get hvalue from queryPtHValue
		} else {
			
		}
		return ret;
	}
	
	
	/**
	 * This is the query running on server
	 * @param storage
	 * @param maximalBlocks
	 * @return
	 */
	public static Vector<SpatialObject> rangeQuery(Map<Long, Vector<SpatialObject>> storage, Vector<MaximalBlock> maximalBlocks) {
		Vector<SpatialObject> ret = new Vector<SpatialObject>();
		for (Iterator<MaximalBlock> it = maximalBlocks.iterator() ; it.hasNext(); ) {
			MaximalBlock mb = it.next() ; 
			for (long l = mb.hb ; l <= mb.he ; l ++) {
				Vector<SpatialObject> so = storage.get(l);
				if (so != null) ret.addAll(so);
			}
		}
		//if (ret.size() == 0) System.out.println("result set is empty...");
		//else System.out.println("result set size = " + ret.size());
		return ret;
	}

	/*
	public static long[] getRangeQueryHilbertValues(Range range, int curveOrder) {
		long[] ret = new long[range.getStepx()*range.getStepy()];
		int k = 0;
		for (long i = range.getX() ; i < range.getX()+range.getStepx() ; i++) {
			for (long j = range.getY() ; j < range.getY()+range.getStepy() ; j++) {
				long a = Hilbert.computeIndex(Constant.N1, i, j);
				ret[k] = a;
				k++;
			}
		}
		return ret;
	}
	*/
	public static long[] getRangeQueryHilbertValues(Vector<MaximalBlock> vmbs) {
		int cnt = 0; //maybe problem if query range is tooooo large.
		for (Iterator<MaximalBlock> it = vmbs.iterator() ; it.hasNext() ; ) {
			cnt += it.next().getNumberOfValues();
		}
		long[] ret = new long[cnt];
		int i = 0;
		for (Iterator<MaximalBlock> it = vmbs.iterator() ; it.hasNext() ; ) {
			MaximalBlock mb = it.next();
			long val = mb.getHb();
			while (val <= mb.getHe()) {
				ret[i] = val;
				val ++;
				i ++;
			} 
		}
		System.out.println("Number of values : " + ret.length);
		for (i = 0; i < ret.length; i++) {
			System.out.println(ret[i]);
		}
		return ret;
	}
	
	public Vector<MaximalBlock> getRangeQueryHilbertValues(Range r) throws InterruptedException {
		return getRangeQueryHilbertValues(r.getX(), r.getY(), r.getStepx(), r.getStepy()); // be careful on the order of the last 2 parameters
		/*
		printMaximalBlocks(finalRuns);
		System.out.println("# of runs = " + finalRuns.size());
		return finalRuns;
		*/
	}
	
	/**
	 * Ask a range query and get the results in a vector.
	 * 
	 * @param intX - starting cell on x-axis
	 * @param intY - starting cell on y-axis 
	 * @param sizeX - size on x-axis
	 * @param sizeY - size on y-axis
	 */
	private Vector<MaximalBlock> getRangeQueryHilbertValues(long intX, long intY, long sizeX, long sizeY) {
		rangeQuery(intX, intY, sizeY, sizeX); // be careful on the order of the last 2 parameters
		return finalRuns;
	}
	/**
	 * ask a range query, don't call this directly, use getRangeQueryHilbertValues instead
	 * @param inX - starting cell on x-axis
	 * @param inY - starting cell on y-axis 
	 * @param inN1 - size on y-axis
	 * @param inN2 - size on x-axis (weird, I know.)
	 */
	private Vector<MaximalBlock> rangeQuery(long inX, long inY, long inN1, long inN2) {
		maximalBlocks.clear();
		finalRuns.clear();

		x = inX;
		y = inY;
		long savedX = x;
		long savedY = y;

		n1 = inN1;
		n2 = inN2;
		long savedN1 = n1;
		long savedN2 = n2;

		decomposer();
		try {
			//printMaximalBlocks(maximalBlocks);
		} catch (Exception e) {
			
		}
		n1 = savedN1;
		n2 = savedN2;
		x = savedX;
		y = savedY;

		Collections.sort(maximalBlocks, new MaximalBlockComparator());
		try {
			//printMaximalBlocks(maximalBlocks);
		} catch (Exception e) {
			
		}
		merge();
		try {
			//printMaximalBlocks(finalRuns);
		} catch (Exception e) {
			
		}
		return finalRuns;
	}
	
	/**
	 * get an random number
	 * @param idx
	 * @return
	 */
    private long roll(long idx) {
    	//dont use new Random everytime, because it will generate the same random numbers.
	    double randomIndex = Constant.generator.nextDouble();
	    // multiply by number of points so it's now between 0 and number of points
	    randomIndex *= idx;
	    //truncate it to an int
	    //randomIndex = Math.floor(randomIndex);
	    // convert to an long and return
	    return (long) (Math.floor(randomIndex));
	  }
    
    /**
     * The function will merge the consecutive Hilbert values of the sorted
	 * maximalBlocks and will fill the vector finalRuns. Each element of the
	 * finalRuns will be passed to the server as a single query
     */
    private void merge() {
		int j = 0;
		int i = 0;
		while (i < maximalBlocks.size()) {
			// A gap of 1 is seen so we should merge the maximal blocks
			j = i + 1;
			while ((j < maximalBlocks.size())
					&& (maximalBlocks.elementAt(i).he + 1 == maximalBlocks
							.elementAt(j).hb)) {
				maximalBlocks.elementAt(i).setHe(maximalBlocks.elementAt(j).he);
				j++;
			}

			finalRuns.add(maximalBlocks.elementAt(i));
			// move forward to j--
			i = j;
		}
	}

	/*
	 * Only used to print a vector of blocks. Note that a block is not
	 * necessarily a quad-tree block
	 */
	public void printMaximalBlocks(Vector<MaximalBlock> inVec)
			throws InterruptedException {
		for (int i = 0; i < inVec.size(); i++) {
			System.out.println(inVec.elementAt(i).toString());
					/*
					inVec.elementAt(i).getX() + ","
					+ inVec.elementAt(i).getY() + ","
					+ inVec.elementAt(i).getD() + ", hb:"
					+ inVec.elementAt(i).getHb() + ", he:"
					+ inVec.elementAt(i).getHe());
					*/

			// Only draw the maximalBlocks
			//if (inVec == maximalBlocks)
				//drawMaximalBlock(inVec.elementAt(i), w);
		}
	}

	/**
	 * Draw a in-by-in grid.
	 * @param in
	 */
	//@SuppressWarnings("unused")
	/*private static void drawGrid(int in) {
		int gridSize = in;

		for (int i = 0; i <= gridSize; i++) {
			StdDraw.setPenColor(StdDraw.BLACK);
			StdDraw.setPenRadius(0.0005);
			//if (i == 8 || i == 12 || i == 4)
			//StdDraw.setPenRadius(0.005);
			//if (i == 12 || i == 4)
				//StdDraw.line(i, 0, i, max / 2);
			//else
			StdDraw.line(i, 0, i, max);
			if (i < gridSize)
				StdDraw.text(i + 0.5, -0.2, Integer.toString(i));
		}
		
		while (!StdDraw.mousePressed()) {
		}
		for (int i = 0; i <= gridSize; i++) {
			StdDraw.setPenColor(StdDraw.BLACK);
			StdDraw.setPenRadius(0.0005);
			//if (i == 8 || i == 4)
			//	StdDraw.setPenRadius(0.005);
			StdDraw.line(0, i, max, i);
			if (i < gridSize)
				StdDraw.text(-0.2, i + 0.5, Integer.toString(i));
		}
		while (!StdDraw.mousePressed()) {
		}

		/*
		StdDraw.setPenRadius(0.005);
		StdDraw.line(10, 6, 12, 6);
		while (!StdDraw.mousePressed()) {
		}
		StdDraw.line(10, 7, 12, 7);
		while (!StdDraw.mousePressed()) {
		}
		StdDraw.line(10, 5, 12, 5);
		while (!StdDraw.mousePressed()) {
		}
		
	}*/

	/*
	 * 
	 * 
	 */
	/**
	 * Algorithm of a paper is implemented here to decompose window query to its maximal quad-tree blocks
	 */
	private void decomposer() {
		long k = 1;
		// while the window is not null
		while (n1 > 0 && n2 > 0) {
			vl(k);
			ht(k);
			vr(k);
			hb(k);

			k++;
		}
	}

	/*
	 * Returns x mod 2^k
	 */
	private long F(long x, long k) {
		return (long) (x % (Math.pow(2, k)));
	}

	private void vl(long k) {
		if (F(x, k) != 0) {
			long numIterations = (int) (n1 / Math.pow(2, k - 1));
			long j = 0;
			for (long i = 0; i < numIterations; i++) {
				calculateHilbert(x, y + j, (long) Math.pow(2, k - 1));
				maximalBlocks.add(new MaximalBlock(x, y + j, (long) Math.pow(2,
						k - 1), hb, he));
				j = (long) (j + Math.pow(2, k - 1));
			}

			x = (long) (x + Math.pow(2, k - 1));
			n2 = (long) (n2 - Math.pow(2, k - 1));
		}
	}

	private void ht(long k) {
		if (F(y, k) != 0) {

			long numIterations = (long) (n2 / Math.pow(2, k - 1));
			long j = 0;
			for (long i = 0; i < numIterations; i++) {
				calculateHilbert(x + j, y, (long) Math.pow(2, k - 1));
				maximalBlocks.add(new MaximalBlock(x + j, y, (long) Math.pow(2,
						k - 1), hb, he));
				j = (long) (j + Math.pow(2, k - 1));
			}

			y = (long) (y + Math.pow(2, k - 1));
			n1 = (long) (n1 - Math.pow(2, k - 1));
		}
	}

	private void vr(long k) {
		if (F(x + n2, k) != 0) {

			long numIterations = (long) (n1 / Math.pow(2, k - 1));
			long j = 0;
			for (long i = 0; i < numIterations; i++) {
				calculateHilbert((long) (x + n2 - Math.pow(2, k - 1)), y + j,
						(long) Math.pow(2, k - 1));
				maximalBlocks.add(new MaximalBlock((long) (x + n2 - Math.pow(2,
						k - 1)), y + j, (long) Math.pow(2, k - 1), hb, he));
				j = (long) (j + Math.pow(2, k - 1));
			}

			n2 = (long) (n2 - Math.pow(2, k - 1));
		}
	}

	private void hb(long k) {
		if (F(y + n1, k) != 0) {

			long numIterations = (long) (n2 / Math.pow(2, k - 1));
			long j = 0;
			for (long i = 0; i < numIterations; i++) {
				calculateHilbert(x + j, (long) (y + n1 - Math.pow(2, k - 1)),
						(long) Math.pow(2, k - 1));
				maximalBlocks.add(new MaximalBlock(x + j, (long) (y + n1 - Math
						.pow(2, k - 1)), (long) Math.pow(2, k - 1), hb, he));
				j = (long) (j + Math.pow(2, k - 1));
			}
			n1 = (long) (n1 - Math.pow(2, k - 1));
		}
	}

	/**
	 * Used for the drawing of maximal quad tree blocks
	 * @param inBlock
	 */
	private void drawMaximalBlock(MaximalBlock inBlock, StdDraw w) {

		double[] xArr = { inBlock.x, (double) inBlock.x + (double) inBlock.d,
				(double) inBlock.x + (double) inBlock.d, inBlock.x };
		double[] yArr = { inBlock.y, inBlock.y,
				(double) inBlock.y + (double) inBlock.d,
				(double) inBlock.y + (double) inBlock.d };

		Color c = new Color(Color.HSBtoRGB(currColor
				/ (float) maximalBlocks.size(), 1, 1));

		currColor = currColor + 10;

		if (currColor > 250)
			currColor = 0;

		w.setPenColor(c);
		w.setPenRadius(0.0038);
		w.filledPolygon(xArr, yArr);

		w.setPenColor(StdDraw.BLACK);
		w.polygon(xArr, yArr);
	}

	public long getHilbert (int order, long x, long y) {
		curverOrder = order; 
		return calculateHilbert(x, y, 1);
		
	}
	/**
	 * Calculate the minimum and the maximum Hilbert value inside a window of
	 * the size s*s where its origin is located at the point (x,y)
	 * @param x
	 * @param y
	 * @param s
	 * @return
	 */
	public long calculateHilbert(long x, long y, long s) {
		int logS = (int) (Math.log(s) / Math.log(2));

		int r = curverOrder ; //(int) (Math.log(max) / Math.log(2));
		long mask = (1 << r) - 1;
		long heven = x ^ y;
		long notx = ~x & mask;
		long noty = ~y & mask;
		long temp = notx ^ y;
		long v1 = 0, v0 = 0;
		

		for (long k = 1; k < r; ++k) {
			v1 = ((v1 & heven) | ((v0 ^ noty) & temp)) >> 1;
			v0 = ((v0 & (v1 ^ notx)) | (~v0 & (v1 ^ noty))) >> 1;
		}
		long hodd = (~v0 & (v1 ^ x)) | (v0 & (v1 ^ noty));
		long ho = interleave(hodd, heven, r);
		// System.out.println(ho);

		// Pad v1 and v0
		String v1ToString = Long.toBinaryString(v1);
		int v1Size = v1ToString.length();
		for (int i = 0; i < (r - v1Size); i++)
			v1ToString = "0" + v1ToString;
		v1ToString = reverse(v1ToString);

		String v0ToString = Long.toBinaryString(v0);
		int v0Size = v0ToString.length();
		for (int i = 0; i < (r - v0Size); i++)
			v0ToString = "0" + v0ToString;
		v0ToString = reverse(v0ToString);

		if (logS == 0) {
			hb = he = ho;
		} else {
			// orientation of a 2^j*2^j block
			int orientation = 2 * (v1ToString.charAt(logS - 1) == '1' ? 1 : 0)
					+ (v0ToString.charAt(logS - 1) == '1' ? 1 : 0);
			// System.out.println("orientation=" + orientation);

			// Will return hb and he
			calculateHbHe(ho, orientation, s, logS);
		}
		return ho;
	}


	/**
	 * Calculate the orientation of the hilbert inside a quad-tree block
	 * @param ho
	 * @param orientation
	 * @param s
	 * @param logS
	 */
	private void calculateHbHe(long ho, int orientation, long s, int logS) {
		
		if (orientation == 0 || orientation == 3) {
			hb = ho;
			he = ho + (s * s - 1);
		}

		if (orientation == 1 || orientation == 2) {
			long tmp = 0;
			for (long i = 0; i <= (logS - 1); i++)
				tmp = tmp + (long) (Math.pow(2, 2 * i));
			he = ho + tmp;
			hb = he - (s * s - 1);
		}

	}

	/**
	 * Returns reverse of the input string
	 * @param in
	 * @return
	 */
	private static String reverse(String in) {
		StringBuffer sb = new StringBuffer(in);
		return sb.reverse().toString();
	}


	/**
	 * Interleave hodd and heven. Output should have the length of 2*r.
	 * @param hodd
	 * @param heven
	 * @param r
	 * @return
	 */
	private static long interleave(long hodd, long heven, int r) {
		String hoddToBinary = Long.toBinaryString(hodd);
		String hevenToBinary = Long.toBinaryString(heven);

		long padSize = r - hoddToBinary.length();
		for (long i = 0; i < padSize; i++)
			hoddToBinary = "0" + hoddToBinary;

		padSize = r - hevenToBinary.length();
		for (long i = 0; i < padSize; i++)
			hevenToBinary = "0" + hevenToBinary;

		StringBuffer interleaved = new StringBuffer(2 * r);

		// Initialize a stringbuffer with the size of 2*r
		interleaved = interleaved.append(hoddToBinary);
		interleaved = interleaved.append(hoddToBinary);
		for (int i = r - 1; i >= 0; i--) {
			interleaved.setCharAt(2 * i, hevenToBinary.charAt(r - i - 1));
			interleaved.setCharAt(2 * i + 1, hoddToBinary.charAt(r - i - 1));
		}

		return (Long.parseLong((reverse(interleaved.toString())), 2));
	}

	/*
	 * For specifying the endpoints of the window query by the mouse.
	 */
	public static void useMouse(StdDraw main) {
		//int i = 0;
		Point2D.Double startPoint = new Point2D.Double();
		Point2D.Double endPoint = new Point2D.Double();
		main.setPenColor(StdDraw.GREEN);
		main.setPenRadius(0.003);
		boolean first = true;
		while (true) {
			if (main.mousePressed() && first) {
				first = false;
				/*i++;
				main.filledCircle(main.mouseX(), main.mouseY(), 0.1);

				if (i == 1) {
					x = (long) Math.ceil(main.mouseX()) - 1;
					y = (long) Math.ceil(main.mouseY()) - 1;
					System.out.println(x + "x " + y);
				} else {
					long a = (long) Math.floor(main.mouseX());
					long b = (long) Math.floor(main.mouseY());

					System.out.println(a + "ff " + b);
					n1 = Math.abs(y - b - 1);
					n2 = Math.abs(x - a - 1);
				}

				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if (i == 2) {
					break;
				}*/
				System.out.println("mouse pressed");
				startPoint.x = main.mouseX();
				startPoint.y = main.mouseY();
			}
			try {
				Thread.sleep(100);
				//main.repaint();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (main.mouseDragged()) {
				System.out.println("mouse dragging");
				endPoint.x = main.mouseX();
				endPoint.y = main.mouseY();
				double[] ax = {startPoint.x, endPoint.x, endPoint.x, startPoint.x};
				double[] ay = {startPoint.y, startPoint.y, endPoint.y, endPoint.y};
				main.filledPolygon(ax, ay);
			}
			if (main.mouseReleased()) {
				System.out.println("mouse released");
				endPoint.x = main.mouseX();
				endPoint.y = main.mouseY();
				double[] ax = {startPoint.x, endPoint.x, endPoint.x, startPoint.x};
				double[] ay = {startPoint.y, startPoint.y, endPoint.y, endPoint.y};
				main.filledPolygon(ax, ay);
				break;
			}
		}
		
		
		
	}

	/*
	 * Used only in experiments to draw the hilbert curves
	 */
	public void drawRuns(StdDraw draw, long max) {

		double xArr[] = { x, x + n2, x + n2, x };
		double yArr[] = { y, y, y + n1, y + n1 };
		
		draw.setPenColor(StdDraw.PINK);
		draw.setPenRadius(0.003);
		draw.polygon(xArr, yArr);
		//dual.polygon(xArr, yArr);
		
		for (int i = 0; i <= max - 1; i++) {
			for (int j = 0; j <= max - 1; j++) {
				calculateHilbert(i, j, 1);

				for (int k = 0; k < finalRuns.size(); k++) {

					if (finalRuns.elementAt(k).hb <= hb
							&& finalRuns.elementAt(k).he >= he) {

						float nextColor = (float) ((k) / 9.0);
						if (nextColor > 255)
							nextColor = 1;

						Color c = new Color(Color.HSBtoRGB(nextColor, 1, 1));
						Font f = new Font("TimesRoman", Font.BOLD, 10);
						
						draw.setPenColor(c);
						draw.filledSquare(i + 0.5, j + 0.5, 0.5);
						draw.setFont(f);
						draw.setPenColor(StdDraw.BLACK);
						draw.text(i + 0.5, j + 0.5, Long.toString(k));
						
						/*dual.setPenColor(c);
						dual.filledSquare(i + 0.5, j + 0.5, 0.5);
						dual.setFont(f);
						dual.setPenColor(StdDraw.BLACK);
						dual.text(i + 0.5, j + 0.5, Long.toString(k));*/
						

					}
				}

				/*Font f = new Font("TimesRoman", Font.ITALIC, 10);
				draw.setFont(f);
				draw.setPenColor(StdDraw.BLACK);
				draw.text(i + 0.2, j + 0.15, Long.toString(he));
				*/

				/*dual.setFont(f);
				dual.setPenColor(StdDraw.BLACK);
				dual.text(i + 0.2, j + 0.15, Long.toString(he));*/
			}
		}
		//delete
		//draw.setPenRadius(0.0003);
		//draw.setPenColor(StdDraw.BLACK);
		//Hilbert.hilbert0(draw,this.curverOrder);
		
	}
	// booleanX and booleanY indicates the condition on the x and y (x should be
	// odd or even and similar case for y)
	private void runExperiments(double numExp) throws IOException {

		boolean rotatedArr[] = { false, true };
		boolean shiftedArr[] = { false, true };

		double numRunsInShiftedRotatedVar[] = new double[(int) numExps];
		double numRunsInRotatedVar[] = new double[(int) numExps];
		double numRunsInShiftedVar[] = new double[(int) numExps];
		double numRunsInOriginalVar[] = new double[(int) numExps];

		long numRunsInOriginal = 0;
		long numRunsInRotated = 0;
		long numRunsInShifted = 0;
		long numRunsInShiftedRotated = 0;
		long numRunsInRossoupolous = 0;
		long numRunsinShiftedRotatedExpanded = 0;

		// Number of runs in the hybrid approach consisting of shifted-rotated
		// and the originial approach
		long numRunsInHybrid = 0;
		// we take the minimum of the following two variables for the hybrid
		// approach
		long numRunsInOriginalOnlyThisOne = 0;
		long numRunsInShiftedRotatedOnlyThisOne = 0;

		for (int i = 0; i < numExp; i++) {

			// StdDraw.clear();
			// drawGrid(max);

			// /////////
			// /////////
			// Change the following lines for generating random size queries
			experimentN1 = (long) (intervalBeginning
					+ roll(intervalEnd - intervalBeginning + 1));
			experimentN2 = (long) (intervalBeginning
					+ roll(intervalEnd - intervalBeginning + 1));

			// First generate the random coordinates
			long randX = roll(max - Math.max(experimentN2, experimentN1));
			long randY = roll(max - Math.max(experimentN2, experimentN1));

			n1 = experimentN1;
			n2 = experimentN2;

			// Iterating over different cases
			for (int j = 0; j < rotatedArr.length; j++) {
				for (int k = 0; k < shiftedArr.length; k++) {
					// System.out.println(x + " " + y + "");

					// Will set the coordinates for dual or shifted ...

					// Clearing the data structures
					n1 = experimentN1;
					n2 = experimentN2;

					// Set the value of X and Y for different cases
					setXYforDualShift(rotatedArr[j], shiftedArr[k], randX,
							randY, n1);
					rangeQuery(x, y, n1, n2);

					if (rotatedArr[j] && shiftedArr[k]) {
						// System.out.print("Shifted+dual");
						numRunsInShiftedRotated += finalRuns.size();
						numRunsInShiftedRotatedVar[i] = finalRuns.size();

						numRunsInShiftedRotatedOnlyThisOne = finalRuns.size();

						// numRunsinShiftedRotatedExpanded += runRossoupolus(x,
						// y,
						// n1, n2);
					}

					if (rotatedArr[j] && !shiftedArr[k]) {
						// System.out.print("Rotated");
						numRunsInRotated += finalRuns.size();
						numRunsInRotatedVar[i] = finalRuns.size();
					}

					if (!rotatedArr[j] && shiftedArr[k]) {
						// System.out.print("Shifted");
						numRunsInShifted += finalRuns.size();
						numRunsInShiftedVar[i] = finalRuns.size();
					}

					if (!rotatedArr[j] && !shiftedArr[k]) {
						// System.out.print("Original");
						// For testing the correlation we need to write this one
						// to a file
						out.write(finalRuns.size() + "\n");
						outAll.write(finalRuns.size() + "\t"+experimentN1+"\n");
						numRunsInOriginal += finalRuns.size();

						numRunsInOriginalVar[i] = finalRuns.size();

						numRunsInOriginalOnlyThisOne = finalRuns.size();
					}

					// drawRuns();

				}// end for
			}// end for

			n1 = experimentN1;
			n2 = experimentN2;
			numRunsInRossoupolous += runRossoupolus(randX, randY, n1, n2);
			// drawRuns();

			numRunsInHybrid = numRunsInHybrid
					+ Math.min(numRunsInOriginalOnlyThisOne,
							numRunsInShiftedRotatedOnlyThisOne);

		}

		System.out.println("numRunsInOriginal: " + numRunsInOriginal / numExp);

		double variance = 0;
		double numRunsInOriginalAvg = numRunsInOriginal / numExp;
		for (int i = 0; i < numRunsInOriginalVar.length; i++) {
			variance += Math.pow(
					(numRunsInOriginalVar[i] - numRunsInOriginalAvg), 2);
		}

		System.out.println("number of runs in original SD: "
				+ Math.sqrt(variance / numExp));

		System.out.println("numRunsInRotated: " + numRunsInRotated / numExp);
		System.out.println("numRunsInShifted: " + numRunsInShifted / numExp);
		System.out.println("numRunsInShiftedRotated: "
				+ numRunsInShiftedRotated / numExp);

		System.out.println("numRunsInHybrid: " + numRunsInHybrid / numExp);

		System.out.println("numRunsInRossoupoulos: " + numRunsInRossoupolous
				/ numExp);

		System.out.println("numRunsinShiftedRotatedExpanded: "
				+ numRunsinShiftedRotatedExpanded / numExp);

		/*
		 * out.write(intervalBeginning + "\t" + intervalEnd + "\t" +
		 * numRunsInOriginal / numExp + "\t" + numRunsInHybrid / numExp + "\n");
		 */
	}

	private long runRossoupolus(long inX, long inY, long inN1, long inN2) {

		long lowerX = inX;
		long lowerY = inY;

		long upperX = inX + inN2 - 1;
		long upperY = inY + inN1 - 1;

		if (lowerX % 2 == 1)
			lowerX--;

		if (lowerY % 2 == 1)
			lowerY--;

		if (upperX % 2 == 0)
			upperX++;

		if (upperY % 2 == 0)
			upperY++;

		n1 = upperY - lowerY + 1;
		n2 = upperX - lowerX + 1;
		x = lowerX;
		y = lowerY;

		rangeQuery(x, y, n1, n2);

		return finalRuns.size();
	}

	private void setXYforDualShift(boolean roateted, boolean shifted,
			long inX, long inY, long inN1) {

		x = inX;
		y = inY;

		long upperLeftX = x;
		long upperLeftY = y + inN1 - 1;
		long rotatedupperLeftX = -upperLeftY + max - 1;
		long rotatedupperLeftY = upperLeftX;

		// We want to rotate for 90 degree
		if (roateted) {
			x = rotatedupperLeftX;
			y = rotatedupperLeftY;

			long tmp = n1;
			n1 = n2;
			n2 = tmp;

		}

		// We want to shift the curve
		if (shifted) {
			x++;
			y++;
		}
	}


	private void runMultipleExperiments() throws IOException {

		File file = new File("hybrid.txt");
		out = new BufferedWriter(new FileWriter(file));

		File fileAll = new File("all.txt");
		outAll = new BufferedWriter(new FileWriter(fileAll));
		// for the square of size 1*1, 2*2, 3*3 ,..., 400*400
		for (intervalBeginning = 2; intervalBeginning <= 10; intervalBeginning++) {
			intervalEnd = intervalBeginning;

			System.out.println(intervalBeginning + " x " + intervalEnd);

			// create a file for the number of runs in a square of
			// intervalBeginning by intervalEnd
			file = new File("other" + ".txt");
			out = new BufferedWriter(new FileWriter(file));

			runExperiments(numExps);

			out.close();

		}

		outAll.close();
		System.exit(0);

	}


	
}
