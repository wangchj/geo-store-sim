package hilbert;
/*************************************************************************
 *  Compilation:  javac Hilbert.java
 *  Execution:    java Hilbert N
 *  Dependencies: //TKDE StdDraw.java
 *
 *  Plot an order N Hilbert curve using two mutually recursive functions.
 *
 *  % java Hilbert 5
 *
 * Before calling this, you have to call filter.java once to filter data for a specific region. Next you need to make sure
 * that the correct constant is used to scale it up.
 *************************************************************************/
import java.awt.Color;
import java.awt.geom.Point2D;
import java.io.*;
import java.util.*;

import com.std.princeton.StdDraw;

import hilbert.Utility;

public class Hilbert {
    /**
     * Default = 1;
     */
    private static int totalNumberOfExperiments = 1;
    /**
     * KNN Default K = 1;
     */
    private static int K=1;//Used for finding the kNN 
    /**
     * turtle graphics position and angle (yuck, static variables)
     */
    private static double x = 0.5, y = 0.5;
    private static double orientation = 0.0;
	private static long index = 0;
	/**
	 * 26 by 26 mile area with no ocean
	 */
	//I Changed the original data set which is longitude, latitude
	//to latitude[33.760000, 34.150000], longitude[-117.932, -118.400163]
	/**
	 * Maximum number of Hospitals in one H-Value
	 * Default = 10
	 */
	private static int MAX_POI = 10;
    /**
     * the maximum number of elements in one cell, i.e. on one Hilbert value
     * Default = 0;
     */
	private static long MaximumRepetition=0;
	/**
	 * The maximum number of elements in one cell
	 */
	private static long MaximumRepetitionIndex=0;
	private static long averageRep=0;
    private static long numberOfVectors=0;
	private static long poiId1 = 0;
	/**
	 * these two indexes move on all poi's for hilbert and shifted hilbert
	 */
	private static long poiId2 = 0;
	/**
	 * this together with averageRep is used to compute the average of rep WHEN it occurs not over the entire data!
	 */
	private static long repetitionCount=0; 
	/**
	 * Initially our data set has less than 10^6 data items in it (in our test case, hospitals).
	 * Its schema is poiId1, {quantizedX, quantizedY,x, y,index});
	 */
	private static HashMap<Long, Vector<?>> poiMap1 = new HashMap<Long, Vector<?>>(15000); //10160
	/**
	 * Initially our data set has less than 10^6 data items in it (in our test case, hospitals). 
	 * Its schema is poiId1, {quantizedX, quantizedY,x, y,index});
	 */
    private static HashMap<Long, Vector<?>> poiMap2 = new HashMap<Long, Vector<?>>(1800);

    //private static long numberOfPoi = 0;
        
	//private static double [] tmpRes={0,0,0,0,0,0};//it temporary stores the randomly retrieved point's data fields. for mymap
	//private static double [] tmpPoi={0,0,0,0,0};//it temporary stores the randomly retrieved point's data fields. for poiMap
	/**
	 * kNNPoiReal is the array containing the id of k nearest POI to the randomly generated point. Max k in KNN is 500!
	 */
	private static long [] kNNPoiReal = new long[500] ;
	/**
	 * kNNPoiHilb1 is the array containing the id of k nearest poi to the randomly generated point in Hilbert curve. Max k in KNN is 500!
	 */
	private static long [] kNNPoiHilb1 = new long[500];
	/**
	 * kNNPoiHilb2 is the array containing the id of k nearest poi to the randomly generated point in shifted Hilbert curve. Max k in KNN is 500!
	 */
	private static long [] kNNPoiHilb2 = new long[500];
	/**
	 *kNNPoiHilbDis is an array containing the real distance from their corresponding id's in kNNPoiHilb1 to our original hilbert 
	 */
	//private static double [] kNNPoiHilbDis1 = new double [500];
	/**
	 * kNNPoiHilbDis is an array containing the real distance from their corresponding id's in knnpoihilb to our shifted hilbert
	 */
	//private static double [] kNNPoiHilbDis2 = new double [500];
	/**
	 * this contains the id's merged from knnpoihib1 and 2
	 */
	private static long [] kNNPoiHilbFinal = new long [500];
	/**
	 * this contains the final result of nn distances the real ones!
	 */
	//private static double [] kNNPoiRealFinalDis = new double [500];
	/**
	 * this contains the final result of nn distances after merging the two arrays
	 */
	//private static double [] kNNPoiHilbFinalDis = new double [500];
	/**
	 * the total euclidian distance between the hilbert points and the Query point
	 */
	//private static double EDistanceHSum = 0;
	/**
	 * the total euclidian distance between the real points and the Query point
	 * 25, 48,-91,and -68 are respectively the right values for a large square on the east coast!
	 */
	//private static double EDistanceSum = 0;
	        
    //private static double variance = 0;
    //private static double maxDisplacement = 0;
    /**
     * the average difference over all experiments.
     */
    //private static double averageOveralDifference = 0;
       /**
        * Default = 2^N
        */
	//private static double max = Math.pow(2, Constant.N);
       
       
        
        private static double[] precision=new double[500]; //we assume maximum number of nearest neighbors is 500
        private static double [] avgPrecision= new double[500];
        
        private static long hilbertVal = 0;
    /**
     * draw hilbert curve on draw at order of n
     * @param draw
     * @param n
     */
    public static void hilbert0(hilbert.StdDraw draw, int n) {
        if (n == 0) return;
        rotate(90);
        hilbert1(draw, n-1);
        forward(draw, 1.0);
        rotate(-90);
        hilbert0(draw, n-1);
        forward(draw, 1.0);
        hilbert0(draw, n-1);
        rotate(-90);
        forward(draw, 1.0);
        hilbert1(draw, n-1);
        rotate(90);
    }
    /**
     * evruc trebliH
     * @param n
     */
    public static void hilbert1(hilbert.StdDraw draw,int n) {
        if (n == 0) return;
        rotate(-90);
        hilbert0(draw, n-1);
        forward(draw, 1.0);
        rotate(90);
        hilbert1(draw, n-1);
        forward(draw, 1.0);
        hilbert1(draw, n-1);
        rotate(90);
        forward(draw, 1.0);
        hilbert0(draw, n-1);
        rotate(-90);
    }
    /**
     * move turtle forward d units in current direction
     * @param d
     */
    private static void forward(hilbert.StdDraw draw, double d) {
        double x0 = x, y0 = y;
        x += d * Math.cos(Math.toRadians(orientation));
        y += d * Math.sin(Math.toRadians(orientation));
        draw.line(x0, y0, x, y);
	    index++;
		
		////TKDE 
	    //draw.text(x0,y0, Long.toString(hilbertVal));
		hilbertVal ++;
		
		//if (hilbertVal == (Math.pow(2, 2 * Constant.N) - 1)) {
		//	StdDraw.text(x,y, Long.toString(hilbertVal));
		//}
        //if (index % 10==0) //TKDE StdDraw.text(x, y, Long.toString(index));
		//******************UNCOMMENT THIS LINE***********************************
		////TKDE StdDraw.text(x, y, Double.toString(x));
    }
    public static void hilbert0(int n) {
        if (n == 0) return;
        rotate(90);
        hilbert1(n-1);
        forward(1.0);
        rotate(-90);
        hilbert0(n-1);
        forward(1.0);
        hilbert0(n-1);
        rotate(-90);
        forward(1.0);
        hilbert1(n-1);
        rotate(90);
    }
    /**
     * evruc trebliH
     * @param n
     */
    public static void hilbert1(int n) {
        if (n == 0) return;
        rotate(-90);
        hilbert0(n-1);
        forward(1.0);
        rotate(90);
        hilbert1(n-1);
        forward(1.0);
        hilbert1(n-1);
        rotate(90);
        forward(1.0);
        hilbert0(n-1);
        rotate(-90);
    }
    /**
     * move turtle forward d units in current direction
     * @param d
     */
    private static void forward(double d) {
        double x0 = x, y0 = y;
        x += d * Math.cos(Math.toRadians(orientation));
        y += d * Math.sin(Math.toRadians(orientation));
        StdDraw.line(x0, y0, x, y);
	    index++;
	    StdDraw.setPenColor(StdDraw.RED);
	    StdDraw.setPenRadius(0.0005);
//	    StdDraw.text(x0, y0, String.valueOf(hilbertVal));
	    StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
	    StdDraw.setPenRadius(0.004);
		////TKDE 
	    //draw.text(x0,y0, Long.toString(hilbertVal));
		hilbertVal ++;
		
		//if (hilbertVal == (Math.pow(2, 2 * Constant.N) - 1)) {
		//	StdDraw.text(x,y, Long.toString(hilbertVal));
		//}
        //if (index % 10==0) //TKDE StdDraw.text(x, y, Long.toString(index));
		//******************UNCOMMENT THIS LINE***********************************
		////TKDE StdDraw.text(x, y, Double.toString(x));
    }
    /**
     * rotate turtle's orientation his many degrees
     * @param angle
     */
    private static void rotate(double angle) {
        orientation += angle;
    }

 

    /**
     * latitude Scaling from (33.76,34.15) to (0,2^N)
	 * longitude Scaling from (-118.400163,-117.932) to (0,2^N)
     * @return
     */
    public static Point2D.Double geo2Grid(Point2D.Double g, int order) {
    	double x = ((g.x - Constant.min.x) * (1/(Constant.max.x-Constant.min.x)) * Math.pow(2, order));
    	double y = ((g.y - Constant.min.y) * (1/(Constant.max.y-Constant.min.y)) * Math.pow(2, order));
    	return new Point2D.Double(x, y);
    }
    
    public static Point2D.Double geo2Screen(Point2D.Double g, int order) {
    	double x = ((g.x - Constant.min.x) * (1/(Constant.max.x-Constant.min.x)) * Constant.ScreenSize); //800 is the size of the frame
    	double y = ((g.y - Constant.min.y) * (1/(Constant.max.y-Constant.min.y)) * Constant.ScreenSize);
    	return new Point2D.Double(x, y);
    }
    
    public static long[] geo2Grid(double[] g, int order) {
    	long[] ret = new long[2];
    	ret[0] = (long)((g[0] - Constant.min.x) * (1/(Constant.max.x-Constant.min.x)) * Math.pow(2, order));
    	ret[1] = (long)((g[1] - Constant.min.y) * (1/(Constant.max.y-Constant.min.y)) * Math.pow(2, order));
    	return ret;
    }
    
    public static Point2D.Double grid2Geo(Point2D.Double g, int order) {
    	double lat = Constant.min.x + g.x * (1/Math.pow(2, order)) * (Constant.max.x-Constant.min.x);
    	double lng = Constant.min.y + g.y * (1/Math.pow(2, order)) * (Constant.max.y-Constant.min.y);
    	return new Point2D.Double(lat, lng);
    }
    
    public static Point2D.Double grid2Geo(long[] g, int order) {
    	double lat = Constant.min.x + g[0] * (1/Math.pow(2, order)) * (Constant.max.x-Constant.min.x);
    	double lng = Constant.min.y + g[1] * (1/Math.pow(2, order)) * (Constant.max.y-Constant.min.y);
    	return new Point2D.Double(lat, lng);
    }
    
    /*
    public static Point2D.Double grid2CellNum(Point2D.Double g, int order) {
    	double x = g.x / Math.pow(2, order);
    	double y = g.y / Math.pow(2, order);
    	return new Point2D.Double(x, y);
    }
    
    public static Point2D.Double cellNum2Grid(Point2D.Double g, int order) {
    	double x = Math.pow(2, order) * g.x;
    	double y = Math.pow(2, order) * g.y;
    	return new Point2D.Double(x, y);
    }
    */
    
    /**
     * get the following information
     * max number of POIs in one cell
     * all the hilbert values of cells with the max number of pionts.
     */
    @SuppressWarnings("unchecked")
	public static void getDistribution(HashMap<Long, Vector<SpatialObject>> hashmap) {

    	int max = 0;
    	long id = 0;
    	Iterator it = hashmap.keySet().iterator();
    	
    	while (it.hasNext()) {
    		Vector<SpatialObject> sos = (Vector<SpatialObject>) (hashmap.get(it.next()));
    		if (sos.size() > max) {
    			max = sos.size();
    			id = sos.iterator().next().getHilbertValue();
    		}
    	}
    	
    	it = hashmap.keySet().iterator();
    	int cnt = 0;
    	while (it.hasNext()) {
    		Vector<SpatialObject> sos = (Vector<SpatialObject>) (hashmap.get(it.next()));
    		if (sos.size() == max) {
    			//max = sos.size();
    			id = sos.iterator().next().getHilbertValue();
    			cnt ++;
    			System.out.println("max = " + max + " with hilbert value = " + id);
    		}
    	}
    	
    	//System.out.println("max = " + max + " with hilbert value = " + id);
    	//return (Constant.totalPOI * 1.00000) / hashmap.size() ;
    	
    }
    public static void getSubset() {
    	try {
    		BufferedReader all = new BufferedReader(new FileReader(Constant.FILTEREDDATA));
    		BufferedWriter part = new BufferedWriter(new FileWriter(Constant.PATH + "NA2MFiltered.txt"));
    		String line ;
    		int cnt = 0;
    		while ((line = all.readLine()) != null) {
		        //process dual info first
		        int tmp1 = ((int)(10 * Constant.generator.nextDouble())); 
                if ((tmp1 == 2) || (tmp1 == 4) || (tmp1 == 6)) { //get 3/10 data
                	cnt ++;
                	part.write(line + "\n");
                }
                if ((tmp1 == 3)) { //plus 0.5/10 data
                	int tmp2 = ((int)(2 * Constant.generator.nextDouble())); 
                	if (tmp2 == 0) {
                		cnt ++;
                    	part.write(line + "\n");
                	}
                }
    		}
    		all.close();
    		part.close();
    	}catch (Exception e) {
    		e.printStackTrace();
    	}
    }
    
    public static int rangePointsCnt(HashMap<Long, PointCnt> hashmap, Range r) {
    	int cnt = 0;
    	List<Long> list = new ArrayList<Long>(hashmap.keySet());
        Collections.sort(list);
        for (Long l1 : list) {
        	if ((l1 >= r.getX()) && (l1 < r.getX()+r.getStepx())) {
        		PointCnt pointCnt = hashmap.get(l1);
            	HashMap<Long, Integer> hh = pointCnt.getHm();
            	List<Long> list2 = new ArrayList<Long>(hh.keySet());
            	for (Long l2 : list2) {
            		if ((l2 >= r.getY()) && (l2 < r.getY()+r.getStepy())) {
            			cnt++;
            		} else continue;
            	}
        	} else continue;
        }
    	return cnt;
    }
    
    public static HashMap<Long, PointCnt> rangeAuxStat(int N) {
    	try {
    		BufferedReader all = new BufferedReader(new FileReader(Constant.FILTEREDDATA));
	        long scaledLat=0;
            long scaledLng=0;
            String[] coordinate = new String[2];
            String str1;
            Point2D.Double g = new Point2D.Double();
            HashMap<Long, PointCnt> ret = new HashMap<Long, PointCnt>();
            while ((str1 = all.readLine()) != null) {
	        	coordinate = str1.split(",");
	        	double lat1 = Double.parseDouble(coordinate[0]);
		        double lng1 = Double.parseDouble(coordinate[1]);
		        g = geo2Grid(new Point2D.Double(lat1, lng1), N);
            	scaledLat= (long) Math.floor(g.x);
                scaledLng= (long) Math.floor(g.y);
                
                //HashMap<Long, Integer> in = new HashMap<Long, Integer>();
                if (ret.containsKey(scaledLat)) {
                	PointCnt pc = ret.get(scaledLat);
                	pc.setCnt(pc.getCnt() + 1);
                	
                	HashMap<Long, Integer> in = pc.getHm();
                	if ((in != null) && (in.containsKey(scaledLng))) {
                		Integer i = new Integer(in.get(scaledLng).intValue()+1); 
                		in.put(scaledLng, i);
                	} else if (!(in.containsKey(scaledLng))) {
                		in.put(scaledLng, 1);
                	}
                	ret.put(scaledLat, pc);
                } else {
                	HashMap<Long, Integer> n = new HashMap<Long, Integer>() ;
                	n.put(scaledLng, 1);
                	ret.put(scaledLat, new PointCnt(1, n));
                }
            }
            List<Long> list = new ArrayList<Long>(ret.keySet());
            Collections.sort(list);
            for (Long l1 : list) {
            	PointCnt pointCnt = ret.get(l1);
            	System.out.println(l1 + "=" + pointCnt.getCnt());
            	HashMap<Long, Integer> hh = pointCnt.getHm();
            	List<Long> list2 = new ArrayList<Long>(hh.keySet());
            	for (Long l2 : list2) {
            		System.out.println("\t" + l2 + "=" + hh.get(l2).intValue());
            	}
            }
            /*
            for (Iterator<Long> it = ret.keySet().iterator(); it.hasNext() ;) {
            	Long l = it.next();
            	PointCnt pointCnt = ret.get(l);
            	System.out.println(l + "***" + pointCnt.getCnt());
            	HashMap<Long, Integer> hh = pointCnt.getHm();
            	for (Iterator<Long> itin = hh.keySet().iterator() ; itin.hasNext() ;) {
            		Long n = itin.next();
            		System.out.println("\t\t" + n + "=" + hh.get(n).intValue());
            		
            	}
            }
            */
            return ret;    
    	} catch (Exception e) {
			System.out.println("Error reading file");
			return null;
	}
    	
    }
    /**
     * Initialization Phase with no plotting.
     * 1. compute hilbert value for every object for the primary set and the secondary set. 
     * 2. compute dual information indicating 
     */
    public static void init(double expoN1, int N1, double expoN2,int N2)
	{
    	try {
	        //System.out.println("Initialization......");
	        BufferedReader all = new BufferedReader(new FileReader(Constant.FILTEREDDATA));
	        long scaledLat=0;
            long scaledLng=0;
            String[] coordinate = new String[2];
            String str1;
            int numberOfPoi = 0;
            int dualPOI = 0;
            int tempcnt = 0;
            boolean localCtl = false;
            Constant.combine = true;
            //Point2D.Double g1 = new Point2D.Double(), g2 = new Point2D.Double();
            while ((str1 = all.readLine()) != null) {
	        	coordinate = str1.split(",");
	        	double lat1 = Double.parseDouble(coordinate[0]);
		        double lng1 = Double.parseDouble(coordinate[1]);
		        double[] g = {lat1, lng1};
		        long[] scaled = Hilbert.geo2Grid(g, N2);
		        scaledLat = scaled[0];
		        scaledLng = scaled[1];
		        //process dual info first
		        int tmp = ((int)(10 * Constant.generator.nextDouble())); 
		        
		        SpatialObject sso = new SpatialObject(0,0,0,0,0,null,'d');
		        switch ((int)(Constant.DUALRATE)) {
		        	case 10 : 
		        		if (tmp == 3) {
				        	tempcnt++;
		                	localCtl = true;
		                    if (Constant.combine) {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.primary, numberOfPoi, true, 'c');
		                    }
		                    else {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.secondary, numberOfPoi, false, 'c');
		                    }
		                    dualPOI ++;
				        }
		        		break;
		        	case 20 : 
		        		if ((tmp == 7) || (tmp == 3)) {
				        	tempcnt++;
		                	localCtl = true;
		                    if (Constant.combine) {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.primary, numberOfPoi, true, 'c');
		                    }
		                    else {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.secondary, numberOfPoi, false, 'c');
		                    }
		                    dualPOI ++;
				        }
		        		break;
		        	case 30 : 
		        		if ((tmp == 7) || (tmp == 3) || (tmp == 9)) {
				        	tempcnt++;
		                	localCtl = true;
		                    if (Constant.combine) {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.primary, numberOfPoi, true, 'c');
		                    }
		                    else {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.secondary, numberOfPoi, false, 'c');
		                    }
		                    dualPOI ++;
				        }
		        		break;
		        	case 40 : 
		        		if ((tmp == 7) || (tmp == 3) || (tmp == 9) || (tmp == 5)) { //dual rate = 0.4
				        	tempcnt++;
		                	localCtl = true;
		                    if (Constant.combine) {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.primary, numberOfPoi, true, 'c');
		                    }
		                    else {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.secondary, numberOfPoi, false, 'c');
		                    }
		                    dualPOI ++;
				        }
		        		break;
		        	case 50 : 
		        		if ((tmp == 7) || (tmp == 3) || (tmp == 9) || (tmp == 5) || (tmp == 2)) { //dual rate = 0.5
				        	tempcnt++;
		                	localCtl = true;
		                    if (Constant.combine) {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.primary, numberOfPoi, true, 'c');
		                    }
		                    else {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.secondary, numberOfPoi, false, 'c');
		                    }
		                    dualPOI ++;
				        }
		        		break;
		        	/*
		        	case 60 : 
		        		if ((tmp == 7) || (tmp == 3)) {
				        	tempcnt++;
		                	localCtl = true;
		                    if (Constant.combine) {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.primary, numberOfPoi, true, 'c');
		                    }
		                    else {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.secondary, numberOfPoi, false, 'c');
		                    }
		                    dualPOI ++;
				        }
		        		break;
		        	case 70 : 
		        		if ((tmp == 7) || (tmp == 3)) {
				        	tempcnt++;
		                	localCtl = true;
		                    if (Constant.combine) {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.primary, numberOfPoi, true, 'c');
		                    }
		                    else {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.secondary, numberOfPoi, false, 'c');
		                    }
		                    dualPOI ++;
				        }
		        		break;
		        	case 80 : 
		        		if ((tmp == 7) || (tmp == 3)) {
				        	tempcnt++;
		                	localCtl = true;
		                    if (Constant.combine) {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.primary, numberOfPoi, true, 'c');
		                    }
		                    else {
		                    	sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.secondary, numberOfPoi, false, 'c');
		                    }
		                    dualPOI ++;
				        }
		        		break;
		        		*/
		        	default : break;
		        }
                //N1 >= N2
                scaled[0] = (long)Math.pow(2, (N1-N2)) * scaledLat;
                scaled[1] = (long)Math.pow(2, (N1-N2)) * scaledLng;
                if (N1 < N2) {
                	System.out.println("ABNORMAL! Please check the Hilbert curve orders.");
                	System.out.println(scaledLat+"/"+scaledLng + "   " + scaled[0] + "/" + scaled[1]);
                }
                char d = 'a';
                if (localCtl) {
                	d = 'b'; //primary with duplication
                	localCtl = false;
                	} 
                else 
                { d = 'a' ; } //primary without duplication
                SpatialObject pso = getHilbertIndex(scaled[0],scaled[1],N1, Constant.primary, numberOfPoi, true, d);
                numberOfPoi ++;
                Constant.totalPOI = numberOfPoi;
    	        Constant.dualPOI = dualPOI;
            }
	        all.close();
    	} catch (Exception e) {
    			e.printStackTrace();
				System.out.println("Error reading file");
                System.exit(1);
    	}
		                
		        
		        
		        
		        /*
                // if (tmp == 3) { //dual rate = 0.1
                //if ((tmp == 7) || (tmp == 3)) { //dual rate = 0.2
		        //if ((tmp == 7) || (tmp == 3) || (tmp == 9)) { //dual rate = 0.3
		        //if ((tmp == 7) || (tmp == 3) || (tmp == 9) || (tmp == 5)) { //dual rate = 0.4
		        //if ((tmp == 7) || (tmp == 3) || (tmp == 9) || (tmp == 5) || (tmp == 2)) { //dual rate = 0.5
		        //if (!((tmp == 7) || (tmp == 3) || (tmp == 9) || (tmp == 5))) { //dual rate = 0.6
		        //if (!((tmp == 7) || (tmp == 3) || (tmp == 9))) { //dual rate = 0.7
		        //if (!((tmp == 7) || (tmp == 3))) { //dual rate = 0.8
		        //if (!(tmp == 3)) { //dual rate = 0.9
                	tempcnt++;
                	localCtl = true;
                	//the current record is dual data
                	
                    if (Constant.combine) 
                    {
                    	SpatialObject sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.primary, numberOfPoi, true, 'c');
                    } else {
                    	SpatialObject sso = getHilbertIndex(scaled[0],scaled[1],N2, Constant.secondary, numberOfPoi, false, 'c');
                    }
                    dualPOI ++;
                }
                //process primary secondly
                */

            /*
            int cell = 4;
            for (int i = 0 ; i < cell ; i ++) 
            	for (int j = 0 ; j < cell ; j ++){
            		scaledLat = i;
            		scaledLng = j;
            		long quantizedX=(long) Math.floor(scaledLat);
    				long quantizedY=(long) Math.floor(scaledLng);
    				
            		SpatialObject sso = Hilbert.getHilbertIndex(quantizedX,quantizedY,2, Constant.secondary, numberOfPoi, false, 'c');
    		        long jeff = sso.getHilbertValue() ;
    		        
    		        HilbertRange hr = new HilbertRange(2);
    		        long houtan = hr.getHilbert(2, quantizedX, quantizedY);
    		        
    		        	System.out.println("Jeff=" + jeff + " houtan = " + houtan);
            	}
			*/
            
		        
		        /*
		        g = geo2Grid(new Point2D.Double(lat1, lng1), N2);
            	scaledLat= g.x;
                scaledLng= g.y;
                long quantizedX=(long) Math.floor(scaledLat);
				long quantizedY=(long) Math.floor(scaledLng);
                SpatialObject sso = Hilbert.getHilbertIndex(scaledLat,scaledLng,N2, Constant.secondary, numberOfPoi, false, 'c');
		        long jeff = sso.getHilbertValue() ; //Hilbert.computeIndex(Constant.N1, quantizedX, quantizedY);
		        HilbertRange hr = new HilbertRange(Constant.N1);
		       // long houtan = hr.getHilbert(Constant.N1, quantizedX, quantizedY);
		        long houtan = hr.getHilbert(Constant.N1, scaledLat, scaledLng);
		        if (jeff != houtan) 
		        	System.out.println("Jeff=" + jeff + " houtan = " + houtan);
		        */
	}
    
    public static void drawGridAndCurveWithNumberOnly() {
    	int order = 7;
    	int gridsize = (int)Math.pow(2, order);
    	com.std.princeton.StdDraw.setCanvasSize(1000, 1000);
    	com.std.princeton.StdDraw.setXscale(0, Math.pow(2, order));
    	com.std.princeton.StdDraw.setYscale(0, Math.pow(2, order));
//		for (int i = 0; i <= gridsize; i++) {
//			com.std.princeton.StdDraw.setPenColor(StdDraw.BLACK);
//			com.std.princeton.StdDraw.setPenRadius(0.0005);
//			com.std.princeton.StdDraw.line(i, 0, i, gridsize);
//			if ((i < gridsize) && (order < 5))
//				com.std.princeton.StdDraw.text(i + 0.5, -0.2, Integer.toString(i));
//		}
//		
//		for (int i = 0; i <= gridsize; i++) {
//			com.std.princeton.StdDraw.setPenRadius(0.0005);
//			com.std.princeton.StdDraw.line(0, i, gridsize, i);
//			if ((i < gridsize) && (order < 5))
//				com.std.princeton.StdDraw.text(-0.2, i + 0.5, Integer.toString(i));
			
//		}
		StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
		StdDraw.setPenRadius(0.004);
		hilbert0(order);
		
		StdDraw.setPenColor(StdDraw.RED);
//	    StdDraw.text(x, y, String.valueOf(hilbertVal));
    }
    public static void plotPointOfInterest() {
//    	com.std.princeton.StdDraw window = new com.std.princeton.StdDraw();;
    	int order = 7;
    	int gridsize = (int)Math.pow(2, order);
//    	com.std.princeton.StdDraw.setCanvasSize(800, 800);
//    	com.std.princeton.StdDraw.setXscale(0, Math.pow(2, order));
//    	com.std.princeton.StdDraw.setYscale(0, Math.pow(2, order));
//    	
//		for (int i = 0; i <= gridsize; i++) {
//			com.std.princeton.StdDraw.setPenColor(StdDraw.LIGHT_GRAY);
//			com.std.princeton.StdDraw.setPenRadius(0.0005);
//			com.std.princeton.StdDraw.line(i, 0, i, gridsize);
//			if ((i < gridsize) && (order < 5))
//				com.std.princeton.StdDraw.text(i + 0.5, -0.4, Integer.toString(i));
//		}
//		
//		for (int i = 0; i <= gridsize; i++) {
//			com.std.princeton.StdDraw.setPenRadius(0.0005);
//			com.std.princeton.StdDraw.line(0, i, gridsize, i);
//			if ((i < gridsize) && (order < 5))
//				com.std.princeton.StdDraw.text(-0.2, i + 0.5, Integer.toString(i));
//		}
//		StdDraw.setPenColor(StdDraw.DARK_GRAY);
//		hilbert0(order);
    	
		com.std.princeton.StdDraw.setXscale(Constant.min.x, Constant.max.x);
    	com.std.princeton.StdDraw.setYscale(Constant.min.y, Constant.max.y);
    	com.std.princeton.StdDraw.setPenColor(Color.red);
    	com.std.princeton.StdDraw.setPenRadius(0.002);
    	try {
	        System.out.println("Generating Scaled1.txt and scaled2.txt ...");
	        BufferedReader all = new BufferedReader(new FileReader(Constant.FILTEREDDATA));
	        String str1;
	        String[] coordinate = new String[2];
	        while ((str1 = all.readLine()) != null) {
	        	coordinate = str1.split(",");
	        	double lat1 = Double.parseDouble(coordinate[0]);
		        double lng1 = Double.parseDouble(coordinate[1]);
		        
		        com.std.princeton.StdDraw.point(lat1, lng1);
	        }
	        System.out.println("Plotting finished..");
	        all.close();
	        } catch (IOException e) {
				System.out.println("Error reading file");
                System.exit(1);
			}
    }
    /**
     *  Plots first converts the LAT LONG coordinates to a scaled version based on the axes and then the points in the scaled.txt are drawn
	 *	scaled1.txt has points from 1 to n where scaled2.txt has all of them shifted one down so from 0 to n-1
	 *  The last four parameters are not used!!!!!!
     */
	public static void scaleAndPlot(hilbert.StdDraw mainWindow, double expoN1, int N1, 
			hilbert.StdDraw dualWindow, double expoN2,int N2)
	{
		try {
	        System.out.println("Generating Scaled1.txt and scaled2.txt ...");
	        BufferedReader all = new BufferedReader(new FileReader(Constant.FILTEREDDATA));
	        
	        //BufferedWriter dual = new BufferedWriter(new FileWriter(Constant.FILTEREDDUALDATA));
//	        BufferedWriter scaled = new BufferedWriter(new FileWriter(Constant.SCALEDDATA));
	        //BufferedWriter scaleddual = new BufferedWriter(new FileWriter(Constant.SCALEDDUALDATA));
	        
//	        BufferedWriter hilbertindexed = new BufferedWriter(new FileWriter(Constant.HILBERTINDEXED));
	        //BufferedWriter dualhilbertindexed = new BufferedWriter(new FileWriter(Constant.DUALHILBERTINDEXED));
	        String str1;
            double scaledLat=0;
            double scaledLng=0;
            String[] coordinate = new String[2];
            int numberOfPoi = 0;
            int dualPOI = 0;
            //HilbertPOI hp = new HilbertPOI();
            int tempcnt = 0; //delete
            mainWindow.setPenRadius(0.02);//0.006
            mainWindow.setPenColor(StdDraw.RED);
            mainWindow.setXscale(Constant.min.x, Constant.max.x);
            mainWindow.setXscale(Constant.min.y, Constant.max.y);
           
            dualWindow.setPenRadius(0.003);//0.006
            dualWindow.setPenColor(StdDraw.BLUE);
            
	        while ((str1 = all.readLine()) != null) {
	        	coordinate = str1.split(",");
	        	double lat1 = Double.parseDouble(coordinate[0]);
		        double lng1 = Double.parseDouble(coordinate[1]);
		        
		        Point2D.Double g = geo2Screen(new Point2D.Double(lat1, lng1), N1);
		        System.out.println(g.toString());
		        
		       // 
	            scaledLat= Math.floor(g.x);
                scaledLng= Math.floor(g.y);
                System.out.println(numberOfPoi+1 + "," + lat1 + "," + lng1);
//                hp = storeIndex(scaledLat,scaledLng,N1, poiMap1, numberOfPoi);

                mainWindow.point(scaledLat,scaledLng);
				
                //scaled variable now contain the 0-n range just to measure the numbers of EXP1 of TKDE
                numberOfPoi++;
                //write scaled POIs to file
                //scaled.write(Double.toString(scaledLat) + "," + Double.toString(scaledLng)+"\n");
                //hilbertindexed.write(hp.toString());
                //get the dual data 
                //we use a random number between 0-9, probability of each number is 10%
                //it is like flip a coin, but instead of 2 choices, we have 10
                int tmp = ((int)(10 * Constant.generator.nextDouble())); 
                if (tmp == 3) {
                	tempcnt++;
                	//the current record is dual data
                	g = geo2Screen(new Point2D.Double(lat1, lng1), N2);
                	scaledLat= g.x;
                    scaledLng= g.y;
                	//dual.write(Double.toString(lat1) + "," + Double.toString(lng1)+"\n");
                	//scaleddual.write(Double.toString(scaledLat) + "," + Double.toString(scaledLng)+"\n");
                	dualWindow.point(scaledLat,scaledLng);
                	
                	//hp = storeIndex(scaledLat,scaledLng,N2, poiMap2, dualPOI);
                	//dualhilbertindexed.write(hp.toString());
                }
                
                //reversed longitude and latitude?  why?
                //out2.write(Double.toString((scaledLat*-1)+(n+1)) + "," + Double.toString(scaledLng) + "\n");
                //out2.write(Double.toString((lng1-Constant.min.y)*(1/(Constant.max.y-Constant.min.y))*(n-1))+","+Double.toString((lat1-Constant.min.x)*(1/(Constant.max.x-Constant.min.x))*(n-1))+"\n");
                //out2 1 to n    out1 0 to n 	
	        	}
	        System.out.println("Total records of main:" + numberOfPoi);
	        all.close();
	        //dual.close();
	        //scaled.close();
	        //scaleddual.close();
	        //hilbertindexed.close();
	        //dualhilbertindexed.close();
	        Constant.totalPOI = numberOfPoi;
	        Constant.dualPOI = dualPOI;
            //out2.close();
			} catch (IOException e) {
				System.out.println("Error reading file");
                System.exit(1);
			}
		}//plot
		/*try {
	        BufferedReader in1 = new BufferedReader(new FileReader("scaled1.txt"));
	        String str;
	        long poiCounter1= 0;
	        String[] coordinate = new String[2];
            while ((str = in1.readLine()) != null) {
            	coordinate = str.split(",");
	        	double lng = Double.parseDouble(coordinate[0]);
		        double lat = Double.parseDouble(coordinate[1]);
		        
	            //int p=str.indexOf(",");
	            //String slat=str.substring(0,p);
	            //String slng=str.substring(p+1,str.length());
	            //double lat = Double.valueOf(slat.trim()).doubleValue();
	            //double lng = Double.valueOf(slng.trim()).doubleValue();
	            //System.out.println(lat);
	            //System.out.println(lng);
		        
				storeIndex(lat,lng,N, poiMap1, poiCounter1);
				StdDraw.setPenRadius(0.003);//0.006
				StdDraw.setPenColor(StdDraw.CYAN);
				StdDraw.point(lat,lng);
                poiCounter1++;
	        }
	        in1.close();
		    } catch (IOException e) {
				System.out.println("Error reading file");
                System.exit(1);
		    }*/
                
/************************************************* code showing the data for shifted curve***********************************/      
 
//                try {
//		        BufferedReader in2 = new BufferedReader(new FileReader("scaled2.txt"));
//		        String str;
//                        double poiCounter2=0.0;
//		        while ((str = in2.readLine()) != null) {
//		            int p=str.indexOf(",");
//		            String slat=str.substring(0,p);
//		            String slng=str.substring(p+1,str.length());
//		            double lat = Double.valueOf(slat.trim()).doubleValue();
//		            double lng = Double.valueOf(slng.trim()).doubleValue();
//		            
//					System.out.println("Storing index " + lat + "," + lng);
//                                        storeIndex(lat,lng,N,poiMap2, (long) poiCounter2);//i THINK :) the lat lng values here are the scaled 0-x 0-y original points coordinates
//                                            
//					//TKDE StdDraw.setPenRadius(0.003);//0.006
//					////TKDE StdDraw.setPenRadius(0.008);//0.006
//                                        //TKDE StdDraw.setPenColor(//TKDE StdDraw.BLACK);
//					////TKDE StdDraw.point(lat,lng);
//                                        //******************UNCOMMENT THIS LINE***********************************
//                                        //TKDE StdDraw.setPenColor(//TKDE StdDraw.BLACK);
//                                        poiCounter2++;
//		        }
//		        in2.close();
//		    } catch (IOException e) {
//				System.out.println("Error reading file");
//                                System.exit(1);
//		    }
	
	/**
	 * This function reads the data from data.txt 
     * and filters it based on min lat/longs passed to it.
     * Reads data from data.txt and filters those in LA area and writes them back in filtered.txt also reporting the min latitude at the end
     * the parameter is not used
	 */
	public static void filter(double minLat,double maxLat, double minLong, double maxLong)
    {
		try {
		        BufferedReader in = new BufferedReader(new FileReader(Constant.ORIGINALDATA));
		        BufferedWriter out = new BufferedWriter(new FileWriter(Constant.FILTEREDDATA));
		        String str;
		        String[] coordinate = new String[2];

		        while ((str = in.readLine()) != null) {
		        	coordinate = str.split(",");
		            double lat = Double.parseDouble(coordinate[0]);
		            double lng = Double.parseDouble(coordinate[1]);

		            if ((lng>Constant.min.y) && (lng<Constant.max.y) && (lat>Constant.min.x) && (lat<Constant.max.x))
		            {
						out.write(Double.toString(lat)+","+Double.toString(lng)+"\n");
					}				        
				}
		        in.close();
		        out.close();
		    } catch (IOException e) {
				System.out.println("Error reading file");
                System.exit(1);
		    }
	}

	

	/**
	 * compute the Hilbert index for the given coordinate (x,y)
	 * change made by Ling on Feb 23, 2009
	 * Original the range of hilbert index returned by the function was 0 - Long.MAX_VALUE
	 * Ling changed it to Long.MIN_VALUE - Long.MAX_VALUE
	 * @param n
	 * @param x
	 * @param y
	 * @return
	 */
	public static long computeIndex(int n, long x,long y)
    {
		long index=-1;
		String xBin=Long.toBinaryString(x);
		String yBin=Long.toBinaryString(y);
		
		String interleaved="";
		String S="";//the Si's in the algorithm of Maryland paper
		//these two values hold the string equivalent of x and y binary coordinate values
		StringBuffer tempStrx = new StringBuffer("");//used to create the padded binary x index values
		StringBuffer tempStry = new StringBuffer("");//used to create the padded binary y index values
		String Si="";
		String finalBinary="";//concatenated binary string to be converted to decimal
		int maxLength = xBin.length();
		if (xBin.length() < yBin.length()) {
			maxLength = yBin.length();
		}
		
	 
		if (xBin.length() < maxLength) {
			//xIdx=Long.toString(x);
			for (int i=0;i<maxLength - xBin.length();i++)
				{
					tempStrx.append('0');
				}//for padding the coordinates with enough number of bits
			tempStrx.append(xBin);
		}//if xbin
		if (yBin.length()<maxLength) {
			//yIdx=Long.toString(y);
			for (int j=0;j<maxLength - yBin.length();j++)
				{
					tempStry.append('0');
				}//for padding the coordinates with enough number of bits
			tempStry.append(yBin);
		}//if ybin

		if (tempStrx.length()>0) xBin=tempStrx.toString(); //putting back the padded values to their read indexes for x and y
		if (tempStry.length()>0) yBin=tempStry.toString();
		if (xBin.length() != yBin.length()) 
        {
            System.out.println("Error! Padding not done correctly! for x=" + x + " and y="+y);
            System.out.println("Xbin = " + xBin + " and Ybin= " + yBin + " and n= " + maxLength);
        }//wrong padding if 
		
		for (int i=0;i<xBin.length();i++)
		{
			interleaved=interleaved+ xBin.charAt(i) + yBin.charAt(i);
		}//interleaving for

		for (int i=0;i<interleaved.length()-1;i=i+2)
		{
			Si = "";
			Si=Si + interleaved.substring(i, i+2);//.charAt(i)+interleaved.charAt(i+1);
			if (Si.equals("00")) S=S+'0';
			if (Si.equals("01")) S=S+'1';
			if (Si.equals("11")) S=S+'2';
			if (Si.equals("10")) S=S+'3';
			Si = "";
		}//separating Si's

		//*******************************Step 5 of the algorithm****************************************
		StringBuffer strConvert= new StringBuffer(S);//string used to take care of conversion
		for (int i=0;i<strConvert.length();i++)
		{
			if (strConvert.charAt(i)=='0')
			{
				for (int j=i+1;j<strConvert.length();j++)
				{
					if (strConvert.charAt(j)=='1') strConvert.setCharAt(j,'3');
					else if (strConvert.charAt(j)=='3') strConvert.setCharAt(j,'1');
				}//0 for
			}//0 conversion if
			if (strConvert.charAt(i)=='3')
			{
				for (int j=i+1;j<strConvert.length();j++)
								{
									if (strConvert.charAt(j)=='0') strConvert.setCharAt(j,'2');
									else if (strConvert.charAt(j)=='2') strConvert.setCharAt(j,'0');
				}//3 for
			}//3 conversion if
		}//step 5 for

	//*************************************Step 6*****************************************************
    for (int i=0;i<strConvert.length();i++)
    {
		if (strConvert.charAt(i)=='0') finalBinary=finalBinary+"00";
		if (strConvert.charAt(i)=='1') finalBinary=finalBinary+"01";
		if (strConvert.charAt(i)=='2') finalBinary=finalBinary+"10";
		if (strConvert.charAt(i)=='3') finalBinary=finalBinary+"11";
	}//i
	//long idx=1; //idx was int before. A bug which will make index less than zero
	long sum=0;
    double idx = 1;
    //long sum = Long.MIN_VALUE;
	//System.out.println("Final Binary = " + finalBinary.toString());
	for (int i=finalBinary.length()-1;i>=0;i--)
	{
		sum+=(long) (Character.digit(finalBinary.charAt(i),10)*idx);
		idx=idx*2;
		//System.out.println("sum = " + sum);
	}
		//System.out.println("The binary was " + finalBinary + "and the int is" + sum);
		index=sum;
		return(index);
	}//computeIndex


    /**
     * get a Hilbert index for each object, put them in Hashmap structures (one Hashmap for whole data set/dual data set each)
     * @param x - latitude
     * @param y - longitude
     * @param N - Hilbert curve order
     * @param map
     * @param poiId - id of each POI
     */
    @SuppressWarnings("unchecked")
	public static HilbertPOI storeIndex(double x,double y,int N, HashMap map, long poiId)
	{
		long quantizedX=(long) Math.floor(x);
		long quantizedY=(long) Math.floor(y);
		double[] tempMapVal={-1,-1,-1,-1,-1};
		////TKDE StdDraw.text(quantizedX,quantizedY,Long.toString(computeIndex(N,quantizedX,quantizedY)));
		//draws the index number next to data points
		long index = computeIndex(N,quantizedX,quantizedY);
        tempMapVal[0]=poiId;
        tempMapVal[1]=quantizedX;
        tempMapVal[2]=quantizedY;
        tempMapVal[3]=x;
        tempMapVal[4]=y;
        
        if (map == poiMap1){ //whole set
            if (poiMap1.containsKey((long) index))
            {
                Vector<double[]> tmpVec=(Vector<double[]>) poiMap1.get(index);
                if (tmpVec==null) System.err.println("NULL! index:"+ index + " Poi id:" + poiId);
                tmpVec.addElement(tempMapVal);
                poiMap1.put(index, tmpVec);
                tmpVec=null;
            }
            else
            {
	            Vector<double[]> tmpVecor= new Vector<double[]>(MAX_POI);
	            tmpVecor.addElement(tempMapVal);
	            poiMap1.put(index, tmpVecor);
            }//else
            //the above if condition adds one more vector of hospitals to the hilbert hash at index H-value 
            poiId1++;
        }
        else //dual set
        {
        	if (poiMap2.containsKey((long) index))
            {
                Vector<double[]> tmpVec= (Vector<double[]>) poiMap2.get(index);
                tmpVec.addElement(tempMapVal);
                poiMap2.put(index, tmpVec);
                tmpVec=null;
            }
            else
            {
                Vector<double[]> tmpVecor= new Vector<double[]>(MAX_POI);
                tmpVecor.addElement(tempMapVal);
                poiMap2.put(index, tmpVecor);
            }//else
           poiId2++;
        }//else for poiMap2
        
        return new HilbertPOI(index, tempMapVal);
	}//store index
    
    /**
     * get the hilbert value of the object and return the spatial object (which will be outsourced to other servers);
     * @param x
     * @param y
     * @param N
     * @param map
     * @param poiId
     * @param primary
     * @param dual -- dual info indicator
     * @return
     */
	//public static SpatialObject getHilbertIndex(double x,double y,int N, HashMap<Long, Vector<SpatialObject>> map, long poiId, boolean primary, char dual)
    public static SpatialObject getHilbertIndex(long x,long y,int N, HashMap<Long, Vector<SpatialObject>> map, long poiId, boolean primary, char dual)
	{
		//long quantizedX=(long) Math.floor(x);
		//long quantizedY=(long) Math.floor(y);
		//long index = computeIndex(N,quantizedX,quantizedY);
		//use houtan's method to get hilbert values
		HilbertRange hr = new HilbertRange(N);
		long index = hr.getHilbert(N, x, y);
        
		SpatialObject so = new SpatialObject(poiId, x, y, x, y, null, dual );//non-spatial content is null for now.
        so.setHilbertValue(index);
        if (index < 0) {
			System.out.println(so.toString());
		}
        if (primary){ //whole set
            if (Constant.primary.containsKey((long) index))
            {
            	Vector<SpatialObject> tmpVec=(Vector<SpatialObject>) Constant.primary.get(index);
                if (tmpVec==null) System.err.println("NULL! index:"+ index + " Poi id:" + poiId);
                tmpVec.addElement(so);
                Constant.primary.put(index, tmpVec);
                tmpVec=null;
            }
            else
            {
                Vector<SpatialObject> tmpVecor= new Vector<SpatialObject>(MAX_POI);
	            tmpVecor.addElement(so);
	            Constant.primary.put(index, tmpVecor);
            }//else
            //the above if condition adds one more vector of hospitals to the hilbert hash at index H-value 
        }
        else //dual set
        {
        	if (Constant.secondary.containsKey((long) index))
            {
                Vector<SpatialObject> tmpVec= (Vector<SpatialObject>) Constant.secondary.get(index);
                tmpVec.addElement(so);
                Constant.secondary.put(index, tmpVec);
                tmpVec=null;
            }
            else
            {
                Vector<SpatialObject> tmpVecor= new Vector<SpatialObject>(MAX_POI);
                tmpVecor.addElement(so);
                Constant.secondary.put(index, tmpVecor);
            }//else
        }//
        return so;
	}//store index

	/**
	 * 
	 * @param idx
	 * @return
	 */
    public static double roll(long idx) {
    	//dont use new Random everytime, because it will generate the same random numbers.
	    double randomIndex = Constant.generator.nextDouble();
	    // multiply by number of points so it's now between 0 and numberofpoints
	    randomIndex *= idx;
	    //truncate it to an int
	    //randomIndex = Math.floor(randomIndex);
	    // convert to an long and return
	    return randomIndex;
	  }//roll


    /**
     *     
     * @param lat1
     * @param lat2
     * @param long1
     * @param long2
     * @param unit
     * @return
     */
    public static double convertLatLng2Mile(double lat1, double lat2, double long1, double long2, char unit)
    {
	  double theta = long1 - long2;
	  double dist = Math.sin(Math.toRadians(lat1)) * Math.sin(Math.toRadians(lat2)) 
	  	+ Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.cos(Math.toRadians(theta));
	  dist = Math.acos(dist);
	  dist = Math.toDegrees(dist);
	  dist = dist * 60 * 1.1515;
	  if (unit == 'K') {
	    dist = dist * 1.609344;
	  } else if (unit == 'N') {
	        dist = dist * 0.8684;
	    }
	  return (dist);
    }
   
        /*
         long R = 6371;
        double deltaLat = Math.abs(lat2 - lat1);
        double deltaLong = Math.abs(long2- long1);
        double a = Math.sin(deltaLat/2) * Math.sin(deltaLat/2) + Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLong/2) * Math.sin(deltaLong/2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        double d = R * c;
        return d/1.6;
         */
 //}//convert lat long to mile

        
//*******************************************************Retrieve*****************************************************
//Retrieve manipulates the tmpRes array and returns the random index chosen!!
	/*
         public static void retrieve (long rndIndex){
			Object key=new Object();//key is the index for one of the points randomly chosen from myMap
			 Iterator itr = myMap.keySet().iterator();
					    for (int idx=0;idx<rndIndex+1;idx++) {//check the PLUS 1!!!
					        // Get key
					        key = itr.next();
					        }//idx for. This loop randomly picks a hospital and later it's fileds are retireved

		tmpRes = (double[]) myMap.get(key);

	}//retrieve
        */

        /**
         * this function manipulates the kNNPoiHilb array and returns the ids of the k closest poi to poi denoted by rnd QX and QY
         */
        /*public static void kNNPoiHilbF(double rndQX, double rndQY ,int k, int n)
        {
            //System.out.println("Computing the kNN using the Hilbert curve");
            int count=0;
            long qIndex= computeIndex(n,(long) Math.floor(rndQX),(long) Math.floor(rndQY));
            long qIndexLess=qIndex-1; //to go left in the curve
            long qIndexMore=qIndex;//to go right in the curve includig the starting point itself
            double realPoiLat=0;
            double realPoiLong=0;
            double realQLat=0;
            double realQLong=0;
            for (int i=0;i<500;i++)
            {
                kNNPoiHilb1[i]=-1;
                kNNPoiHilb2[i]=-1;
                kNNPoiHilbDis1[i]=-1;
                kNNPoiHilbDis2[i]=-1;
                kNNPoiHilbFinal[i]=-1;
                kNNPoiHilbFinalDis[i]=-1;
            }//init for
            //initializing kNNPoiHilb1 and kNNPoiHilb2 to -1
            
            realQLong=(rndQX-1) *(Constant.max.y-Constant.min.y)/(max-1) + Constant.min.y;  //these two lines conversts the xY coordinates of each point which is between 0 and max to a point between Constant.min.x and Constant.max.x (same for min long and Constant.max.y)
            realQLat=(rndQY-1) *(Constant.max.x-Constant.min.x)/(max-1) + Constant.min.x;
            while (count<k)//compute knn for the first hilbert curve on both directions
            {
                if (poiMap1.containsKey(qIndexMore))//change this to hashmaps' get next!!! will become much faster
                {
                    Vector tmpVec= (Vector) poiMap1.get(qIndexMore);
                    int vecLen=tmpVec.size();
                    double[] tempMapVal={-1,-1,-1,-1,-1};
                    for (int i=0;i<vecLen;i++)
                    {
                        tempMapVal=(double[]) tmpVec.get(i);
                        long PoiId=(long)tempMapVal[0];
                        
                         if (count<k)
                            {
                                    kNNPoiHilb1[count]=PoiId;
                                    ////TKDE StdDraw.setPenColor(//TKDE StdDraw.MAGENTA);
                                    ////TKDE StdDraw.text(tmpPoi[2],tmpPoi[3], (count+1) + "st");
                                    realPoiLong=(tempMapVal[3]-1)*(Constant.max.y-Constant.min.y)/(max-1) + Constant.min.y; 
                                    realPoiLat = (tempMapVal[4]-1)*(Constant.max.x-Constant.min.x)/(max-1) + Constant.min.x;
                                    //EDistanceHSum = EDistanceHSum + convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M');
                                    kNNPoiHilbDis1[count]=convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M');
                                    count++;                         
                                    //System.out.println(count +  " st neighbor 1st hilbert distance: " + convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M') + " miles, id: " + allPoi + " lat: " + realPoiLat + "long: " + realPoiLong);
                                    //The above line shows individual reasulst for each experiment
                                    //TKDE StdDraw.setPenColor(//TKDE StdDraw.BLACK);
                            }//if
                        
                    }//i for
                }//index exists in poiMap1
                
                
                if (poiMap1.containsKey(qIndexLess))
                {
                    Vector tmpVec= (Vector) poiMap1.get(qIndexLess);
                    int vecLen=tmpVec.size();
                    double[] tempMapVal={-1,-1,-1,-1,-1};
                    for (int i=0;i<vecLen;i++)
                    {
                        tempMapVal=(double[]) tmpVec.get(i);
                        long PoiId=(long)tempMapVal[0];
                        
                         if (count<k)
                            {
                                    kNNPoiHilb1[count]=PoiId;
                                    ////TKDE StdDraw.setPenColor(//TKDE StdDraw.MAGENTA);
                                    ////TKDE StdDraw.text(tmpPoi[2],tmpPoi[3], (count+1) + "st");
                                    realPoiLong=(tempMapVal[3]-1)*(Constant.max.y-Constant.min.y)/(max-1) + Constant.min.y; 
                                    realPoiLat = (tempMapVal[4]-1)*(Constant.max.x-Constant.min.x)/(max-1) + Constant.min.x;
                                    //EDistanceHSum = EDistanceHSum + convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M');
                                    kNNPoiHilbDis1[count]=convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M');
                                    count++;                         
                                    //System.out.println(count +  " st neighbor 1st hilbert distance: " + convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M') + " miles, id: " + allPoi + " lat: " + realPoiLat + "long: " + realPoiLong);
                                    //The above line shows individual reasulst for each experiment
                                    //TKDE StdDraw.setPenColor(//TKDE StdDraw.BLACK);
                            }//if
                    }//i for
                }//index exists in poiMap1
                
                
                
                qIndexLess--;
                qIndexMore++; 
                
            }//while

//            count=0;
//            double temp=rndQX;
//            rndQX=-rndQY+max+1;
//            rndQY=temp;
//            //The above three lines rotate the query point for the shifted curve
//            qIndex= computeIndex(n,(long) Math.floor(rndQX),(long) Math.floor(rndQY));
//            qIndexLess=qIndex-1; //to go left in the curve
//            qIndexMore=qIndex;//to go right in the curve includig the starting point itself
//            realQLong=(rndQX-1) *(Constant.max.y-Constant.min.y)/(max-1) + Constant.min.y;  //these two lines conversts the xY coordinates of each point which is between 0 and max to a point between Constant.min.x and Constant.max.x (same for min long and Constant.max.y)
//            realQLat=(rndQY-1) *(Constant.max.x-Constant.min.x)/(max-1) + Constant.min.x;
//            realPoiLat=0;
//            realPoiLong=0;
//
//            while (count <k)
//            {
//                if (poiMap2.containsKey(qIndexMore))
//                {
//                    Vector tmpVec= (Vector) poiMap2.get(qIndexMore);
//                    int vecLen=tmpVec.size();
//                    double[] tempMapVal={-1,-1,-1,-1,-1};
//                    for (int i=0;i<vecLen;i++)
//                    {
//                        tempMapVal=(double[]) tmpVec.get(i);
//                        long PoiId=(long)tempMapVal[0];
//                        if (count<k)
//                            {
//                                    kNNPoiHilb2[count]=PoiId;
//                                    ////TKDE StdDraw.setPenColor(//TKDE StdDraw.MAGENTA);
//                                    ////TKDE StdDraw.text(tmpPoi[2],tmpPoi[3], (count+1) + "st");
//                                    realPoiLong=(tempMapVal[3]-1)*(Constant.max.y-Constant.min.y)/(max-1) + Constant.min.y; 
//                                    realPoiLat = (tempMapVal[4]-1)*(Constant.max.x-Constant.min.x)/(max-1) + Constant.min.x;
//                                    //EDistanceHSum = EDistanceHSum + convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M');
//                                    kNNPoiHilbDis2[count]=convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M');
//                                    count++;                         
//                                    //System.out.println(count +  " st neighbor 2nd hilbert distance: " + convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M') + " miles, id: " + allPoi + " lat: " + realPoiLat + "long: " + realPoiLong);
//                                    //The above line shows individual reasulst for each experiment
//                                    //TKDE StdDraw.setPenColor(//TKDE StdDraw.BLACK);
//                            }//if
//                    }//i for
//                }//index exists in poiMap2
//                
//                
//                if (poiMap2.containsKey(qIndexLess))
//                {
//                    Vector tmpVec= (Vector) poiMap2.get(qIndexLess);
//                    int vecLen=tmpVec.size();
//                    double[] tempMapVal={-1,-1,-1,-1,-1};
//                    for (int i=0;i<vecLen;i++)
//                    {
//                        tempMapVal=(double[]) tmpVec.get(i);
//                        long PoiId=(long)tempMapVal[0];
//                        
//                         if (count<k)
//                            {
//                                    kNNPoiHilb2[count]=PoiId;
//                                    ////TKDE StdDraw.setPenColor(//TKDE StdDraw.MAGENTA);
//                                    ////TKDE StdDraw.text(tmpPoi[2],tmpPoi[3], (count+1) + "st");
//                                    realPoiLong=(tempMapVal[3]-1)*(Constant.max.y-Constant.min.y)/(max-1) + Constant.min.y; 
//                                    realPoiLat = (tempMapVal[4]-1)*(Constant.max.x-Constant.min.x)/(max-1) + Constant.min.x;
//                                    //EDistanceHSum = EDistanceHSum + convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M');
//                                    kNNPoiHilbDis2[count]=convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M');
//                                    count++;                         
//                                    //System.out.println(count +  " st neighbor 1st hilbert distance: " + convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M') + " miles, id: " + allPoi + " lat: " + realPoiLat + "long: " + realPoiLong);
//                                    //The above line shows individual reasulst for each experiment
//                                    //TKDE StdDraw.setPenColor(//TKDE StdDraw.BLACK);
//                            }//if
//                    }//i for
//                }//index exists in poiMap2 
//                qIndexLess--;
//                qIndexMore++; 
//                
//            }//second while
            
        }//kNNPoiHilbF
        */
        /**
         * compute the euclidean distance between p1 and p2
         * @param p1
         * @param p2
         * @return
         */
        public static double euclideanDist(Point2D.Double p1, Point2D.Double p2) {
        	return Math.sqrt(Math.pow(p1.x - p2.x, 2.0) + Math.pow((p1.y - p2.y), 2.0));
        }
        
        /**
         * Given a query point, find the k nearest POIs in Euclidean distance.
         * Naive approach is just go over all POIs and compute its distance to query point
         * Then do a sort on the result, and return the top k closest one.
         * Notice we have 2 coordinate systems in this program
         * real one and fake one ((0,0) to (2^N, 2^N)), pay attention to the conversion between 
         * @param query
         * @param k
         * @return
         */
        public static double[] kNN(Point2D.Double query, int k) {
        	
        	return new double[k];
        }
        /**
         * this function manipulates the kNNPoiReal array and returns the ids of the k closest poi to poi denoted by rndQX and rndQY
         * @param rndQX
         * @param rndQY
         * @param k
         */
        @SuppressWarnings("unchecked")
		/*public static void kNNPoiRealF(double rndQX, double rndQY ,int k)
        {
        
	        for (int i=0;i<500;i++)
	            kNNPoiReal[i]=-1;
            
	        double shortestDPrev = -1;
	        double minDis = Double.MAX_VALUE; //?
	        double EDistance=0;
	        double realQLong=(rndQX -1) *(Constant.max.y-Constant.min.y)/(max-1) + Constant.min.y;  //these two lines conversts the xY coordinates of each point which is between 0 and max to a point between Constant.min.x and Constant.max.x (same for min long and Constant.max.y)
	        double realQLat=(rndQY -1) *(Constant.max.x-Constant.min.x)/(max-1) + Constant.min.x;
	        
	        double realPoiLat=0;
	        double realPoiLong=0;
	        //Math.sqrt(2) * Math.pow(2,N);
	        //this variable stores the shortes distance viewed from previous iteration
	        //the minimum distance from the current POI to Q point
	        for (int NN=0;NN<k;NN++)
	        {    
                minDis = convertLatLng2Mile(Constant.min.x,Constant.max.x,Constant.min.y,Constant.max.y,'M'); //38 miles
                Collection<Vector<?>> col = poiMap1.values();
                numberOfVectors = poiMap1.size();
                Iterator<Vector<?>> iter = col.iterator ();
                double tmpMapVal[] = {-1,-1,-1,-1,-1};
                long idx=0;
                averageRep = 0;
                while (iter.hasNext ()) 
                {
	                Vector<double[]> tmpVec= (Vector<double[]>) iter.next();
	                int vecLen=tmpVec.size();
	                if ( vecLen > MaximumRepetition) MaximumRepetition = vecLen;
	                averageRep += vecLen;
	                for (int count=0;count<vecLen;count++)
	                {
		                tmpMapVal=(double[]) tmpVec.get(count);
		                long poiId=(long) tmpMapVal[0];
		                double PoiX = tmpMapVal[3];
		                double PoiY = tmpMapVal[4];
		                realPoiLong = (PoiX-1)*(Constant.max.y-Constant.min.y)/(max-1) + Constant.min.y; 
		                realPoiLat = (PoiY-1)*(Constant.max.x-Constant.min.x)/(max-1) + Constant.min.x;
		                EDistance = convertLatLng2Mile(realQLat,realPoiLat,realQLong,realPoiLong,'M');
		                
		                if (  (EDistance <= minDis)  && (EDistance> shortestDPrev))
		                    {
		                        minDis = EDistance;
		                        kNNPoiReal[NN] = poiId;
		                    }//if edistance
		                idx++;
	                }//for all elements of vector
                }//while
                
                kNNPoiRealFinalDis[NN]=minDis;
                EDistanceSum+=minDis;
                //System.out.println("Euclidean Distance for the " + NN +"th NN:" + minDis + " miles, id:" + kNNPoiReal[NN] + " real lat: " + realPoiLat + " real long: " + realPoiLong);
                //The above line shows individual results per experiment
                //indexOfPoi(kNNPoiReal[NN]);
                /**
                 * mark up all kNN points
                 */
                /*Collection col1=poiMap1.values();
                Iterator iter1 = col1.iterator ();
                double tmpMapVal1[]={-1,-1,-1,-1,-1};
                long idx1=0;
                while (iter1.hasNext ()) 
                {
                    Vector tmpVec1= (Vector) iter1.next();
                    for (int count=0;count<tmpVec1.size();count++)
                    {
                        tmpMapVal1=(double[]) tmpVec1.get(count);
                        long poiId=(long) tmpMapVal1[0];
                        double PoiX=tmpMapVal1[3];
                        double PoiY=tmpMapVal1[4];
                        if (poiId==kNNPoiReal[NN])
                        {
                        //TKDE StdDraw.setPenColor(//TKDE StdDraw.BLUE); 
                        //TKDE StdDraw.text(PoiX,PoiY, (NN+1) + "st");
                        //System.out.println("A blue was drwan for " + NN+1 + " st neigbor at " + PoiX + " " + PoiY + "for id "+ poiId);
                         //TKDE StdDraw.setPenColor(//TKDE StdDraw.BLACK);
                        
                        }//if
                    }//for
                }//while
                */
                //shortestDPrev=minDis;
	        //}// for NN 
        //}//knnPoiReal

        /**
         * find searches the kNNPoiHilb arrays looking for poi ID specified by id in such arrays and returns the index it was fount at
         * @param HilbId
         * @param id
         * @param k
         * @return
         */
        public static int find (int HilbId,long id, int k)
            {
                int ret=499;   
                if (HilbId==1)
                   {
                       for (int i=0;i<k;i++)
                           if (kNNPoiHilb1[i]==id) ret=i;
                   }//1

                   else if (HilbId==2)
                   {
                       for (int i=0;i<k;i++)
                       if (kNNPoiHilb2[i]==id) ret=i;
                   }//2
                   //if (ret==499) 
                     //  System.out.println("why 500?!!!");
                    return ret;
           }//find
       
       /**
        *  Merges the two POI arrays together with their distances into a final kNNPoiHilb and kNNPoiHilbDis
        * @param k
        * @param realQLat
        * @param realQLong
        */
        /*public static void merge(int k, double realQLat, double realQLong)
        {
            double PoiX=-1;
            double PoiY=-1;
            double realPoiLong=-1;
            double realPoiLat=-1;
            
            for (int j=0;j<k;j++)//each iteration finds the jth smallest merged element
            {
		        double minDis=convertLatLng2Mile(Constant.max.x, Constant.min.x, Constant.max.y, Constant.min.y, 'M');
		        int minId1=-1;
		        int minId2=-1;
		        int hilbId=-1;
		        for (int i=0;i<k;i++)//for the jth element query all values of both arrays
		        {
		            if (kNNPoiHilb1[i]!=-1)
		            {
	                    Collection col=poiMap1.values();
	                    Iterator iter = col.iterator ();
	            		double tmpMapVal[]={-1,-1,-1,-1,-1};
	                            int idx=0;
	                            while (iter.hasNext ()) 
	                            {
	                                    Vector tmpVec= (Vector) iter.next();
	                                    int vecLen=tmpVec.size();
	                                    for (int count=0;count<vecLen;count++)
	                                    {
	                                    tmpMapVal=(double[]) tmpVec.get(count);
	                                    long poiId=(long) tmpMapVal[0];
	                                    if (poiId==kNNPoiHilb1[i])
	                                    {
	                                        PoiX=tmpMapVal[3];
	                                        PoiY=tmpMapVal[4];
	                                        realPoiLong=(PoiX-1)/(max-1)*(Constant.max.y-Constant.min.y) + Constant.min.y; 
	                                        realPoiLat = (PoiY-1)/(max-1)*(Constant.max.x-Constant.min.x) + Constant.min.x;
	                                        if (convertLatLng2Mile(realPoiLat,realQLat,realPoiLong,realQLong,'M') < minDis )
	                                        {
	                                                    minDis = convertLatLng2Mile(realPoiLat,realQLat,realPoiLong,realQLong,'M');
	                                                    minId1=i;
	                                                    hilbId=1;
	                                        }
	                                    }//match
	                                    idx ++;
	                                    }//for all elements of  a vector
	                            }//while iter
		            }//outer if
		            if (kNNPoiHilb2[i]!=-1)
		            {
                        Collection col=poiMap1.values();
                        Iterator iter = col.iterator ();
                        double tmpMapVal[]={-1,-1,-1,-1,-1};
	                    int idx=0;
	                    while (iter.hasNext ()) 
	                    {
	                            Vector tmpVec= (Vector) iter.next();
	                            int vecLen=tmpVec.size();
	                            for (int count=0;count<vecLen;count++)
	                            {
	                            tmpMapVal=(double[]) tmpVec.get(count);
	                            long poiId=(long) tmpMapVal[0];
	                            if (poiId==kNNPoiHilb2[i])
	                            {
	                                PoiX=tmpMapVal[3];
	                                PoiY=tmpMapVal[4];
	                                realPoiLong=(PoiX-1)/(max-1)*(Constant.max.y-Constant.min.y) + Constant.min.y; 
	                                realPoiLat = (PoiY-1)/(max-1)*(Constant.max.x-Constant.min.x) + Constant.min.x;
	                                if (convertLatLng2Mile(realPoiLat,realQLat,realPoiLong,realQLong,'M') < minDis )
	                                 {
	                                            minDis = convertLatLng2Mile(realPoiLat,realQLat,realPoiLong,realQLong,'M');
	                                            minId2=i;
	                                            hilbId=2;
	                                }//
	                            }//match
	                            idx++;
	                            }//for all elements of a vector
	                    }//while iter
		            }//outer if
		        }//poiMap for
                                
                if (hilbId==1) 
                {
                    kNNPoiHilbFinal[j]=kNNPoiHilb1[minId1];
                    kNNPoiHilbDis1[minId1]=convertLatLng2Mile(Constant.min.x,Constant.max.x,Constant.min.y,Constant.max.y,'M');
                    kNNPoiHilb2[find(2,kNNPoiHilb1[minId1],k)]=-1;
                    kNNPoiHilb1[minId1]=-1;
                }
                else 
                {
                    kNNPoiHilbFinal[j]=kNNPoiHilb2[minId2];
                    kNNPoiHilbDis2[minId2]=convertLatLng2Mile(Constant.min.x,Constant.max.x,Constant.min.y,Constant.max.y,'M');
                    kNNPoiHilb1[find(1,kNNPoiHilb2[minId2],k)]=-1;
                    kNNPoiHilb2[minId2]=-1;
                  }
               	Collection col=poiMap1.values();
                Iterator iter = col.iterator ();
                double tmpMapVal[]={-1,-1,-1,-1,-1};
                int idx=0;
                while (iter.hasNext ()) 
                {
                        Vector tmpVec= (Vector) iter.next();
                        int vecLen=tmpVec.size();
                        for (int count=0;count<vecLen;count++)
                        {
                        tmpMapVal=(double[]) tmpVec.get(count);
                        long poiId=(long) tmpMapVal[0];
                        if (poiId==kNNPoiHilbFinal[j])
                        {
                            PoiX=tmpMapVal[3];
                            PoiY=tmpMapVal[4]; 
                        }//if poi
                        idx++;
                        }//for all elements of a vector
                }//while iter
                //TKDE StdDraw.setPenColor(//TKDE StdDraw.GREEN);
                  //TKDE StdDraw.text(PoiX,PoiY, (j+1) + "st");
                  //TKDE StdDraw.setPenColor(//TKDE StdDraw.BLACK);
                kNNPoiHilbFinalDis[j]=minDis;
                EDistanceHSum+=minDis;
            }//j for
        }//merge
        */
        
    /**
     * to compute precision and recall for each experiment
     * @param expNum
     * @param k
     */
    public static void computeStats(int expNum, int k)
    {
        precision[k]=0;
        try 
        {
            BufferedWriter resFile = new BufferedWriter(new FileWriter("results.txt"));
            for (int i=0;i<k;i++)
            {
                for (int j=0;j<k;j++)
                {
                    if (kNNPoiHilbFinal[i]==kNNPoiReal[j])
                        precision[k]++;
                }//j
            }//i
            precision[k]=precision[k]/k*100;
            avgPrecision[k]=avgPrecision[k]+precision[k];
            resFile.write(Double.toString(precision[k]));
            System.out.println("Precision=% "+ precision[k]);
            resFile.close();
        }//try
        catch (Exception E)
        {
            System.err.println(E.getMessage());
        }
    }//computeStats

    public static void drawHilbertCurve(hilbert.StdDraw winMain, Point2D.Double startPointMain, int curveOrderMain, boolean isDrawingGridMain,
    		hilbert.StdDraw winDual, Point2D.Double startPointDual, int curveOrderDual, boolean isDrawingGridDual) {
    	//main window
    	int main = (int) Math.pow(2, curveOrderMain);
    	winMain.setXscale(0, main);
    	winMain.setYscale(0, main);
    	if (isDrawingGridMain) {
    		drawGrid(winMain, main);
    	}
    	x = startPointMain.x;
        y = startPointMain.y;
    	System.out.println("Drawing degree " + curveOrderMain + " Hilberts...");
    	winMain.setPenColor(StdDraw.DARK_GRAY);
    	//winMain.setPenColor(StdDraw.WHITE); //don't show it
    	winMain.setPenRadius(0.0009);
    	//orientation = 0;
        hilbert0(winMain, curveOrderMain);

        //for the second window
        int dual = (int) Math.pow(2, curveOrderDual);
        winDual.setXscale(0, dual);
    	winDual.setYscale(0, dual);
        if (isDrawingGridDual) {
    		drawGrid(winDual, dual);	
    	}
        x = startPointDual.x;
        y = startPointDual.y;
        winDual.setPenColor(StdDraw.DARK_GRAY);
        //winDual.setPenColor(StdDraw.WHITE); //don't show it
    	winDual.setPenRadius(0.0009);
    	//orientation = 0;
        hilbert0(winDual, curveOrderDual); 
        
    }
    
	public static void drawGrid(hilbert.StdDraw draw, int in) {
		int gridSize = in;
		for (int i = 0; i <= gridSize; i++) {
			draw.setPenColor(StdDraw.LIGHT_GRAY);
			draw.setPenRadius(0.0005);
			draw.line(i, 0, i, gridSize);
			if (i < gridSize)
				draw.text(i + 0.5, -0.2, Integer.toString(i));
		}
		
		for (int i = 0; i <= gridSize; i++) {
			draw.setPenRadius(0.0005);
			draw.line(0, i, gridSize, i);
			if (i < gridSize)
				draw.text(-0.2, i + 0.5, Integer.toString(i));
		}
	}
    /**
     * 
     * @param args
     */
    public static void main(String args[]) {
    	drawGridAndCurveWithNumberOnly();
    	plotPointOfInterest();
    	
//    	System.out.println("you shouldn't execute from here.");
//    	filter(Constant.min.x,Constant.max.x,Constant.min.y,Constant.max.y); 
//        System.out.println("filter completed...");
        //Code to draw shifted curve
//        x = 1.5;
//        y = 1.5;
        //TKDE StdDraw.setPenColor(//TKDE StdDraw.MAGENTA);
//        System.out.println("Drawing Hilbert...");
//        hilbert0(5);
        
//        System.out.println("Plotting Points...");
//        StdDraw draw = new StdDraw(800, 800, "main");
//        scaleAndPlot(draw, draw, Math.pow(2, Constant.N),Constant.N, Constant.min.x,Constant.max.x,Constant.min.y,Constant.max.y);
        
//        System.out.println("Total number of Points: "+ poiId1 + " Vs. " + poiId2);

//        for (int expNum=0;expNum<totalNumberOfExperiments;expNum++)
//        {
//	        double rndQPointX=roll((long) Math.pow(2,Constant.N)-1)+1;  
//	        double rndQPointY=roll((long) Math.pow(2,Constant.N)-1)+1;
//	
//	        System.out.println("Experiment # " + expNum + 
//	        		" Query point:" + ((rndQPointX-1) *(Constant.max.y-Constant.min.y)/(max-1) + Constant.min.y) + " " 
//	        						+ ((rndQPointY-1) *(Constant.max.x-Constant.min.x)/(max-1) + Constant.min.x));
//	        //x and y coordinates of random query point
//	        //Mark the query point
//	        draw.setPenColor(StdDraw.RED);
//	        draw.setPenRadius(0.06);
//	        draw.text(rndQPointX,rndQPointY,"Q");
//	        draw.text(rndQPointX-1,rndQPointY-1,"*");
//	        
//	        //compute KNN using baseline method
//	        long[] timeCost = new long[2];
//	        Utility.TimerStart(timeCost);
//	        System.out.println("Computing the real Nearest Neighbbors...");
//	        kNNPoiRealF(rndQPointX,rndQPointY,K);
//	        Utility.TimerEnd(timeCost);
//	        
//	        Utility.TimerStart(timeCost);
//	        System.out.println("Computing the Hilbert Nearest Neighbbors...");
//	        kNNPoiHilbF(rndQPointX,rndQPointY,K, Constant.N);
//	        Utility.TimerEnd(timeCost);
//	        
//	        double realQLat= (rndQPointY-1) *(Constant.max.x-Constant.min.x)/(max-1) + Constant.min.x;
//	        double realQLng=(rndQPointX-1) *(Constant.max.y-Constant.min.y)/(max-1) + Constant.min.y;
//	        
//	        merge(K,realQLat,realQLng);
//	        System.out.println("Distance difference sum:" + EDistanceSum + " - "  
//	        		+  EDistanceHSum + " which is " + Math.abs(EDistanceSum-EDistanceHSum) + " miles."); 
//	        		// + " Average error of " + (Math.abs(EDistanceSum-EDistanceHSum)/K));
//	        if (Math.abs(EDistanceSum-EDistanceHSum)>maxDisplacement)
//	            maxDisplacement=Math.abs(EDistanceSum-EDistanceHSum);
//	        
//	        variance = variance + (((EDistanceSum-EDistanceHSum)/K)*((EDistanceSum-EDistanceHSum)/K));
//	        averageOveralDifference += Math.abs(EDistanceSum-EDistanceHSum);
//	        EDistanceSum=0;
//	        EDistanceHSum=0;
//	         for (int i=1;i<K+1;i++)
//	        {
//	            computeStats(expNum,i);
//	         }
//        }//expNum for 
//        //System.out.println("poi size is " + poiMap1.size() + " and the index values are " + tmpPoi[0] + " " + tmpPoi[1]+ " "+tmpPoi[2]+ " " + tmpPoi[3] + " " + tmpPoi[4]);
//        variance=Math.sqrt(variance/totalNumberOfExperiments);
//        System.out.println("Average overal difference for this experiment: " + averageOveralDifference/(K*totalNumberOfExperiments));
//        System.out.println("Maximum displacement:" + maxDisplacement/K + ". Standard Deviation=" + variance);
//        for (int i=1;i<K+1;i++)
//        {
//            System.out.println("Average Precision for k=" + i + "=%"+avgPrecision[i]/totalNumberOfExperiments);
//        }//i for
//        System.out.println("MAX rep is : " + MaximumRepetition);  
//        System.out.println("Average Repetition: "+ averageRep + "/"+ numberOfVectors + "="+ (double)averageRep/(double)numberOfVectors);
//        */
   }//main
}//Hilbert
