/**
 * 
 */
package hilbert;

/**
 * @author Ling
 *
 */
public class Range {

	private long x ;
	private long y ;
	private long stepx ;
	private long stepy ;
	/**
	 * @param x
	 * @param y
	 * @param stepx0
	 * @param stepy0
	 */
	public Range(long x, long y, long stepx0, long stepy0) {
		super();
		this.x = x;
		this.y = y;
		this.stepx = stepx0;
		this.stepy = stepy0;
	}
	public long getX() {
		return x;
	}
	public long getY() {
		return y;
	}
	public long getStepx() {
		return stepx;
	}
	public long getStepy() {
		return stepy;
	}
	
	public String toString() {
		return "From cell(" + x + ", " + y + ")" + stepx + " long and " + stepy + " high." ;
	}
	
	public String print() {
		return x + " " + y + " " + stepx + " " + stepy + " ";
	}
	
	public Range scaleTo(int main, int dual) {
		double scale = Math.pow(2, main - dual);
		long x0 = (long) (getX() * scale);
		long y0 = (long) (getY() * scale);
		long stepx0 = (long) (getStepx() * scale);
		long stepy0 = (long) (getStepy() * scale);
		
		Range r0 = new Range(x0, y0, stepx0, stepy0);
		return r0;		
	}
	/**
	 * better to use this to scale up
	 * @param r1
	 * @param main
	 * @param dual
	 * @return
	 */
	public static Range scale(Range r1, int main, int dual) {
		//transformed query range in main map
		double scale = Math.pow(2, main - dual);
		long x0 = (long) (r1.getX() * scale);
		long y0 = (long) (r1.getY() * scale);
		long stepx0 = (long) (r1.getStepx() * scale);
		long stepy0 = (long) (r1.getStepy() * scale);
		
		Range r0 = new Range(x0, y0, stepx0, stepy0);
		return r0;		
	}
}
