/**
 * 
 */
package hilbert;

import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.ListIterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;

import javax.crypto.NoSuchPaddingException;
import javax.swing.JFrame;

/**
 * @author Ling
 *
 */
public class ExperimentWrapper {

	private static void printHashmap(HashMap<Long, Vector<SpatialObject>> in ) {
		
		for (Long l : in.keySet()) {
			Vector<SpatialObject> vso = in.get(l) ;
			Iterator<SpatialObject> it = vso.iterator();
			while (it.hasNext()){
				System.out.println (it.next().toString());
			}
		}
	}
	
	private static void writeToFile(String file, Map<Long, Vector<SpatialObject>> in) {
		try {
			BufferedWriter bfw = new BufferedWriter(new FileWriter(file));
			for (Iterator<Long> it = in.keySet().iterator() ; it.hasNext() ;) {
				Vector<SpatialObject> vso = in.get(it.next()) ;
				for (Iterator<SpatialObject> itso = vso.iterator() ; itso.hasNext() ; ) {
					SpatialObject so = itso.next();
					//if (so.getDual() != 'c')
						bfw.write(so.toString() + "\n");
				}
			}
			bfw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//it has some problem, need to check the scaled values
	private static void visualize() {
		//visualization
		//prepare data and set up screen
//		Hilbert.filter(Constant.min.x,Constant.max.x,Constant.min.y,Constant.max.y);
		System.out.println("Drawing Hilbert Cuvers");
		StdDraw main = new StdDraw(Constant.ScreenSize, Constant.ScreenSize, "Main");
		StdDraw dual = new StdDraw(Constant.ScreenSize,Constant.ScreenSize, "Dual", main.getFrame());
		dual.getFrame().setLocation(main.getFrame().getLocationOnScreen().x+main.getFrame().getWidth(), main.getFrame().getLocationOnScreen().y);
		Hilbert.drawHilbertCurve(main,  new Point2D.Double(0.5,0.5), Constant.N1, false, 
				dual,new Point2D.Double(0.5,0.5), Constant.N2, false);
		System.out.println("Plotting Points...");
		Hilbert.scaleAndPlot(main, Math.pow(2, Constant.N1),Constant.N1,
				dual, Math.pow(2, Constant.N2),Constant.N2);
		System.out.println("waiting for mouse click to exit.......");
		while (!main.mousePressed()) {
			
		}
	}
	
	/**
	 * curve order v.s. # of POI per hilbert value
	 */
	private static void exp01(int main, int dual) {
		Constant.N1 = main;
		Constant.N2 = dual;
		Constant.combine = false; //we don't consider the secondary storage at this experiment.
		Constant.totalPOI = 0;
		Constant.primary.clear();
		Hilbert.init(Math.pow(2, Constant.N1),Constant.N1,Math.pow(2, Constant.N2),Constant.N2);
		System.out.println(Constant.totalPOI + " Number of POI per cell in Primary = " + (Constant.totalPOI * 1.00000) / Constant.primary.size()) ;
		//Hilbert.getDistribution(Constant.primary);
		//System.out.println("Number of POI per cell in Secondary = " + (Constant.dualPOI * 1.00000) / Constant.secondary.size()) ;
	}
	
	/**
	 * time cost on finding counter part
	 * @param main
	 * @param dual
	 */
	private static void exp010() {
		Constant.STORAGE = Constant.PATH + "SORTEDDB-R" + Constant.DUALRATE + "-O" + Constant.N1 + "-O" + Constant.N2 + ".bin";
		Map<Long, Vector<SpatialObject>> db = Utility.restoreFileFromBin(Constant.STORAGE);
		
		Vector<SpatialObject> allSO = new Vector<SpatialObject>();
		
		for ( Long l : db.keySet()) {
			allSO.addAll(db.get(l));
		}
		long[] verifyTimer = new long[3];
		Utility.TimerStart(verifyTimer);
		if (!clientVerify(allSO)) {
			System.out.println("Problems in verifying......");
		}
		Utility.TimerEnd(verifyTimer, true);
		
	}
	
	/**
	 * compute the time cost of the three components during initialization
	 * @param N1
	 * @param N2
	 * @throws InvalidKeyException
	 * @throws NoSuchAlgorithmException
	 * @throws NoSuchPaddingException
	 */
	private static void exp02(int N1, int N2) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException {
		long scaledLat=0;
        long scaledLng=0;
        String[] coordinate = new String[2];
        String str1;
        int numberOfPoi = 0;
        int dualPOI = 0;
        int tempcnt = 0;
        boolean localCtl = false, hv = true, encrypt = true, signature = true, decrypt = true, verifySignature = true;;
        HilbertRange hr2 = new HilbertRange(Constant.N2);
        HilbertRange hr1 = new HilbertRange(Constant.N1);
        
        char dual = 'a'; //don't need to be right for now
        long[] generateHvalues = new long[3];
        long[] totalTimer = new long[3];
        
        long[] encryptTimer = new long[3];
        long[] signatureTimer = new long[3];
        
        long[] decryptTimer = new long[3];
        long[] verifySignatureTimer = new long[3];
        
        Blowfish bf = new Blowfish();
        
		try {
	        //System.out.println("Initialization......");
			Utility.TimerStart(totalTimer);
	        BufferedReader all = new BufferedReader(new FileReader(Constant.FILTEREDDATA));
	        
            //Point2D.Double g1 = new Point2D.Double(), g2 = new Point2D.Double();
            while ((str1 = all.readLine()) != null) {
	        	coordinate = str1.split(",");
	        	double lat1 = Double.parseDouble(coordinate[0]);
		        double lng1 = Double.parseDouble(coordinate[1]);
		        double[] g = {lat1, lng1};
		        long[] scaled = Hilbert.geo2Grid(g, N2);
		        scaledLat = scaled[0];
		        scaledLng = scaled[1];
		        //process dual info first
		        int tmp = ((int)(10 * Constant.generator.nextDouble())); 
		        
		        SpatialObject sso = new SpatialObject(0,0,0,0,0,null,'d');
		        dual = 'c';
		        switch ((int)(Constant.DUALRATE)) {
		        	case 10 : 
		        		if (tmp == 3) {
		        			tempcnt++;
		                	localCtl = true;
		                	
		                	//Timer for calculating hilbert value
		                	if (hv) { 
		                		Utility.TimerStart(generateHvalues);
		                		hv = false;
		                	} else {
		                		Utility.TimerResume(generateHvalues);
		                	}
		            		long index = hr2.getHilbert(Constant.N2,scaled[0],scaled[1]);
		            		Utility.TimerPause(generateHvalues);
		            		//end of hilbert value calculation
		            		
		            		//generate the spatialobject
		            		sso = new SpatialObject(dualPOI, scaled[0], scaled[1], scaled[0], scaled[1], null, dual );//non-spatial content is null for now.
		                    sso.setHilbertValue(index);
		                    //Timer for encrption
		                    if (encrypt) {
		                    	Utility.TimerStart(encryptTimer);
		                    	encrypt = false;
		                    } else {
		                    	Utility.TimerResume(encryptTimer);
		                    }
		                    //encrypt
		                    byte[] cipher = bf.encrypt(SpatialObject.getBytes(sso));
		                    Utility.TimerPause(encryptTimer);
		                    //end of encryption
		                    
		                    //Timer for Signature
		                    if (signature) {
		                    	Utility.TimerStart(signatureTimer);
		                    	signature = false;
		                    } else {
		                    	Utility.TimerResume(signatureTimer);
		                    }
		                    //hash signature
		                    String signatureStr = MD5.md5Converter(cipher);
		                    Utility.TimerPause(signatureTimer);
		                    //end of signature
		                    dualPOI ++;
		                    
		                    
		                  //Timer for decrption
		                    if (verifySignature) {
		                    	Utility.TimerStart(verifySignatureTimer);
		                    	verifySignature = false;
		                    } else {
		                    	Utility.TimerResume(verifySignatureTimer);
		                    }
		                  //verify Signature
		                    String signatureStr0 = MD5.md5Converter(cipher);
		                    if (!signatureStr.equals(signatureStr0)) {System.out.println("Signatures doesn't math."); System.exit(0);}
		                    Utility.TimerPause(verifySignatureTimer);
		                    //end of verify Signature
		                    
		                   //Timer for decrption
		                    if (decrypt) {
		                    	Utility.TimerStart(decryptTimer);
		                    	decrypt = false;
		                    } else {
		                    	Utility.TimerResume(decryptTimer);
		                    }
		                    //decrypt
		                    Blowfish.decrypt(bf.getSecretKey(), cipher);
		                    Utility.TimerPause(decryptTimer);
		                    //end of decryption
		                    
		        		}
		        		break;
		        	case 20 : 
		        		if ((tmp == 7) || (tmp == 3)) {
		        			tempcnt++;
		                	localCtl = true;
		                	if (hv) { 
		                		Utility.TimerStart(generateHvalues);
		                		hv = false;
		                	} else {
		                		Utility.TimerResume(generateHvalues);
		                	}
		            		long index = hr2.getHilbert(Constant.N2,scaled[0],scaled[1]);
		            		Utility.TimerPause(generateHvalues);
		            		
		            		//generate the spatialobject
		            		sso = new SpatialObject(dualPOI, scaled[0], scaled[1], scaled[0], scaled[1], null, dual );//non-spatial content is null for now.
		                    sso.setHilbertValue(index);
		                    
		                    if (encrypt) {
		                    	Utility.TimerStart(encryptTimer);
		                    	encrypt = false;
		                    } else {
		                    	Utility.TimerResume(encryptTimer);
		                    }
		                    //encrypt
		                    byte[] cipher = bf.encrypt(SpatialObject.getBytes(sso));
		                    Utility.TimerPause(encryptTimer);
		                    
		                    if (signature) {
		                    	Utility.TimerStart(signatureTimer);
		                    	signature = false;
		                    } else {
		                    	Utility.TimerResume(signatureTimer);
		                    }
		                    //hash signature
		                    String signatureStr = MD5.md5Converter(cipher);
		                    Utility.TimerPause(signatureTimer);
		                    
		                    dualPOI ++;
		                    
		                  //Timer for decrption
		                    if (verifySignature) {
		                    	Utility.TimerStart(verifySignatureTimer);
		                    	verifySignature = false;
		                    } else {
		                    	Utility.TimerResume(verifySignatureTimer);
		                    }
		                  //verify Signature
		                    String signatureStr0 = MD5.md5Converter(cipher);
		                    if (!signatureStr.equals(signatureStr0)) {System.out.println("Signatures doesn't math."); System.exit(0);}
		                    Utility.TimerPause(verifySignatureTimer);
		                    //end of verify Signature
		                    
		                   //Timer for decrption
		                    if (decrypt) {
		                    	Utility.TimerStart(decryptTimer);
		                    	decrypt = false;
		                    } else {
		                    	Utility.TimerResume(decryptTimer);
		                    }
		                    //decrypt
		                    Blowfish.decrypt(bf.getSecretKey(), cipher);
		                    Utility.TimerPause(decryptTimer);
		                    //end of decryption
		                    
				        }
		        		break;
		        	case 30 : 
		        		if ((tmp == 7) || (tmp == 3) || (tmp == 9)) {
		        			tempcnt++;
		                	localCtl = true;
		                	if (hv) { 
		                		Utility.TimerStart(generateHvalues);
		                		hv = false;
		                	} else {
		                		Utility.TimerResume(generateHvalues);
		                	}
		            		long index = hr2.getHilbert(Constant.N2,scaled[0],scaled[1]);
		            		Utility.TimerPause(generateHvalues);
		            		
		            		//generate the spatialobject
		            		sso = new SpatialObject(dualPOI, scaled[0], scaled[1], scaled[0], scaled[1], null, dual );//non-spatial content is null for now.
		                    sso.setHilbertValue(index);
		                    
		                    if (encrypt) {
		                    	Utility.TimerStart(encryptTimer);
		                    	encrypt = false;
		                    } else {
		                    	Utility.TimerResume(encryptTimer);
		                    }
		                    //encrypt
		                    byte[] cipher = bf.encrypt(SpatialObject.getBytes(sso));
		                    Utility.TimerPause(encryptTimer);
		                    
		                    if (signature) {
		                    	Utility.TimerStart(signatureTimer);
		                    	signature = false;
		                    } else {
		                    	Utility.TimerResume(signatureTimer);
		                    }
		                    //hash signature
		                    String signatureStr = MD5.md5Converter(cipher);
		                    Utility.TimerPause(signatureTimer);
		                    
		                    dualPOI ++;
		                    
		                  //Timer for decrption
		                    if (verifySignature) {
		                    	Utility.TimerStart(verifySignatureTimer);
		                    	verifySignature = false;
		                    } else {
		                    	Utility.TimerResume(verifySignatureTimer);
		                    }
		                  //verify Signature
		                    String signatureStr0 = MD5.md5Converter(cipher);
		                    if (!signatureStr.equals(signatureStr0)) {System.out.println("Signatures doesn't math."); System.exit(0);}
		                    Utility.TimerPause(verifySignatureTimer);
		                    //end of verify Signature
		                    
		                   //Timer for decrption
		                    if (decrypt) {
		                    	Utility.TimerStart(decryptTimer);
		                    	decrypt = false;
		                    } else {
		                    	Utility.TimerResume(decryptTimer);
		                    }
		                    //decrypt
		                    Blowfish.decrypt(bf.getSecretKey(), cipher);
		                    Utility.TimerPause(decryptTimer);
		                    //end of decryption
		                    
				        }
		        		break;
		        	case 40 : 
		        		if ((tmp == 7) || (tmp == 3) || (tmp == 9) || (tmp == 5)) { //dual rate = 0.4
		        			tempcnt++;
		                	localCtl = true;
		                	if (hv) { 
		                		Utility.TimerStart(generateHvalues);
		                		hv = false;
		                	} else {
		                		Utility.TimerResume(generateHvalues);
		                	}
		            		long index = hr2.getHilbert(Constant.N2,scaled[0],scaled[1]);
		            		Utility.TimerPause(generateHvalues);
		            		
		            		//generate the spatialobject
		            		sso = new SpatialObject(dualPOI, scaled[0], scaled[1], scaled[0], scaled[1], null, dual );//non-spatial content is null for now.
		                    sso.setHilbertValue(index);
		                    
		                    if (encrypt) {
		                    	Utility.TimerStart(encryptTimer);
		                    	encrypt = false;
		                    } else {
		                    	Utility.TimerResume(encryptTimer);
		                    }
		                    //encrypt
		                    byte[] cipher = bf.encrypt(SpatialObject.getBytes(sso));
		                    Utility.TimerPause(encryptTimer);
		                    
		                    if (signature) {
		                    	Utility.TimerStart(signatureTimer);
		                    	signature = false;
		                    } else {
		                    	Utility.TimerResume(signatureTimer);
		                    }
		                    //hash signature
		                    String signatureStr = MD5.md5Converter(cipher);
		                    Utility.TimerPause(signatureTimer);
		                    
		                    dualPOI ++;
		                    
		                  //Timer for decrption
		                    if (verifySignature) {
		                    	Utility.TimerStart(verifySignatureTimer);
		                    	verifySignature = false;
		                    } else {
		                    	Utility.TimerResume(verifySignatureTimer);
		                    }
		                  //verify Signature
		                    String signatureStr0 = MD5.md5Converter(cipher);
		                    if (!signatureStr.equals(signatureStr0)) {System.out.println("Signatures doesn't math."); System.exit(0);}
		                    Utility.TimerPause(verifySignatureTimer);
		                    //end of verify Signature
		                    
		                   //Timer for decrption
		                    if (decrypt) {
		                    	Utility.TimerStart(decryptTimer);
		                    	decrypt = false;
		                    } else {
		                    	Utility.TimerResume(decryptTimer);
		                    }
		                    //decrypt
		                    Blowfish.decrypt(bf.getSecretKey(), cipher);
		                    Utility.TimerPause(decryptTimer);
		                    //end of decryption
		                    
				        }
		        		break;
		        	case 50 : 
		        		if ((tmp == 7) || (tmp == 3) || (tmp == 9) || (tmp == 5) || (tmp == 2)) { //dual rate = 0.5
		        			tempcnt++;
		                	localCtl = true;
		                	if (hv) { 
		                		Utility.TimerStart(generateHvalues);
		                		hv = false;
		                	} else {
		                		Utility.TimerResume(generateHvalues);
		                	}
		            		long index = hr2.getHilbert(Constant.N2,scaled[0],scaled[1]);
		            		Utility.TimerPause(generateHvalues);
		            		
		            		//generate the spatialobject
		            		sso = new SpatialObject(dualPOI, scaled[0], scaled[1], scaled[0], scaled[1], null, dual );//non-spatial content is null for now.
		                    sso.setHilbertValue(index);
		                    
		                    if (encrypt) {
		                    	Utility.TimerStart(encryptTimer);
		                    	encrypt = false;
		                    } else {
		                    	Utility.TimerResume(encryptTimer);
		                    }
		                    //encrypt
		                    byte[] cipher = bf.encrypt(SpatialObject.getBytes(sso));
		                    Utility.TimerPause(encryptTimer);
		                    
		                    if (signature) {
		                    	Utility.TimerStart(signatureTimer);
		                    	signature = false;
		                    } else {
		                    	Utility.TimerResume(signatureTimer);
		                    }
		                    //hash signature
		                    String signatureStr = MD5.md5Converter(cipher);
		                    Utility.TimerPause(signatureTimer);
		                    
		                    dualPOI ++;
		                    
		                  //Timer for decrption
		                    if (verifySignature) {
		                    	Utility.TimerStart(verifySignatureTimer);
		                    	verifySignature = false;
		                    } else {
		                    	Utility.TimerResume(verifySignatureTimer);
		                    }
		                  //verify Signature
		                    String signatureStr0 = MD5.md5Converter(cipher);
		                    if (!signatureStr.equals(signatureStr0)) {System.out.println("Signatures doesn't math."); System.exit(0);}
		                    Utility.TimerPause(verifySignatureTimer);
		                    //end of verify Signature
		                    
		                   //Timer for decrption
		                    if (decrypt) {
		                    	Utility.TimerStart(decryptTimer);
		                    	decrypt = false;
		                    } else {
		                    	Utility.TimerResume(decryptTimer);
		                    }
		                    //decrypt
		                    Blowfish.decrypt(bf.getSecretKey(), cipher);
		                    Utility.TimerPause(decryptTimer);
		                    //end of decryption
		                    
				        }
		        		break;
		        	default : break;
		        }
		        
                //process primary secondly
                //N1 >= N2
                scaled[0] = (long)Math.pow(2, (N1-N2)) * scaledLat;
                scaled[1] = (long)Math.pow(2, (N1-N2)) * scaledLng;
                if (N1 < N2) {
                	System.out.println("ABNORMAL! Please check the Hilbert curve orders.");
                	System.out.println(scaledLat+"/"+scaledLng + "   " + scaled[0] + "/" + scaled[1]);
                }
                char d = 'a';
                if (hv) { 
            		Utility.TimerStart(generateHvalues);
            		hv = false;
            	} else {
            		Utility.TimerResume(generateHvalues);
            	}
                long index = hr1.getHilbert(N1,scaled[0],scaled[1]);
                Utility.TimerPause(generateHvalues);
                
                //generate the spatialobject
        		sso = new SpatialObject(numberOfPoi, scaled[0], scaled[1], scaled[0], scaled[1], null, dual );//non-spatial content is null for now.
                sso.setHilbertValue(index);
                if (encrypt) {
                	Utility.TimerStart(encryptTimer);
                	encrypt = false;
                } else {
                	Utility.TimerResume(encryptTimer);
                }
                //encrypt
                byte[] cipher = bf.encrypt(SpatialObject.getBytes(sso));
                Utility.TimerPause(encryptTimer);
                
                if (signature) {
                	Utility.TimerStart(signatureTimer);
                	signature = false;
                } else {
                	Utility.TimerResume(signatureTimer);
                }
                //hash signature
                String signatureStr = MD5.md5Converter(cipher);
                Utility.TimerPause(signatureTimer);
                numberOfPoi ++;
                
              //Timer for decrption
                if (verifySignature) {
                	Utility.TimerStart(verifySignatureTimer);
                	verifySignature = false;
                } else {
                	Utility.TimerResume(verifySignatureTimer);
                }
              //verify Signature
                String signatureStr0 = MD5.md5Converter(cipher);
                if (!signatureStr.equals(signatureStr0)) {System.out.println("Signatures doesn't math."); System.exit(0);}
                Utility.TimerPause(verifySignatureTimer);
                //end of verify Signature
                
               //Timer for decrption
                if (decrypt) {
                	Utility.TimerStart(decryptTimer);
                	decrypt = false;
                } else {
                	Utility.TimerResume(decryptTimer);
                }
                //decrypt
                Blowfish.decrypt(bf.getSecretKey(), cipher);
                Utility.TimerPause(decryptTimer);
                //end of decryption
                
            }
	        all.close();
    	} catch (Exception e) {
    			e.printStackTrace();
				System.out.println("Error reading file");
                System.exit(1);
    	}
		
    	Utility.TimerEnd(generateHvalues, false);
    	Utility.TimerEnd(encryptTimer, false);
    	Utility.TimerEnd(signatureTimer, false);
    	//Utility.TimerEnd(totalTimer, true);
    	Utility.TimerEnd(decryptTimer, false);
    	Utility.TimerEnd(verifySignatureTimer, false);
	}
	/**
	 * compute the client pre-query time cost
	 * @param file -- input file of query ranges
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private static Vector<MaximalBlock> exp03(String file) throws IOException, InterruptedException {
		//Vector<Range> ranges = readRangeQuery(Constant.PATH + "LARangeQueries.txt");
		Vector<Range> ranges = readRangeQuery(file);
		//Map<Long, Vector<SpatialObject>> db = Utility.restoreFileFromBin(Constant.STORAGE);
		long[] timer1 = new long[3];
		Vector<MaximalBlock> ret = new Vector<MaximalBlock>();
		//System.out.println("# of ra	nge queries: " + ranges.size());
		Utility.TimerStart(timer1);
		for (Range r : ranges) {
			//client generate hilbert segments
			HilbertRange hr1 = new HilbertRange(Constant.N1);
			//HilbertRange hr2 = new HilbertRange(Constant.N2);
			
			Vector<MaximalBlock> vmb1 = hr1.getRangeQueryHilbertValues(r.scaleTo(Constant.N1, Constant.N2));
			//Vector<MaximalBlock> vmb2 = hr2.getRangeQueryHilbertValues(r);
			//merge two 
			//vmb1.addAll(vmb2); //hilbert segments are in vmb1 now
			//ret = vmb2;
			ret = vmb1;
			//start of a range query on server side
			//Vector<SpatialObject> vos = HilbertRange.rangeQuery(db, vmb1);
			//end of a range query
			
			//client verify result here
			//System.out.println("size = " + vmb1.size());
			
		}
	 
		Utility.TimerEnd(timer1, true);
		//System.out.println("Number of queries = " + ranges.size());
		return ret;
	}
	/**
	 * this method can retire exp03, which uses generated ranges from files; this use ranges generated on-the-fly
	 * @param file
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private static void exp030(int curveOrder, int rangeExtent) throws IOException, InterruptedException {
		//Vector<Range> ranges = readRangeQuery(Constant.PATH + "LARangeQueries.txt");
		//Vector<Range> ranges = readRangeQuery(file);
		//Map<Long, Vector<SpatialObject>> db = Utility.restoreFileFromBin(Constant.STORAGE);
		Range[] ranges = getRandomRange(curveOrder, rangeExtent);
		long[] timer1 = new long[3];
		Vector<MaximalBlock> ret = new Vector<MaximalBlock>();
		//System.out.println("# of range queries: " + ranges.size());
		Utility.TimerStart(timer1);
		for (Range r : ranges) {
			//client generate hilbert segments
			HilbertRange hr1 = new HilbertRange(curveOrder);
			//HilbertRange hr2 = new HilbertRange(Constant.N2);
			
			Vector<MaximalBlock> vmb1 = hr1.getRangeQueryHilbertValues(r);
			//Vector<MaximalBlock> vmb2 = hr2.getRangeQueryHilbertValues(r);
			//merge two 
			//vmb1.addAll(vmb2); //hilbert segments are in vmb1 now
			//ret = vmb2;
			ret = vmb1;
			//start of a range query on server side
			//Vector<SpatialObject> vos = HilbertRange.rangeQuery(db, vmb1);
			//end of a range query
			
			//client verify result here
		}
	 
			Utility.TimerEnd(timer1, true);
		//}
		//System.out.println("Number of queries = " + ranges.size());
		//return ret;
	}
	/**
	 * size of data that client transfers to server 
	 * one long number is 8 Bytes, one maximalblock has 2 longs = 16 Bytes
	 * @param file
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private static Vector<MaximalBlock> exp031(int curveOrder, int rangeExtent) throws IOException, InterruptedException {
		//Vector<Range> ranges = readRangeQuery(file);
		//Map<Long, Vector<SpatialObject>> db = Utility.restoreFileFromBin(Constant.STORAGE);
		Range[] ranges = getRandomRange(curveOrder, rangeExtent);
		Vector<MaximalBlock> ret = new Vector<MaximalBlock>();
		//System.out.println("# of range queries: " + ranges.size());
		//Utility.TimerStart(timer1);
		int size = 0;
		for (Range r : ranges) {
			//client generate hilbert segments
			HilbertRange hr1 = new HilbertRange(Constant.N1);
			//HilbertRange hr2 = new HilbertRange( Constant.N2);
			
			Vector<MaximalBlock> vmb1 = hr1.getRangeQueryHilbertValues(r);//(r.scaleTo(Constant.N1, 13));//Constant.N2));
			//Vector<MaximalBlock> vmb2 = hr2.getRangeQueryHilbertValues(r);
			//merge two 
			//vmb1.addAll(vmb2); //hilbert segments are in vmb1 now
			//ret = vmb2;
			//System.out.println("size of transmission=" + vmb1.size());
			size += vmb1.size();
			//start of a range query on server side
			//Vector<SpatialObject> vos = HilbertRange.rangeQuery(db, vmb1);
			
			
			//end of a range query
			//Utility.printVector(vos);
		}
		System.out.println("size of transmission=" + size*16); //16Bytes per maximalblock, size of 50 range queries
		return ret;
	}
	
	private static Range[] getRandomRange(int curveOrder, int rangeExtent, int numOfRanges) {
		Range[] ranges = new Range[numOfRanges];
		//for (int k = 1 ;k<6;k++ ) {
		for (int i = 0;i<numOfRanges;i++) {
			long x = (long) ((long)Math.pow(2, curveOrder)* Constant.generator.nextDouble()) ;//1512 ; //1005724;//7861;//
			long y = (long)((long)Math.pow(2,curveOrder)* Constant.generator.nextDouble()) ; //2914 ; //586130; // 3227;//
			//System.out.println("Hilbert value = 63038055 &" + Hilbert.computeIndex(Constant.N1, x, y));
			long step = (long) (0.01*rangeExtent * (Math.pow(2, curveOrder))); //?% of the data
			long stepx = step;//100 ; //1005891-1005724;//(int) (10 *  (Constant.generator.nextDouble()+1)) ;
			long stepy = step;//80 ; //14907-586130;//(int) (10 *  (Constant.generator.nextDouble())+1) ;
			Range r = new Range(x, y, stepx, stepy);
			ranges[i] = r;
		}
		return ranges;		
	}
	/**
	 * 
	 * @param curveOrder - if consider dual curve, it should be the order of the second curve
	 * @param rangeExtent
	 * @return
	 */
	private static Range[] getRandomRange(int curveOrder, int rangeExtent) {
		return getRandomRange(curveOrder, rangeExtent, 50);
	}
	/**
	 * size of transmission server sends to clients vary duplication rates
	 * @param file
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private static Vector<MaximalBlock> exp032(int curveOrder, int rangeExtent) throws IOException, InterruptedException {
		//Vector<Range> ranges = readRangeQuery(file);
		Range[] ranges = getRandomRange(curveOrder, rangeExtent);
		Constant.STORAGE = Constant.PATH + "SORTEDDB-R" + Constant.DUALRATE + "-O" + Constant.N1 + "-O" + Constant.N2 + ".bin";
		Map<Long, Vector<SpatialObject>> db = Utility.restoreFileFromBin(Constant.STORAGE);
		Vector<MaximalBlock> ret = new Vector<MaximalBlock>();
		int size = 0;
		for (Range r : ranges) {
			//client generate hilbert segments
			HilbertRange hr1 = new HilbertRange(Constant.N1);
			HilbertRange hr2 = new HilbertRange( Constant.N2);
			
			Vector<MaximalBlock> vmb1 = hr1.getRangeQueryHilbertValues(r.scaleTo(Constant.N1, Constant.N2));
			Vector<MaximalBlock> vmb2 = hr2.getRangeQueryHilbertValues(r);
			//merge two 
			vmb1.addAll(vmb2); //hilbert segments are in vmb1 now
			ret = vmb2;
			//start of a range query on server side
			Vector<SpatialObject> vos = HilbertRange.rangeQuery(db, vmb1);
			size += vos.size();
		}
		System.out.println("size of results returned by server = " + size); //per 50 queries
		return ret;
	}
	
	/**
	 * client verifies query results with no attacks
	 * @param file
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private static Vector<MaximalBlock> exp033(int curveOrder1, int curveOrder2, int rangeExtent) throws IOException, InterruptedException {
		Range[] ranges = getRandomRange(curveOrder2, rangeExtent, 50);
		
		Constant.STORAGE = Constant.PATH + "SORTEDDB-R" + Constant.DUALRATE + "-O" + Constant.N1 + "-O" + Constant.N2 + ".bin";
		Map<Long, Vector<SpatialObject>> db = Utility.restoreFileFromBin(Constant.STORAGE);
		//Range[] ranges = generateRandomGeneratedRangeQuery(db, 10, 50, curveOrder1, curveOrder2, rangeExtent );
		//Range r = new Range(0,0,(long)Math.pow(2, curveOrder2),(long)Math.pow(2, curveOrder2));
		
		long[] timer1 = new long[3];
		boolean firstTimer = true;
		int detected = 0, resultCnt = 0, resultCnt1 = 0;;
		Vector<MaximalBlock> ret = new Vector<MaximalBlock>();

		for (Range r : ranges) {
			//client generate hilbert segments
			HilbertRange hr1 = new HilbertRange(Constant.N1);
			HilbertRange hr2 = new HilbertRange(Constant.N2);
			
			Vector<MaximalBlock> vmb1 = hr1.getRangeQueryHilbertValues(r.scaleTo(Constant.N1, Constant.N2));
			Vector<SpatialObject> vos1 = HilbertRange.rangeQuery(db, vmb1);
			Vector<MaximalBlock> vmb2 = hr2.getRangeQueryHilbertValues(r);
			//merge two 
			vmb1.addAll(vmb2); //hilbert segments are in vmb1 now
			ret = vmb2;
			//start of a range query on server side
			Vector<SpatialObject> vos = HilbertRange.rangeQuery(db, vmb1);
			resultCnt1 += vos1.size();
			resultCnt += vos.size();
			//System.out.println("Total results returned = " + vos.size());
			/*
			//malicious deletion attack
			int index = 0;
			int cnt = 1; //number of deletion
			if (vos.size() < cnt) continue;
			for (int i = 0 ; i < cnt ; i++) {
				index = (int)(vos.size() * Constant.generator.nextDouble());
				vos.remove(index);
			}
			
			//end of a range query
			//Utility.printVector(vos);
			 
			 */
			if (firstTimer) {
				Utility.TimerStart(timer1);
				firstTimer = false;
			} else {
				Utility.TimerResume(timer1);
			}
			//client verify result here
			if (!clientVerify(vos)) {
				//System.out.println("malicious results.....");
				detected ++;
			}
			Utility.TimerPause(timer1);
			//System.out.println("******************************");
		}
	 
		//System.out.print("Cost of checking results of 50 queries with " + resultCnt/50.00 + "\t POIs without attack = " );
		System.out.print(resultCnt1/50.00 + "\t\t" + resultCnt/50.00 + "\t\t" );
		Utility.TimerEnd(timer1, false);
		
		return ret;
	}
	
	private static boolean findCounterPart(SpatialObject so1, Vector<SpatialObject> vso) {
		SpatialObject[] aso = new SpatialObject[vso.size()];
		aso = vso.toArray(aso);
		
		if (so1.getDual() == 'b') {
			for (SpatialObject so : aso) {
				if ((so.getId() == so1.getId()) && (so.getDual() == 'c')) {
					return true;
				}
			}
		} else { //'c'
			for (SpatialObject so : aso) {
				if ((so.getId() == so1.getId()) && (so.getDual() == 'b')) {
					return true;
				}
			}
		}
		return false;
	}
	
	@SuppressWarnings("unchecked")
	private static boolean clientVerify(Vector<SpatialObject> vso) {
		//when compute client cost, we need to consider decrypt&verify hash signature time
		
		boolean ret = true;
		SpatialObject[] aso = new SpatialObject[vso.size()];
		aso = vso.toArray(aso);
		
		for (SpatialObject so : aso) {
			
			switch (so.getDual()){
				case 'a': break; //primary without duplication
				case 'b': { //find the counter part
					if (!findCounterPart(so, vso)) {
						ret = false;;
					}
					break; //primary with duplication
				}
				case 'c':  {//find the counter part
					if (!findCounterPart(so, vso)) {
						ret = false;
					}
					break; //secondary
				}
				default :   break;
			}
			if (!ret) break;
		}
		return ret;
	}
	/**
	 * kNN query processing
	 * @param k
	 */
	private static void exp04(int k) {
		//client sends server query point
		
		//server get KNN based on hilbert values and return
		
		//client formulate range query
		
		//server response range query and return results
		
		//client verify
	
	}
	
	/**
	 * 
	 * @param numOfDeletions
	 * @param file - with query range
	 * @throws Exception
	 */
	private static void exp05(int numOfDeletions, int rangeExtent) throws Exception {
		//Vector<SpatialObject> temp = null;
		//restore query results, todo
		//server delete records
		//attachModelDelete(temp, numOfDeletions);
		//client verify and return if there are records missing or not
		int total = 50;
		//Vector<Range> ranges = readRangeQuery(file);
		Range[] ranges = getRandomRange(Constant.N2, rangeExtent, total); //
		//System.out.println("Loading..." + Constant.STORAGE);
		Constant.STORAGE = Constant.PATH + "SORTEDDB-R" + Constant.DUALRATE + "-O" + Constant.N1 + "-O" + Constant.N2 + ".bin";
		Map<Long, Vector<SpatialObject>> db = Utility.restoreFileFromBin(Constant.STORAGE);
		//long[] timer1 = new long[3];
		//boolean firstTimer = true;
		int detected = 0;
		boolean moreRange = true;
		int numUsableRange = 0, numTotalPOI = 0;
		
		
		Vector<MaximalBlock> ret = new Vector<MaximalBlock>();

		while (moreRange) {
			for (Range r : ranges) {
				//client generate hilbert segments
				HilbertRange hr1 = new HilbertRange(Constant.N1);
				HilbertRange hr2 = new HilbertRange(Constant.N2);
				
				Vector<MaximalBlock> vmb1 = hr1.getRangeQueryHilbertValues(r.scaleTo(Constant.N1, Constant.N2));
				Vector<SpatialObject> vosMain = HilbertRange.rangeQuery(db, vmb1);
				
				Vector<MaximalBlock> vmb2 = hr2.getRangeQueryHilbertValues(r);
				//merge two 
				vmb1.addAll(vmb2); //hilbert segments are in vmb1 now
				ret = vmb2;
				//start of a range query on server side
				Vector<SpatialObject> vos = HilbertRange.rangeQuery(db, vmb1);
				//Utility.printVector(vos);
				//malicious deletion attack
				//System.out.println("************************************");
				int index = 0;
				if (vos.size() < numOfDeletions) continue; //you can't delete more than number of records in the query result, skip this range, will generate more later
				numUsableRange++;
				numTotalPOI += vosMain.size();
				for (int i = 0 ; i < numOfDeletions ; i++) {
					index = (int)(vos.size() * Constant.generator.nextDouble());
					vos.remove(index);
				}
				//client verify result here
				if (!clientVerify(vos)) {
					//System.out.println("malicious results.....");
					detected ++;
				}
				if (numUsableRange == total) {
					moreRange = false;
					break;
				}	
			}
			
			ranges = getRandomRange(Constant.N2, rangeExtent, total);
		}
	 
		System.out.println("ratio of detection = " + detected + " of " + numUsableRange + "  with " + numTotalPOI*1.00/numUsableRange + " POIs " + ((double)detected / numUsableRange));
		
	}
	
	
	private static Vector<SpatialObject> attachModelDelete(Vector<SpatialObject> original, int numOfDeletions) throws Exception {
		int size = original.size();
		if (size <= numOfDeletions ) {
			throw new Exception("you can't delete all the records.");
		}
		for (int i = 0; i < numOfDeletions; i++) {
			int random = (int)(size * Constant.generator.nextDouble()); //get a random number between 0 ~ size-1
			original.remove(random);
			size --;
		}
		return original; //after deletion attack.
		
	}
	
	/**
	 * data owner preproscess data
	 */
	private static void generateDualAtDifferentRatio() {
		System.out.println("Primary order = " + Constant.N1 + " Secondary order = " + Constant.N2 + " dual ratio = " +Constant.DUALRATE) ;
		//long[] timer = new long[3];
		//Utility.TimerStart(timer);
		Hilbert.init(Math.pow(2, Constant.N1),Constant.N1,Math.pow(2, Constant.N2),Constant.N2);
		//Utility.TimerEnd(timer, true);
		
		System.out.println("Ratio = " + Constant.DUALRATE + "Total POI=" + Constant.totalPOI + " Dual POI=" + Constant.dualPOI);
		//Utility.storeBinToFile(Constant.SECONDARY, Constant.secondary);
		//Hilbert.getDistribution(Constant.secondary);
		Constant.secondary.clear();
		//Utility.getStringFromUser("Press any key to continue.....");
		Map<Long, Vector<SpatialObject>> sorted = sortHashMap(Constant.primary);
		//if we dont add this, STORAGE will be the same in the loop
		Constant.STORAGE = Constant.PATH + "SORTEDDB-R" + Constant.DUALRATE + "-O" + Constant.N1 + "-O" + Constant.N2 + ".bin";
		
		Utility.storeBinToFile(Constant.STORAGE, sorted);
		//Hilbert.getDistribution(Constant.primary);
		writeToFile(Constant.PATH + "db_init"+ Constant.DUALRATE + ".txt", sorted);
		Constant.primary.clear();
		//System.exit(0);
	}
	/**
	 * don't need to merge anymore because we generate one hashmap in init() when Constant.combine = true;
	 * @param p
	 * @param s
	 */
	private static void mergeHashMaps(HashMap<Long, Vector<SpatialObject>> p, HashMap<Long, Vector<SpatialObject>> s) {
		Iterator<Long> it = s.keySet().iterator();
		while (it.hasNext()) {
			long id = it.next();
			Vector<SpatialObject> vso = s.get(id);
			if (!p.containsKey(id)) {
				p.put(id, vso);
			} else {
				Vector<SpatialObject> vsop = p.get(id);
				if (vsop == null) System.err.println("NULL! index:"+ id);
				for (Iterator<SpatialObject> i = vso.iterator() ; i.hasNext() ; ) {
					vsop.addElement(i.next());
				}
				p.put(id, vsop);
			}
		}
	}
	
	/**
	 * 
	 * @param k - number of points every range has
	 * @param total - number of ranges
	 * @param curveOrder1 - first curve 
	 * @param curveOrder2 - second curve
	 * @param rangeExtent - range extent
	 * @return
	 * @throws InterruptedException
	 * @throws IOException
	 */
	private static Range[] generateRandomGeneratedRangeQuery(Map<Long, Vector<SpatialObject>> db, 
			int k, int total, int curveOrder1,int curveOrder2, int rangeExtent) throws InterruptedException, IOException {
		int ptsCnt = 0;
		int numQuery = 0 , numRun = 0;
		HilbertRange hr1 = new HilbertRange(curveOrder1);
		Range[] ret = new Range[total];
		do {
			numRun++;
			Range[] ranges = getRandomRange(curveOrder2, rangeExtent) ; 
			for (Range r : ranges) {
				if (numQuery >= total) break;
				Vector<MaximalBlock> vmb1 = hr1.getRangeQueryHilbertValues(r.scaleTo(curveOrder1, curveOrder2));
				if (checkPointsInRange(db, vmb1, k)) {
					ret[numQuery++] = r;
					//System.out.println("I found the " + numQuery + " range.");
				}
			}
				
		} while ((numQuery < total)) ;
		return ret;
	}
	
		private static boolean checkPointsInRange(Map<Long, Vector<SpatialObject>> db, Vector<MaximalBlock> mb, int k) {
			int numPts = 0;
			boolean flag = false;
			//Map<Long, Vector<SpatialObject>> db = Utility.restoreFileFromBin(Constant.STORAGE);
			
			for (MaximalBlock m : mb) {
				for (long i = m.hb ; i<= m.he ; i++) {
					if (db.containsKey(i)) numPts ++;
					if (numPts > k) {
						flag = true; break;
					}
				}
				if (numPts > k) {
					flag = true; break;
				}
			}
			return flag;
		}
		
	private static Vector<Range> readRangeQuery(String file) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader(file));
		String line;
		long x, y ;
		int stepx, stepy;
		Vector<Range> ranges = new Vector<Range>();
		while ((line = br.readLine()) != null) {
			//System.out.println(line);
			String[] fields = line.split("\\s");
			x = Long.parseLong(fields[0]);
			y = Long.parseLong(fields[1]);
			stepx = Integer.parseInt(fields[2]);
			stepy = Integer.parseInt(fields[3]);
			Range range = new Range(x, y, stepx, stepy);
			ranges.add(range);
		}
		br.close();
		return ranges;
	}
	private static Map<Long, Vector<SpatialObject>> sortHashMap(Map<Long, Vector<SpatialObject>> db) {
		Map<Long, Vector<SpatialObject>> sortedMap = new TreeMap<Long, Vector<SpatialObject>>(db);
		/*
		for (Iterator<Long> it = sortedMap.keySet().iterator() ; it.hasNext() ;) {
			System.out.println(sortedMap.get(it.next()));
		}
		Utility.storeBinToFile(Constant.STORAGE, sortedMap);
		*/
		return sortedMap;
	}
	private static void getKNNHilbertValues(Map<Long, Vector<SpatialObject>> db, long queryHilbertValue, int k) {
		MyArrayList<Long> mal = new MyArrayList<Long>(db.keySet());
		int index = mal.leftNN(new Long(queryHilbertValue));
		System.out.println("index="+index);
		int left = k/2 , right = k/2 + 1;
		for (ListIterator<Long> li = mal.listIterator(index+1); li.hasPrevious();) {
			left --;
			System.out.println(li.previous());
			if (left == 0) break;
		}
		System.out.println("**********************");
		for (ListIterator<Long> li = mal.listIterator(index+1); li.hasNext() ;) {
			right --;
			System.out.println(li.next());
			if (right == 0) break;
		}
		
	}
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		
		System.out.println("Running your program now......");
		visualize();
		System.exit(0);
		/*
		generateRandomGeneratedRangeQuery(10, 50);
		System.exit(0);
		*/
		
		/*exp010 - measure verifying cost 
		for (int i = 1; i <= 5; i++) //dual ratio
		{
			Constant.DUALRATE = 10 * i ;
			Constant.N1 = 12;
			Constant.N2 = Constant.N1 - 2;
			for (int loop = 0; loop < 10; loop++) {
				exp010();
			}
			System.out.println();
		}*/
		/*atatck detection 
		for (int i = 1 ; i < 5; i++) {
			int k = 6;
			Constant.STORAGE = Constant.PATH + "SORTEDDB" + k + "0.0.bin";
			for (int j = 1; j < 8 ; j ++) {
				exp05(j,Constant.PATH + "RQ-R"+k+"0-252.txt");
			}
			System.out.println();
		}
		*/
		/*exp05 - attack detection*/
		for (int j = 1; j < 8 ; j ++) {
			
			Constant.N1 = 12;
			Constant.N2 = Constant.N1 - 2;
			int k = 5 ; //fix range extent
			//for (int k = 1 ; k<=5 ; k++) {//range extent
				
				for (int i = 5 ; i <= 5; i++) { //dual rate
					Constant.DUALRATE = i*10;
					for (int loop = 0; loop < 10; loop++){
						exp05(j,k);
					}
					System.out.println();
				}
			//}
		}
		System.exit(0);
		
		/*
		int k = 63*5;
		String file = Constant.PATH + "LARangeQueries-"+ k +".txt";
		System.out.println("Processing:" + file);
		for (int i = 1 ; i < 5; i++) {
			
			for (int j = 1; j < 8 ; j ++) {
				exp05(j,file);
			}
			System.out.println();
		}
		System.exit(0);
		*/
		/*Init DB 
		for (int k = 10; k<16;k++) { //curve order
			for (int i = 1; i<=5; i++){
				System.out.println(i + " value;");
				
				Constant.DUALRATE = i*10;
				Constant.N1 = k;
				Constant.N2 = k - 2;
				generateDualAtDifferentRatio();
			}	
		}
		
		
		System.exit(0);
		*/
		/*exp01
		for (int i=2; i<20;i++) {
			exp01(i,i);
		}
		System.exit(0);
		 */
		
		/*exp02
		
		for (int k = 1; k <=5 ; k++) {
			Constant.DUALRATE = 10*k;
			for (int loop = 0; loop < 10; loop++){
				Constant.N1 = 12;
				Constant.N2 = Constant.N1 ;
				exp02(Constant.N1, Constant.N2);
				System.out.println();
				
			}
			System.out.println();
		}
		
		System.exit(0);
		*/
		/*exp03 -client pre query cost
		
		//Vector<MaximalBlock> sizer = new Vector<MaximalBlock>();
		for (int l = 1;l<=5;l++) { //range extent
			for (int k = 10;k<16;k++) {//curve order
				//String file = Constant.PATH + "LARangeQueries-" + k + ".txt";
				System.out.println("order="+k+";extent"+l);
				for (int i=0;i<10;i++) {
					
					exp030(k, l);
				}
				System.out.println();
			}
		}
		
		System.exit(0);*/
		 
		/*exp031 -- size of client transfer to server
		for (int k = 10;k<16;k++) {//curve order
			for (int l = 1;l<=5;l++) { //range extent
			for (int i=0;i<10;i++) {
				exp031(k, l);
			}
			System.out.println();
			}
		}
		
		System.exit(0);
		*/
		/*exp032
		for (int j = 1 ; j <=5 ; j++) { //dual rate
			Constant.DUALRATE = j*10;
			 //for (int k = 10;k<16;k++) {//curve order
					Constant.N1 = 10;
					Constant.N2 = 8;
				for (int l = 1;l<=5;l++) { //range extent
					for (int i=0;i<10;i++) {
						exp032(Constant.N2, l);
					}
				System.out.println();
				//}
			}

		}
		
		System.exit(0);
		 */
		
		/*exp033  */
		for (int j = 1 ; j <=5 ; j++) { //dual rate
			Constant.DUALRATE = j*10;
			 //for (int k = 10;k<16;k++) {//curve order
					Constant.N1 = 12;
					Constant.N2 = 10;
				for (int l = 2;l<=10;l=l+2) { //range extent
					for (int i=0;i<10;i++) {
						exp033(Constant.N1, Constant.N2, l);
						System.out.println();
					}
				System.out.println();
				//}
			}

		}
		
		System.exit(0);
		//exp032(Constant.PATH + "LARangeQueries.txt");
		
		//System.out.println("size = " + sizer.size());
		//visualize();
		//generateDualAtDifferentRatio();
		//generateRandomGeneratedRangeQuery(10, 50);
		//Map<Long, Vector<SpatialObject>> db = Utility.restoreFileFromBin(Constant.STORAGE);
		//getKNNHilbertValues(db, 155243, 5);
		//for (Iterator<Long> it = db.keySet().iterator() ; it.hasNext() ;) {
		//	System.out.println(db.get(it.next()));
		//}
		//Map<Long, Vector<SpatialObject>> sorted = sortHashMap(db);
		//MyArrayList<Long> mal = new MyArrayList<Long>(db.keySet());
		
		//int index = mal.leftNN(new Long(632588));
		//System.out.println("index = " + index);
		/*
		exp05(1,Constant.PATH + "LARangeQueries-63x63.txt");
		exp05(2,Constant.PATH + "LARangeQueries-63x63.txt");
		exp05(3,Constant.PATH + "LARangeQueries-63x63.txt");
		exp05(4,Constant.PATH + "LARangeQueries-63x63.txt");
		exp05(5,Constant.PATH + "LARangeQueries-63x63.txt");
		exp05(6,Constant.PATH + "LARangeQueries-63x63.txt");
		System.out.println("");
		exp05(1,Constant.PATH + "LARangeQueries-126x126.txt");
		exp05(2,Constant.PATH + "LARangeQueries-126x126.txt");
		exp05(3,Constant.PATH + "LARangeQueries-126x126.txt");
		exp05(4,Constant.PATH + "LARangeQueries-126x126.txt");
		exp05(5,Constant.PATH + "LARangeQueries-126x126.txt");
		exp05(6,Constant.PATH + "LARangeQueries-126x126.txt");
		System.out.println("");                                             
		exp05(1,Constant.PATH + "LARangeQueries-252x252.txt");                                                            
		exp05(2,Constant.PATH + "LARangeQueries-252x252.txt");                                                            
		exp05(3,Constant.PATH + "LARangeQueries-252x252.txt");                                                            
		exp05(4,Constant.PATH + "LARangeQueries-252x252.txt");                                                            
		exp05(5,Constant.PATH + "LARangeQueries-252x252.txt");                                                            
		exp05(6,Constant.PATH + "LARangeQueries-252x252.txt");       
		System.out.println("");
		exp05(1,Constant.PATH + "LARangeQueries-504x504.txt");
		exp05(2,Constant.PATH + "LARangeQueries-504x504.txt");
		exp05(3,Constant.PATH + "LARangeQueries-504x504.txt");
		exp05(4,Constant.PATH + "LARangeQueries-504x504.txt");
		exp05(5,Constant.PATH + "LARangeQueries-504x504.txt");
		exp05(6,Constant.PATH + "LARangeQueries-504x504.txt");   
		System.out.println("");
		exp05(1,Constant.PATH + "LARangeQueries-1008x1008.txt");
		exp05(2,Constant.PATH + "LARangeQueries-1008x1008.txt");
		exp05(3,Constant.PATH + "LARangeQueries-1008x1008.txt");
		exp05(4,Constant.PATH + "LARangeQueries-1008x1008.txt");
		exp05(5,Constant.PATH + "LARangeQueries-1008x1008.txt");
		exp05(6,Constant.PATH + "LARangeQueries-1008x1008.txt");
		*/
		System.exit(0);
		//int cnt = 0;
		//for (ListIterator<Long> li = mal.listIterator(); li.hasNext() ;) {
			
		//	System.out.println(li.next());
		//	cnt ++ ;
		//	if (cnt == 10) break;
		//}
		//
		//for (ListIterator<Long> li = mal.listIterator(cnt); li.hasPrevious();) {
			
		//	System.out.println(li.previous());
		//	cnt -- ;
		//	if (cnt == 0) break;
		//}
		
		//HilbertRange hr1 = new HilbertRange(Constant.N1);
		//Vector<MaximalBlock> vmb1 = hr1.getRangeQueryHilbertValues(ranges[0]);
		//HilbertRange hr2 = new HilbertRange(Constant.N2);
		//Vector<MaximalBlock> vmb2 = hr2.getRangeQueryHilbertValues(ranges[1]);
		//System.out.println("# of runs=" + vmb2.size());
		//merge two 
		//vmb1.addAll(vmb2);
		//start of a range query
		//Vector<SpatialObject> vos = HilbertRange.rangeQuery(db, vmb1);
		//System.out.println ("&&&&"+ranges[1]);
		//Utility.printVector(vos1);
		//Utility.printVector(vos);
		//System.out.println("------------------------------------------");
		//HashMap<Long, PointCnt> hashmap = Hilbert.rangeAuxStat(Constant.N2);
		//Utility.storeBinToFile2(Constant.PATH + "TEMP_POINT_CNT.txt", hashmap);
		
		
		
		//Hilbert.init(Math.pow(2, Constant.N1),Constant.N1,Math.pow(2, Constant.N2),Constant.N2);
		//Utility.storeBinToFile(Constant.STORAGE, Constant.primary);
		//Hilbert.getDistribution(primary);
		//writeToFile(Constant.PATH + "primary.txt", primary);
		//System.exit(0);
		//Utility.getStringFromUser("Press any key to continue.....");
		//Hilbert.getDistribution(secondary);
		//printHashmap(test);
		
		//mergeHashMaps(primary, secondary);
		//Utility.storeBinToFile(Constant.STORAGE, primary);
		//System.out.println("count = " + primary.size());
		//writeToFile(Constant.PATH + "storage.txt", Constant.primary);
		//System.exit(0);
		//Range[] ranges = Utility.generateRangeQuery(Constant.N1, Constant.N2) ;
		//System.out.println (ranges[1]);
		//
		//HashMap<Long, PointCnt> hashmap = Utility.restoreFileToBin2(Constant.PATH + "TEMP_POINT_CNT.txt");
		//System.out.println("The range has " + Hilbert.rangePointsCnt(hashmap, ranges[1]) + " points.");
		//writeToFile(Constant "storage.txt", db);
		//System.exit(0);
		
		
		//HashMap<Long, Vector<SpatialObject>> db = Utility.restoreFileFromBin(Constant.STORAGE);
		//writeToFile(Constant.PATH + "storage.txt", db);
		//query range in dual map (x,y) is the lower left corner
		//Range[] ranges = Utility.generateRangeQuery(Constant.N1, Constant.N2) ;
		/*
		System.out.println (ranges[0]);
		System.out.println (ranges[1]);
		HilbertRange hr1 = new HilbertRange(Constant.N1);
		Vector<MaximalBlock> vmb1 = hr1.getRangeQueryHilbertValues(ranges[0]);
		System.out.println("# of runs=" + vmb1.size());
		Vector<SpatialObject> vos1 = HilbertRange.rangeQuery(db, vmb1);
		Utility.printVector(vos1);
		*/
		/*
		for (Iterator<SpatialObject> it1 = vos.iterator() ; it1.hasNext() ; ) {
			System.out.println(it1.next());
		}
		
		HilbertRange hr2 = new HilbertRange(Constant.N2);
		Vector<MaximalBlock> vmb2 = hr2.getRangeQueryHilbertValues(ranges[1]);
		System.out.println("# of runs=" + vmb2.size());
		Vector<SpatialObject> vos2 = HilbertRange.rangeQuery(db, vmb2);
		Utility.printVector(vos2);
		for (Iterator<SpatialObject> it1 = vos.iterator() ; it1.hasNext() ; ) {
			System.out.println(it1.next());
		}
		
		checkPointsInRange();
		System.exit(0);
		 */
		// merge primary hashmap with secondary hashmap
		/*Iterator<Long> it = secondary.keySet().iterator();
		while (it.hasNext()) {
			long id = it.next();
			Vector<SpatialObject> vso = secondary.get(id);
			if (!primary.containsKey(id)) {
				primary.put(id, vso);
			} else {
				Vector<SpatialObject> vsop = primary.get(id);
				if (vsop == null) System.err.println("NULL! index:"+ id);
				for (Iterator<SpatialObject> i = vso.iterator() ; i.hasNext() ; ) {
					vsop.addElement(i.next());
				}
				primary.put(id, vsop);
			}
		}*/
		
		/*
		exp01(3, 8);
		exp01(4, 8);
		exp01(5, 8);
		exp01(6, 8);
		exp01(7, 8);
		exp01(8, 8);
		exp01(9, 8);
		exp01(10, 8);
		exp01(11, 8);
		exp01(12, 8);
		exp01(13, 8);
		exp01(14, 8);
		exp01(15, 8);
		exp01(16, 8);
		exp01(17, 8);
		exp01(18, 8);
		exp01(19, 8);
		exp01(20, 8);
		*/
		//visualize();
		System.exit(0);
		
		//no visualization
		//Hilbert.init(Math.pow(2, Constant.N1),Constant.N1,Math.pow(2, Constant.N2),Constant.N2);
		//System.out.println("Total POI=" + Constant.totalPOI + " Dual POI=" + Constant.dualPOI);
		//Utility.storeBinToFile(Constant.PRIMARY, Constant.primary);
		//Utility.storeBinToFile(Constant.SECONDARY, Constant.secondary);
		
		//System.out.println("Number of POI per cell in Primary = " + (Constant.totalPOI * 1.00000) / Constant.primary.size()) ;
		//System.out.println("Number of POI per cell in Secondary = " + (Constant.dualPOI * 1.00000) / Constant.secondary.size()) ;
		
		//Utility.getStringFromUser("Press any key to exit.....");
		//HashMap<Long, Vector<SpatialObject>> primary = Utility.restoreFileToBin(Constant.PRIMARY);
		//Hilbert.getDistribution(primary);
		//printHashmap(primary);
		//Utility.getStringFromUser("Press any key to exit.....");
		//HashMap<Long, Vector<SpatialObject>> secondary = Utility.restoreFileToBin(Constant.SECONDARY);
		//Hilbert.getDistribution(secondary);
		//printHashmap(test);
		
		// merge primary hashmap with secondary hashmap
		/*Iterator<Long> it = secondary.keySet().iterator();
		while (it.hasNext()) {
			long id = it.next();
			Vector<SpatialObject> vso = secondary.get(id);
			if (!primary.containsKey(id)) {
				primary.put(id, vso);
			} else {
				Vector<SpatialObject> vsop = primary.get(id);
				if (vsop == null) System.err.println("NULL! index:"+ id);
				for (Iterator<SpatialObject> i = vso.iterator() ; i.hasNext() ; ) {
					vsop.addElement(i.next());
				}
				primary.put(id, vsop);
			}
		}*/
		//printHashmap(primary);
		//Hilbert.getDistribution(primary);
		//writeToFile(Constant.PATH+"storage.txt", primary);
		//ask a query in real word measures - todo
		
		//deal with boundary cells - todo
		//Utility.getStringFromUser("input.....");

		
		//on main curve
		//Vector<MaximalBlock> maximalBlocks0 = hr.getRangeQueryHilbertValues(ranges[0]);
		//hr.printMaximalBlocks(maximalBlocks0);
		/*
		Vector<SpatialObject> vos = HilbertRange.rangeQuery(primary, HilbertRange.getRangeQueryHilbertValues(ranges[0], Constant.N1));
		
		for (Iterator<SpatialObject> it1 = vos.iterator() ; it1.hasNext() ; ) {
			System.out.println(it1.next());
		}
		Utility.getStringFromUser("press to continue....");
		*/
		//on dual curve
		//Vector<MaximalBlock> maximalBlocks1 = hrd.getRangeQueryHilbertValues(ranges[1]);
		//hrd.printMaximalBlocks(maximalBlocks1);
		
		/*
		vos = HilbertRange.rangeQuery(primary, HilbertRange.getRangeQueryHilbertValues(ranges[1], Constant.N2));
		for (Iterator<SpatialObject> it1 = vos.iterator() ; it1.hasNext() ; ) {
			System.out.println(it1.next());
		}
		Utility.getStringFromUser("press to continue....");
		*/
		//for (Iterator<SpatialObject> it1 = vos.iterator() ; it1.hasNext() ; ) {
		//	System.out.println(it1.next());
		//}
		//Vector<MaximalBlock> maximalBlocks1 = hrd.getRangeQuery(x, y, n1, n2);
		//convert cell # between different order of hilbert curves
		//transfer query range from one curve order to the other.
		//notice it is better to transfer from coarser to finer. Otherwise the cell will be cut in half.
		//Point2D.Double tmp1 = Hilbert.geo2Grid(Hilbert.grid2Geo(new Point2D.Double(x,y), Constant.N1), Constant.N2) ;
		
		//Vector<MaximalBlock> maximalBlocks2 = hrd.getRangeQuery((long)tmp1.x, (long)tmp1.y, (long)2 * (Constant.N2-Constant.N1) * n1, 
		//		(long)(2 * (Constant.N2-Constant.N1) * n2));
		//try {
		//	hr.printMaximalBlocks(maximalBlocks0); 
		//	hrd.printMaximalBlocks(maximalBlocks1);
		//} catch (InterruptedException e) {
		//	System.out.println("Something wrong happens");
		//	System.exit(1); 
		//}
		//System.out.println("Number of runs:" + maximalBlocks.size());
		//hr.drawRuns(main,(long) Math.pow(2, Constant.N1));
		//hrd.drawRuns(dual,(long) Math.pow(2, Constant.N2));
        //System.out.println("Total number of Points: "+ poiId1 + " Vs. " + poiId2);
		
		//dual encryption
		
		//ask range queries
		
		//ask kNN queries
		
		
		//exit after the final mouse single click
		//while(!main.mousePressed()) {
		//	
		//}
		
	}

}
