/**
 * 
 */
package hilbert;

import java.util.ArrayList;
import java.util.Collection;
import java.util.ListIterator;

/**
 * @author Ling
 * @param <E>
 *
 */
public class MyArrayList<E> extends ArrayList<E> {
	private int size;
	private transient Object[] elementData;
	/**
	 * 
	 */
	private static final long serialVersionUID = -5103137360367876969L;

	/**
	 * 
	 */
	public MyArrayList() {
		super();
		
	}

	/**
	 * @param c
	 */
	public MyArrayList(Collection<? extends E> c) {
		super(c);
		size = c.size();
		elementData = c.toArray();
	}

	/**
	 * @param initialCapacity
	 */
	public MyArrayList(int initialCapacity) {
		super(initialCapacity);
		size = initialCapacity;
		this.elementData = new Object[initialCapacity];
	}
	
	private int bisearchResult = -1;
	/**
	 * return the left near neighbor of o, no matter if o exists in the array list or not
	 * use bi-search approach
	 * @param o
	 * @return
	 */
	public int leftNN(Object o) {
		if (o == null) return -1;
		if (this.contains(o)) {
			int index = this.indexOf(o);
			if (index == 0) return 0;
			else return index-1;			
		}
		//o is not in the array list
		Long l = (Long) o;
		int lower = 0, upper = size-1;
		bisearch(lower, upper, l);
		return bisearchResult;
	}
	
	private void bisearch(int lowerIndex, int upperIndex, Long l) {
		if ((lowerIndex + 1)== upperIndex) {
			bisearchResult = lowerIndex;
		} else {
			int bisector = (int)Math.floor((upperIndex + 1 - lowerIndex)/2) + lowerIndex;
			if (((Long)this.elementData[bisector]).longValue() > l) { //left subtree
				bisearch(lowerIndex, bisector, l) ;
			} else { //right subtree
				bisearch(bisector, upperIndex, l);
			}
		}
	}
	
}
