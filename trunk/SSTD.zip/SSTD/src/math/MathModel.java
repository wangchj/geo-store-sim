/**
 * 
 */
package math;

import org.apache.commons.math.util.MathUtils;

/**
 * @author Ling
 *
 */
public class MathModel {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("k"+"\t"+"r"+"\t"+"d"+"\t"+"%"+"\t"+"m");
//		fix_r();
//		fix_k();
//		fix_r(3);
		fix_d(5); //d=5, m=5;
	}
	
	public static void fix_r() {
		int deletion = 5;
		int result = 20;
		double ratio = 0.3;
		
		for(int j=0;j<5;j++){
			for (int i = 2; i < 21 ; i =i+2) {
				deletion = i;
				double pr = pb(result, deletion, ratio);
				System.out.println(result+"\t"+ratio+"\t"+deletion+"\t"+pr);
				
			}
			result = result + 10;
		}
		System.out.println();
	}
	public static void fix_r(int m) {
		int deletion = 5;
		int result = 20;
		double ratio = 0.3;
		for(int j=0;j<5;j++){
			for (int i = 2; i < 21 ; i =i+2) {
				deletion = i;
				double pr = pbm(result, deletion, ratio,m);
				System.out.println(result+"\t"+ratio+"\t"+deletion+"\t"+pr);
				
			}
			result = result + 10;
		}
		System.out.println();
	}
	public static void fix_d() {
		int deletion = 5;
		int result = 10;
		double ratio = 0.1;
		for(int j=0;j<5;j++){
			for (int i = 10; i < 61 ; i =i+10) {
				result = i;
				double pr = pb(result, deletion, ratio);
				System.out.println(result+"\t"+ratio+"\t"+deletion+"\t"+pr);
				
			}
			ratio = ratio + 0.1;
		}
		System.out.println();
	}
	
	public static void fix_d(int m) {
		int deletion = 5;
		int result = 10;
		double ratio = 0.1;
		for(int j=0;j<5;j++){
			for (int i = 10; i < 61 ; i =i+10) {
				result = i;
				double pr = pbm(result, deletion, ratio, m);
				System.out.println(result+"\t"+ratio+"\t"+deletion+"\t"+pr+"\t"+m);
				
			}
			ratio = ratio + 0.1;
		}
		System.out.println();
	}
	
	public static void fix_k() {
		int deletion = 0;
		int result = 30;
		double ratio = 0.1;
		for(int j=0;j<5;j++){
			for (int i = 3; i < 31 ; i =i+3) {
				deletion = i;
				double pr = pb(result, deletion, ratio);
				System.out.println(result+"\t"+ratio+"\t"+deletion+"\t"+pr);
				
			}
			ratio = ratio + 0.1;
		}
		System.out.println();
	}
	/**
	 * 1-to-1 verification model
	 * @param k
	 * @param d
	 * @param r
	 * @return
	 */
	public static double pb (int k, int d, double r) {
		double ret = 0; 
		double nominator = 0;
		double denomi = 0 ;
		int a1=(int) Math.floor(k*(1-r)); 
		int a2=(int) Math.floor(k*r);
		int a3=(int) Math.floor(k*(1+r));
		
		if (d > k) return -1;
		denomi = MathUtils.binomialCoefficientDouble(a3, d); 
		denomi = denomi * denomi;
			for (int i = 0; i <= d ; i ++) {
				for (int j = 0; j <= d; j++) {
					if ((i>a1)||(j>a2)||((d-i-j)>a2)||((d-j)>k)||((d-i-j)<0)||((d-j)<0)) {
						ret += 0;
						continue;
					}
					nominator = MathUtils.binomialCoefficientDouble(a1, i)
						* MathUtils.binomialCoefficientDouble(a2, j)
						* MathUtils.binomialCoefficientDouble(a2, d-i-j)
						* MathUtils.binomialCoefficientDouble(k, d-j);
					ret += (nominator/denomi);
//					if (d == 6)  {
//						System.out.println("C("+a1+","+i+")*"+"C("+a2+","+j+")*"+"C("+a2+","+(d-i-j)+")*"+"C("+k+","+(d-j)+")*");
//						System.out.println("+");
//					}
				}
			}
			//i, j cannot both be 0, this is not a successful attack
			if (d<=a2) {
				nominator = MathUtils.binomialCoefficientDouble(a2, d);
				ret = ret - (nominator/denomi);
			}
			
		return ret;
	}
	/**
	 * 1-to-many verification model
	 * @param k
	 * @param d
	 * @param r
	 * @param m
	 * @return
	 */
	public static double pbm (int k, int d, double r, int m) {
		double ret = 0; 
		double nominator = 0;
		double denomi = 0 ;
		int a1=(int) Math.floor(k*(1-r)); 
		int a2=(int) Math.floor(k*r);
		int a3=(int) Math.floor(k*(1+r));
		int a4=(int) Math.floor(m*a3);
		int a5=(int) Math.floor(m*a2);
		
		if (d > k) return -1;
		denomi = MathUtils.binomialCoefficientDouble(a3, d); 
		denomi = denomi * MathUtils.binomialCoefficientDouble(a4, d);
		for (int i = 0; i <= d ; i ++) {
			for (int j = 0; j <= d; j++) {
				if ((i>a1)||(j>a2)||((d-i-j)>a2)||((d-j)>a5)||((d-i-j)<0)||((d-j)<0)) {
					ret += 0;
					continue;
				}
				nominator = MathUtils.binomialCoefficientDouble(a1, i)
				* MathUtils.binomialCoefficientDouble(a2, j)
				* MathUtils.binomialCoefficientDouble(a2, d-i-j)
				* MathUtils.binomialCoefficientDouble(a5, d-j);
				ret += (nominator/denomi);
//					if (d == 6)  {
//						System.out.println("C("+a1+","+i+")*"+"C("+a2+","+j+")*"+"C("+a2+","+(d-i-j)+")*"+"C("+k+","+(d-j)+")*");
//						System.out.println("+");
//					}
			}
		}
		//i, j cannot both be 0, this is not a successful attack
		if (d<=a2) {
			nominator = MathUtils.binomialCoefficientDouble(a2, d);
			ret = ret - (nominator/denomi);
		}
		
		return ret;
	}

	public static double prob(int k, int d, double r) {
		double ret = 0; 
		double nominator = 0;
		double denomi = 0 ;
		int a1=(int) Math.floor(k*(1-r)); 
		int a2=(int) Math.floor(k*r);
		int a3=(int) Math.floor(k*(1+r));
		if (d == 34) {
			System.out.println();
		}
		if (d <= k) {
			for (int i = 0; i<=d; i++) {
				
				if (((d-i)>Math.floor(k*(1-r)))||(i>Math.floor(k*r))||((d-i)>k)||(d>Math.floor(k*(1+r)))) {
					ret += 0;
					continue;
				}
				nominator = MathUtils.binomialCoefficientDouble(a1, d-i) //a choose b
					* MathUtils.binomialCoefficientDouble(a2, i) //a choose b
					* MathUtils.binomialCoefficientDouble(k, d-i); //a choose b
				denomi = MathUtils.binomialCoefficientDouble(a3, d); 
				denomi = denomi * denomi;
				ret += (nominator/denomi);
			}
		} else if ((d > k)&&(d < Math.floor(k*(1+r)))) {
			nominator = MathUtils.binomialCoefficientDouble(a2, d-k) 
				* MathUtils.binomialCoefficientDouble(k, a1);
			denomi = MathUtils.binomialCoefficientDouble(a3, d); 
			denomi = denomi * denomi;
			ret = nominator/denomi;
		} 
		
		return ret;
	}
}
