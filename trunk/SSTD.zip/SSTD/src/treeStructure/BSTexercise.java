package treeStructure;

import java.io.*;  // Needed for BufferedReader etc.

/**
 * Exercise the methods in BST --- full-feature version
 *
 * @author  Timothy Rolfe
 * @version 2002 August 8
 */
public class BSTexercise
{
   /**
    * Driver for the BST methods:  build a tree,
    * traverse it several ways when finished, and then
    * allow multiple find operations.
    */
// NOTE:  This assumes friend-like access to BSTnode fields
//        through package-level access.
   public static void main ( String[] args )
   {  BST     tree = new BST();
      BSTnode treeNode;           // Find returns a cell pointer
      String  lineIn = "";        // readLine used for user interaction
      int     value;              // decoded via "atoi"

      java.util.Scanner console = new java.util.Scanner(System.in);

   // *****  Tree building phase ***** //
      System.out.println ("\nBuilding the binary search tree");
      while (true) // Will break out on input of 666
      {  System.out.print ("Value (666 exits):  ");
         value = console.nextInt();
         if (value == 666)
            break;
         tree.insert(value);
         value = tree.size();   // For debugging convenience.
         System.out.println ("Tree (size " + value + ") after insert:");
         tree.walk();
      }

   // *****  Tree display phase ***** //
      System.out.println ("\nAverage depth of nodes:  " + tree.avgDepth()
           + "\n           Tree height:  " + tree.height());
      System.out.println ("\nExercising non-recursive tree traversals");
      System.out.println ("\nWeiss'  pre-order traversal:");
      tree.tstNR(1);
      System.out.println ("\nCarrano's  in-order traversal:");
      tree.tstNR(2);
      System.out.println ("\nWeiss' post-order traversal:");
      tree.tstNR(3);
      System.out.println ("\nLevel-order traversal for \"pretty-print\":");
      tree.pretty();

   // *****  Tree thinning phase ***** //
      System.out.println ("\nExercising Find and Delete on the tree\n");
      while (true) // Will break out on input of 666
      {  System.out.print ("Value (666 exits):  ");
         value = console.nextInt();  console.nextLine();
         if (value == 666)
            break;
         treeNode = tree.find(value);
         if (treeNode != null)
         {  System.out.print ("Found " + value + ":");
            if (treeNode.left != null)
               System.out.print ("  left child " + treeNode.left.data);
            else
               System.out.print ("  no left child");
            if (treeNode.right != null)
               System.out.print ("; right child " + treeNode.right.data);
            else
               System.out.print ("; no right child");
            System.out.println();

            System.out.print ("Do you wish it deleted?  (Y/N) ");
            lineIn = console.nextLine();
            if ( lineIn.length() > 0 &&
                 Character.toUpperCase(lineIn.charAt(0)) == 'Y' )
            {  tree.delete(value);
               value = tree.size();
               System.out.println ("Tree (size " + value + ") after delete");
               tree.walk();   System.out.println();
               tree.pretty(); System.out.println();
            }

         }
         else
            System.out.println (value + " not found in the tree");
      }

   // ***** Shut-down phase:  characteristics of remaining tree *****  //
      System.out.println ("\nAverage depth of nodes:  " + tree.avgDepth()
           + "\n           Tree height:  " + tree.height());
      tree.empty();
      System.out.println ("\nTree has been emptied:"
           + "\nAverage depth of nodes:  " + tree.avgDepth()
           + "\n           Tree height:  " + tree.height() );
      System.out.print   ("\nPress ENTER to exit.\t");
      lineIn = console.nextLine();
   }
} // end class BSTexercise